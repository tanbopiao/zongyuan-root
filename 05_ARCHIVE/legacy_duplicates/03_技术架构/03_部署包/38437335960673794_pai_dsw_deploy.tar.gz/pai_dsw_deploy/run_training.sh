#!/bin/bash
# ============================================================
# 火斗云智AIOS · PAI-DSW 192G GPU 一键训练启动脚本
# DID-BR-000002 | Ω₀⊂⊙∞⊂Ω
# 用法: bash run_training.sh [prepare|finetune|distill|eval|all]
# ============================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

MODE="${1:-all}"
echo "============================================================"
echo "  火斗云智AIOS · 模型硬裁剪训练引擎"
echo "  模式: $MODE | GPU: 192G显存 | DID-BR-000002"
echo "============================================================"
echo ""

# ---- 1. 环境检测 ----
echo "[1/6] 环境检测..."
python3 -c "import torch; print(f'  PyTorch: {torch.__version__}')" 2>/dev/null || echo "  ⚠️ PyTorch未安装"
python3 -c "import torch; print(f'  CUDA可用: {torch.cuda.is_available()}, 设备数: {torch.cuda.device_count()}')" 2>/dev/null || true
nvidia-smi --query-gpu=name,memory.total,memory.free --format=csv,noheader 2>/dev/null || echo "  ⚠️ 无法检测GPU"
echo ""

# ---- 2. 安装依赖 ----
echo "[2/6] 安装依赖..."
pip install -q -r requirements.txt 2>&1 | tail -3
echo "  ✅ 依赖安装完成"
echo ""

# ---- 3. 异构架构自适应检测 ----
echo "[3/6] 异构架构自适应检测..."
python3 scripts/heterogeneous_configurator.py
echo ""

# ---- 4. 检查ModelScope ----
echo "[4/6] 检查ModelScope..."
python3 -c "import modelscope; print(f'  ModelScope: {modelscope.__version__}')" 2>/dev/null || pip install -q modelscope
echo ""

# ---- 5. 执行训练 ----
echo "[5/6] 执行训练 (模式: $MODE)..."
echo "  日志输出到: logs/training_$(date +%Y%m%d_%H%M%S).log"
mkdir -p logs data output

python3 scripts/model_hard_pruning_engine.py --mode "$MODE" 2>&1 | tee "logs/training_$(date +%Y%m%d_%H%M%S).log"

echo ""
echo "[6/6] 训练完成检查..."
if [ -d "output" ]; then
  echo "  输出目录:"
  ls -lh output/ 2>/dev/null || echo "  (空)"
fi
echo ""
echo "============================================================"
echo "✅ 训练流程完成!"
echo "   模型输出: output/"
echo "   训练日志: logs/"
echo "   下一步: 将训练好的模型导出为GGUF,部署到腾讯云服务器"
echo "============================================================"
