# PAI-DSW 192G GPU 训练部署包

**火斗云智AIOS · 模型硬裁剪训练引擎 V1.0**
DID-BR-000002 | Ω₀⊂⊙∞⊂Ω

## 包内容

```
pai_dsw_deploy/
├── run_training.sh          # 一键训练启动脚本（主入口）
├── start_14b_full.sh        # 快速启动：14B全参微调
├── start_72b_lora.sh        # 快速启动：72B LoRA微调
├── requirements.txt         # Python依赖清单
├── scripts/
│   └── model_hard_pruning_engine.py  # 训练引擎核心
├── data/                    # 训练数据（自动生成）
├── output/                  # 模型输出（训练后生成）
└── logs/                    # 训练日志
```

## 上传到PAI-DSW

### 方式一：JupyterLab界面上传
1. 打开PAI-DSW实例 → JupyterLab
2. 左侧文件浏览器 → 上传按钮
3. 上传 `pai_dsw_deploy.tar.gz`
4. 终端执行：`tar xzf pai_dsw_deploy.tar.gz && cd pai_dsw_deploy`

### 方式二：命令行上传
```bash
# 本地打包
tar czf pai_dsw_deploy.tar.gz pai_dsw_deploy/

# 在PAI-DSW终端中（通过scp或Jupyter上传后）
tar xzf pai_dsw_deploy.tar.gz
cd pai_dsw_deploy
```

## 执行训练

```bash
# 方式A：一键全流程（推荐）
bash run_training.sh all

# 方式B：分步执行
bash run_training.sh prepare    # 1. 生成训练数据（~10分钟）
bash run_training.sh finetune   # 2. 微调训练（4-20小时）
bash run_training.sh distill    # 3. 知识蒸馏（可选）
bash run_training.sh eval       # 4. 评估验证

# 方式C：快速启动预设
bash start_14b_full.sh          # 14B全参微调（4-8小时）
bash start_72b_lora.sh          # 72B LoRA微调（12-20小时）
```

## 显存与时间预估

| 模型 | 微调方式 | 显存需求 | 预计耗时 | 适用场景 |
|------|----------|----------|----------|----------|
| Qwen2.5-7B | 全参 | ~40G | 2-4小时 | 快速验证 |
| Qwen2.5-14B | 全参 | ~120G | 4-8小时 | **推荐** |
| Qwen2.5-32B | LoRA | ~100G | 8-12小时 | 平衡选择 |
| Qwen2.5-72B | LoRA | ~160G | 12-20小时 | 最大能力 |

## 训练数据来源

训练引擎自动从以下来源构造SFT数据：
1. **真值库提取**：从 `~/.zongyuan_root/` 提取元法则、协议、决策记录
2. **领域语料合成**：基于体系架构文档合成instruction-following对
3. **格式**：Alpaca格式 `{instruction, input, output}`

如需自定义训练数据，放入 `data/train.json`：
```json
[
  {"instruction": "解释元极恒一体系", "input": "", "output": "..."},
  {"instruction": "三维稳态决策公式", "input": "", "output": "利益40%+风险35%+成本25%"}
]
```

## 输出产物

训练完成后 `output/` 目录包含：
- `final_model/` — 微调后的完整模型
- `adapter_model/` — LoRA适配器（如使用LoRA）
- `training_log.json` — 训练曲线（loss/learning_rate）
- `eval_results.json` — 5类测试用例评估结果
- `model_card.md` — 模型卡片（参数/数据/性能）

## 部署到腾讯云

训练完成后：
```bash
# 1. 量化为GGUF（可选，大幅减小体积）
python3 -c "
from transformers import AutoModelForCausalLM
model = AutoModelForCausalLM.from_pretrained('output/final_model')
# 使用llama.cpp量化
"

# 2. 打包上传
tar czf trained_model.tar.gz output/final_model/

# 3. 上传到腾讯云服务器（通过记忆网关或scp）
```

## 注意事项

1. **额度管理**：192G GPU剩余99小时20分，训练完立即停止实例
2. **断点续训**：训练引擎支持 `--resume` 从checkpoint恢复
3. **监控**：另开终端执行 `watch -n 5 nvidia-smi` 监控显存
4. **数据备份**：训练完成后立即下载 `output/` 到本地
5. **零成本**：全部使用免费额度，不产生费用

## 确权

DID-BR-000002 | Ω₀⊂⊙∞⊂Ω | 火斗云智AIOS
模型硬裁剪训练引擎 V1.0 | 2026-09-18
