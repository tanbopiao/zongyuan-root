#!/bin/bash
# 快速启动：192G GPU LoRA微调 Qwen2.5-72B
# 预计耗时: 12-20小时 | 显存需求: ~160G
# 注意: 72B需要修改 model_hard_pruning_engine.py 中的 BASE_MODEL
sed -i 's/Qwen2.5-14B-Instruct/Qwen2.5-72B-Instruct/' scripts/model_hard_pruning_engine.py
sed -i 's/full/lora/' scripts/model_hard_pruning_engine.py
bash run_training.sh all
