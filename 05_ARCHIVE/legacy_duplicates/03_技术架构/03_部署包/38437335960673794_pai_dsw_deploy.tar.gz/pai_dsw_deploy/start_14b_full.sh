#!/bin/bash
# 快速启动：192G GPU 全参微调 Qwen2.5-14B
# 预计耗时: 4-8小时 | 显存需求: ~120G
bash run_training.sh all
