# 火斗云智·政务AI中台 私有化部署指南 V1.0
DID-BR-000002 | Ω₀⊂⊙∞⊂Ω | ZONGYUAN-ROOT

## 一、部署包结构
gov_mid_platform/
├── operators/
│   └── operator_registry.py      # 4类政务算子统一注册表+执行入口+审计留痕
├── tests/
│   └── test_operators.py         # 算子仿真验收（7/7通过）
├── web/
│   └── gov-platform.html         # 官网政务AI中台产品页
└── docs/
    └── DEPLOY-GUIDE.md           # 本指南

## 二、部署模式（政务合规）
1. **私有化部署**（默认）：政务内网/政务云，物理隔离，数据不出域
2. **混合部署**：内网部署算子+治理，外网仅展示层

## 三、端口规划（台账已登记）
| 端口 | 服务 | 说明 |
|------|------|------|
| 8200 | gov-gateway | 政务统一网关（内外网隔离/国密SSL/限流）|
| 8201 | gov-operator-cluster | 政务算子集群 |
| 8202 | gov-audit-log | 全链路审计日志 |
| 8203 | gov-dashboard | 可视化大屏工作台 |

## 四、部署步骤
1. 上传部署包至目标服务器
2. 安装依赖：python3 + requests
3. 启动算子服务：python3 operators/operator_registry.py（注册自检）
4. 运行验收：python3 tests/test_operators.py（应7/7通过）
5. 配置网关/审计/大屏服务（按端口规划）
6. 接入统一身份认证+国密通道

## 五、安全基线
- 全链路审计：所有算子调用记录操作人/时间/IP/入参/结果/哈希
- 四级权限：超管/运维/经办/查阅，最小权限
- 国密适配：SM2/SM3/SM4
- 内外网摆渡：单向文件摆渡，全程留痕
- 敏感脱敏：AI推理只用脱敏副本

## 六、验收清单
- [ ] 4算子可调用（registry自检）
- [ ] 仿真验收7/7通过
- [ ] 审计日志留痕完整
- [ ] 权限越权拦截生效
