#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
火斗云智·政务AI中台 — 算子统一注册表与执行入口 V1.0
DID-BR-000002 | Ω₀⊂⊙∞⊂Ω | ZONGYUAN-ROOT
本地仿真版：注册4类政务算子，统一调用+审计留痕
"""
import hashlib
import json
import re
from datetime import datetime

TRACE = "Ω₀⊂⊙∞⊂Ω"
DID = "DID-BR-000002"

# ---------- 算子1：政务公文RAG检索 ----------
def gov_rag_search(query: str, doc_pool: list) -> dict:
    """政策条文检索：关键词+条文定位+溯源"""
    results = []
    for doc in doc_pool:
        text = doc.get("text", "")
        for para in re.split(r"[。\n]", text):
            if query in para or any(k in para for k in query.split()):
                results.append({"doc": doc.get("title"), "para": para.strip(), "source": doc.get("source")})
    return {"query": query, "hits": results[:5], "hit_count": len(results)}

# ---------- 算子2：政务材料预审 ----------
def gov_doc_check(fields: dict) -> dict:
    """材料预审：缺项检测+格式校验+逻辑矛盾"""
    issues = []
    required = ["单位名称", "统一社会信用代码", "联系人", "联系电话", "申请事项"]
    for f in required:
        if not fields.get(f):
            issues.append({"level": "error", "item": f, "msg": f"缺少必填项: {f}"})
    if fields.get("联系电话") and not re.fullmatch(r"1[3-9]\d{9}", fields.get("联系电话", "")):
        issues.append({"level": "error", "item": "联系电话", "msg": "手机号格式不正确"})
    if fields.get("统一社会信用代码") and not re.fullmatch(r"[0-9A-Z]{18}", fields.get("统一社会信用代码", "")):
        issues.append({"level": "error", "item": "统一社会信用代码", "msg": "信用代码格式不正确(应为18位)"})
    if not issues:
        issues.append({"level": "pass", "item": "整体", "msg": "材料预审通过"})
    return {"result": "pass" if all(i["level"] != "error" for i in issues) else "reject", "issues": issues}

# ---------- 算子3：政务档案OCR结构化 ----------
def gov_archive_ocr(raw_text: str) -> dict:
    """档案文本结构化：抽取元数据"""
    meta = {}
    for key, pat in [("文号", r"[^号\s]+号"), ("成文日期", r"20\d{2}年\d{1,2}月\d{1,2}日"),
                     ("发文机关", r"^[\u4e00-\u9fa5]{2,20}(?:局|厅|部|委|办|政府)"), ("标题", r"(?:关于|印发|发布).{2,40}?(?:方案|通知|意见|办法|规定|批复|措施)")]:
        m = re.search(pat, raw_text)
        meta[key] = m.group(0) if m else ""
    meta["字数"] = len(raw_text)
    meta["哈希"] = hashlib.sha256(raw_text.encode()).hexdigest()[:16]
    return meta

# ---------- 算子4：政务敏感数据脱敏 ----------
def gov_data_mask(text: str) -> dict:
    """敏感信息脱敏：身份证/手机号/住址/银行卡"""
    masked = re.sub(r"\d{17}[\dXx]", "***************X", text)
    masked = re.sub(r"1[3-9]\d{9}", "138****0000", masked)
    masked = re.sub(r"(\d{4})\d{10}(\d{4})", r"\1**********\2", masked)
    hits = {"身份证": len(re.findall(r"\d{17}[\dXx]", text)),
            "手机号": len(re.findall(r"1[3-9]\d{9}", text)),
            "银行卡": len(re.findall(r"\d{4}\d{10}\d{4}", text))}
    return {"masked": masked, "masked_count": sum(hits.values()), "hits": hits}

REGISTRY = {
    "gov-rag-v1": {"desc": "政务公文RAG检索", "fn": gov_rag_search, "audit": True},
    "gov-doc-check-v1": {"desc": "政务材料预审", "fn": gov_doc_check, "audit": True},
    "gov-archive-v1": {"desc": "政务档案OCR结构化", "fn": gov_archive_ocr, "audit": True},
    "gov-data-mask-v1": {"desc": "政务敏感数据脱敏", "fn": gov_data_mask, "audit": True},
}

AUDIT_LOG = []

def run_operator(op_id: str, *args, **kwargs) -> dict:
    """统一执行入口：调用+审计留痕"""
    if op_id not in REGISTRY:
        return {"success": False, "error": f"未知算子: {op_id}"}
    entry = REGISTRY[op_id]
    try:
        result = entry["fn"](*args, **kwargs)
        record = {"op": op_id, "time": datetime.now().isoformat(), "trace": TRACE, "did": DID, "status": "ok"}
        AUDIT_LOG.append(record)
        return {"success": True, "op": op_id, "result": result, "audit": record}
    except Exception as e:
        AUDIT_LOG.append({"op": op_id, "time": datetime.now().isoformat(), "status": "error", "err": str(e)})
        return {"success": False, "error": str(e)}


if __name__ == "__main__":
    import sys
    print(f"火斗云智·政务AI中台算子注册表 V1.0 | {TRACE} | {DID}")
    print("已注册算子:", ", ".join(f"{k}({v['desc']})" for k, v in REGISTRY.items()))
