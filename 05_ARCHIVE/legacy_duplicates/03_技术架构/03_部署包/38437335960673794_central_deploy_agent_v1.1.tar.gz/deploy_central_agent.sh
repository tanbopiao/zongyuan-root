#!/bin/bash
# 中枢部署拉取服务一键部署脚本
# DID-BR-000002 | Ω₀⊂⊙∞⊂Ω

set -e

echo "========================================"
echo "  中枢部署拉取服务部署脚本 V1.0"
echo "  DID-BR-000002 | Ω₀⊂⊙∞⊂Ω"
echo "========================================"

# 1. 创建目录
echo "[1/5] 创建目录..."
mkdir -p /opt/zongyuan/deployments
mkdir -p /opt/zongyuan/temp
mkdir -p /opt/zongyuan/scripts

# 2. 复制服务文件
echo "[2/5] 复制服务文件..."
cp central_deploy_agent.py /opt/zongyuan/central_deploy_agent.py
chmod +x /opt/zongyuan/central_deploy_agent.py

# 3. 安装systemd服务
echo "[3/5] 安装systemd服务..."
cp central-deploy-agent.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable central-deploy-agent

# 4. 启动服务
echo "[4/5] 启动服务..."
systemctl start central-deploy-agent
sleep 2

# 5. 验证
echo "[5/5] 验证服务状态..."
systemctl status central-deploy-agent --no-pager | head -10

echo ""
echo "========================================"
echo "  ✅ 中枢部署拉取服务部署完成"
echo "  服务状态: $(systemctl is-active central-deploy-agent)"
echo "  日志查看: journalctl -u central-deploy-agent -f"
echo "  手动执行: python3 /opt/zongyuan/central_deploy_agent.py once"
echo "  修复昆仑: python3 /opt/zongyuan/central_deploy_agent.py fix-kunlun"
echo "========================================"
