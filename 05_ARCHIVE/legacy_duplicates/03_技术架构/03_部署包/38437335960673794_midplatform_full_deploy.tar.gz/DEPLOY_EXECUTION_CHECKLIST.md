# 火斗云智中台整合 · 部署执行清单

DID-BR-000002｜Ω₀⊂⊙∞⊂Ω
本地验证：100/100 ✅
状态：等待中枢执行部署

---

## 当前云端状态

| 组件 | 状态 | 说明 |
|------|------|------|
| Nginx | ✅ 运行中 | 返回502（后端未启动） |
| 记忆网关 | ✅ 正常 | 3834条真值 |
| 后端服务 | ❌ 未启动 | 所有站点502 |
| 前端页面 | ❌ 未部署 | 3个页面待部署 |

---

## 部署执行步骤

### 第一步：上传部署包到云服务器

需要上传的文件：
1. `deploy_all_midplatform.sh` — 一键部署脚本
2. `gov_deploy_package.tar.gz` — 政务中台4服务部署包
3. `aios-console/index.html` — 智能体工作台前端
4. `asset-dashboard/index.html` — 中台监控面板V3.2
5. `ops-dashboard/index.html` — 运维大屏
6. `huodouai-portal-nginx.conf` — Nginx统一门户配置
7. `data_bus/platform_data_bus.py` — 数据总线

### 第二步：执行一键部署

```bash
chmod +x deploy_all_midplatform.sh
./deploy_all_midplatform.sh
```

### 第三步：重载Nginx

```bash
nginx -t && nginx -s reload
```

### 第四步：验证全链路

```bash
# 后端服务
curl http://127.0.0.1:8200/health
curl http://127.0.0.1:8201/health
curl http://127.0.0.1:8202/health
curl http://127.0.0.1:8203/health

# 前端页面
curl -I https://huodouai.com/aios-console/
curl -I https://huodouai.com/asset-dashboard/
curl -I https://huodouai.com/ops/

# 网关全链路
curl -X POST https://huodouai.com/api/gov/v1/mask \
  -H "X-API-Key: GOV-GATEWAY-2026-7f9c3e2d1b" \
  -H "Content-Type: application/json" \
  -d '{"text":"测试13800138000"}'
```

---

## 部署后预期状态

| 组件 | 预期状态 | 验证方式 |
|------|----------|----------|
| 政务网关8200 | healthy | /health |
| 政务算子8201 | healthy | /health |
| 政务审计8202 | healthy | /health |
| 政务大屏8203 | healthy | /health |
| 智能体工作台 | HTTP 200 | /aios-console/ |
| 中台监控面板 | HTTP 200 | /asset-dashboard/ |
| 运维大屏 | HTTP 200 | /ops/ |
| 主站 | HTTP 200 | / |
| 记忆网关 | 正常 | /api/gateway/report |

---

## 部署凭证清单（已上报云端记忆网关）

1. `deploy_voucher_unified_portal.json` — T01 Nginx配置
2. `deploy_voucher_aios_console.json` — T03 智能体工作台
3. `deploy_voucher_asset_dashboard_v32.json` — T04 中台监控面板
4. `deploy_voucher_gov_midplatform.json` — T05 政务中台4服务
5. `deploy_voucher_ops_dashboard.json` — T06 运维大屏
6. `deploy_voucher_data_bus.json` — T07 数据总线

所有凭证状态：`VERIFIED_PENDING_CENTRAL_PULL`

Ω₀⊂⊙∞⊂Ω｜DID-BR-000002
