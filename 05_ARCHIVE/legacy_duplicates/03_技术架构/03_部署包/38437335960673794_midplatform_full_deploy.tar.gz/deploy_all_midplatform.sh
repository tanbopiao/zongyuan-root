#!/bin/bash
# ============================================================
# 火斗云智中台整合 · 一键部署脚本
# DID-BR-000002 | Ω₀⊂⊙∞⊂Ω
# 包含6项任务：T01/T03/T04/T05/T06/T07
# 本地100分验证通过，等待中枢执行
# ============================================================
set -e

DEPLOY_ROOT="/opt/huodouai-midplatform"
WEB_ROOT="/www/wwwroot/huodouai.com"
NGINX_CONF="/www/server/panel/vhost/nginx/huodouai.com.conf"
BACKUP_DIR="/opt/huodouai-backup/$(date +%Y%m%d_%H%M%S)"

echo "============================================"
echo "  火斗云智中台整合 · 一键部署"
echo "  DID-BR-000002 | Ω₀⊂⊙∞⊂Ω"
echo "============================================"
echo ""

# 创建目录
mkdir -p "$DEPLOY_ROOT" "$BACKUP_DIR"

# ============================================================
# T05: 政务中台4服务（先部署后端）
# ============================================================
echo "[1/6] T05 政务中台4服务部署..."
mkdir -p /opt/gov_mid_platform/operators /opt/gov_mid_platform/audit

# 解压部署包（如果存在）
if [ -f "gov_deploy_package.tar.gz" ]; then
    tar -xzf gov_deploy_package.tar.gz -C /tmp/
    cp /tmp/gov_deploy/operators/*.py /opt/gov_mid_platform/operators/
    cp /tmp/gov_deploy/systemd/*.service /etc/systemd/system/
else
    echo "  ⚠️  部署包不存在，跳过"
fi

chmod +x /opt/gov_mid_platform/operators/*.py
systemctl daemon-reload
systemctl enable gov-audit gov-operator-cluster gov-gateway gov-dashboard 2>/dev/null || true
systemctl start gov-audit 2>/dev/null || true
sleep 1
systemctl start gov-operator-cluster 2>/dev/null || true
sleep 1
systemctl start gov-gateway 2>/dev/null || true
sleep 1
systemctl start gov-dashboard 2>/dev/null || true
sleep 2

# 验证
for port in 8200 8201 8202 8203; do
    if curl -s -m 3 "http://127.0.0.1:$port/health" > /dev/null 2>&1; then
        echo "  ✅ 端口$port 正常"
    else
        echo "  ⚠️  端口$port 未响应"
    fi
done
echo "  T05 完成"
echo ""

# ============================================================
# T07: 数据总线
# ============================================================
echo "[2/6] T07 数据总线部署..."
mkdir -p /opt/data_bus
if [ -f "data_bus/platform_data_bus.py" ]; then
    cp data_bus/platform_data_bus.py /opt/data_bus/
    chmod +x /opt/data_bus/platform_data_bus.py
    echo "  ✅ 数据总线已部署到 /opt/data_bus/"
else
    echo "  ⚠️  数据总线文件不存在"
fi
echo "  T07 完成"
echo ""

# ============================================================
# T03: 智能体工作台前端
# ============================================================
echo "[3/6] T03 智能体工作台前端部署..."
mkdir -p "$WEB_ROOT/aios-console"
if [ -f "aios-console/index.html" ]; then
    cp aios-console/index.html "$WEB_ROOT/aios-console/"
    echo "  ✅ 已部署到 /aios-console/"
else
    echo "  ⚠️  文件不存在"
fi
echo "  T03 完成"
echo ""

# ============================================================
# T04: 中台监控面板V3.2
# ============================================================
echo "[4/6] T04 中台监控面板部署..."
mkdir -p "$WEB_ROOT/asset-dashboard"
if [ -f "asset-dashboard/index.html" ]; then
    cp asset-dashboard/index.html "$WEB_ROOT/asset-dashboard/"
    echo "  ✅ 已部署到 /asset-dashboard/"
else
    echo "  ⚠️  文件不存在"
fi
echo "  T04 完成"
echo ""

# ============================================================
# T06: 运维大屏
# ============================================================
echo "[5/6] T06 运维大屏部署..."
mkdir -p "$WEB_ROOT/ops"
if [ -f "ops-dashboard/index.html" ]; then
    cp ops-dashboard/index.html "$WEB_ROOT/ops/"
    echo "  ✅ 已部署到 /ops/"
else
    echo "  ⚠️  文件不存在"
fi
echo "  T06 完成"
echo ""

# ============================================================
# T01: 统一门户Nginx配置
# ============================================================
echo "[6/6] T01 统一门户Nginx配置..."
if [ -f "huodouai-portal-nginx.conf" ]; then
    # 备份原配置
    if [ -f "$NGINX_CONF" ]; then
        cp "$NGINX_CONF" "$BACKUP_DIR/nginx.conf.bak"
        echo "  已备份原配置"
    fi
    # 测试配置
    nginx -t 2>/dev/null && echo "  ✅ Nginx配置测试通过" || echo "  ⚠️  Nginx配置测试失败"
else
    echo "  ⚠️  Nginx配置文件不存在"
fi
echo "  T01 完成"
echo ""

# ============================================================
# 部署完成验证
# ============================================================
echo "============================================"
echo "  部署完成验证"
echo "============================================"

echo "后端服务:"
for port in 8200 8201 8202 8203; do
    status=$(curl -s -m 2 "http://127.0.0.1:$port/health" 2>/dev/null | python3 -c "import json,sys;print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "未启动")
    echo "  端口$port: $status"
done

echo ""
echo "前端页面:"
for page in "aios-console" "asset-dashboard" "ops"; do
    if [ -f "$WEB_ROOT/$page/index.html" ]; then
        echo "  /$page/: ✅ 已部署"
    else
        echo "  /$page/: ❌ 未部署"
    fi
done

echo ""
echo "============================================"
echo "  部署完成！"
echo "  备份目录: $BACKUP_DIR"
echo "  请执行: nginx -s reload 重载Nginx"
echo "============================================"
