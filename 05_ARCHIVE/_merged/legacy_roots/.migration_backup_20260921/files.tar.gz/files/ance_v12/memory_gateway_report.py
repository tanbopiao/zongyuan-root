"""
ANCE 记忆网关上报模块 V1.2
执行结果自动上报记忆网关（飞书Base台账 + 本地内核快照），完成深度集成。
复用 session_recovery 的 base-token 通道。
"""
import hashlib
import json
import os
import subprocess
from datetime import datetime
from typing import Dict, Optional

# 记忆网关（飞书Base）配置
BASE_TOKEN = "AM2VbZ064akRc1sFWw3cVAdTnBg"
STATUS_TABLE_ID = "tblJg58700JMNxx7"

TRACE = "Ω₀⊂⊙∞⊂Ω"
DID = "DID-BR-000002"


class MemoryGatewayReporter:
    """执行结果上报记忆网关"""

    def __init__(self, base_token: str = BASE_TOKEN,
                 status_table_id: str = STATUS_TABLE_ID,
                 report_dir: Optional[str] = None):
        self.base_token = base_token
        self.status_table_id = status_table_id
        self.report_dir = report_dir or os.path.expanduser(
            "~/.zongyuan_root/kernel/exec_reports")
        os.makedirs(self.report_dir, exist_ok=True)

    # ---------- 本地内核快照 ----------
    def _save_local_snapshot(self, host: str, command: str, result: Dict) -> str:
        """写入本地内核执行报告"""
        entry = {
            "type": "ANCE_EXEC_REPORT",
            "host": host,
            "command": command,
            "success": result.get("success"),
            "return_code": result.get("return_code"),
            "cache_hit": result.get("cache_hit", False),
            "duration_ms": int(result.get("duration_ms", 0)),
            "stdout_summary": (result.get("stdout") or "")[:500],
            "stderr_summary": (result.get("stderr") or "")[:300],
            "timestamp": datetime.now().isoformat(),
            "did": DID,
            "trace": TRACE,
        }
        # 计算条目哈希
        content = json.dumps(entry, ensure_ascii=False, sort_keys=True)
        entry["hash"] = hashlib.sha256(content.encode()).hexdigest().upper()

        fname = f"ance_exec_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.json"
        fpath = os.path.join(self.report_dir, fname)
        with open(fpath, "w", encoding="utf-8") as f:
            json.dump(entry, f, ensure_ascii=False, indent=1)
        return fpath

    # ---------- 飞书Base台账上报 ----------
    def _report_to_base(self, host: str, command: str, result: Dict) -> bool:
        """执行结果写回飞书Base状态台账（记忆网关）"""
        status_key = "ANCE-EXEC"
        status_value = "SUCCESS" if result.get("success") else "FAILED"
        hash_val = result.get("hash", "")[:32] or "NO_HASH"
        remark = f"{host} | {command[:40]} | rc={result.get('return_code')} | cache={result.get('cache_hit',False)}"

        try:
            # 尝试用 lark-cli 写Base台账（记忆网关通道）
            payload = json.dumps({
                "状态键": status_key,
                "状态值": status_value,
                "哈希校验": hash_val,
                "备注": remark,
                "更新时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }, ensure_ascii=False)
            cmd = [
                "lark-cli", "base", "+record-upsert",
                "--base-token", self.base_token,
                "--table-id", self.status_table_id,
                "--json", payload,
                "--as", "user", "--format", "json",
            ]
            proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            return proc.returncode == 0
        except Exception as e:
            print(f"Base台账上报失败: {e}")
            return False

    # ---------- 统一上报 ----------
    def report(self, host: str, command: str, result: Dict) -> Dict:
        """执行结果上报：本地内核快照 + 飞书Base台账"""
        # 计算时长（若未提供）
        if "duration_ms" not in result:
            result["duration_ms"] = 0
        # 生成本地快照
        local_path = self._save_local_snapshot(host, command, result)
        # 计算用于Base的hash
        result["hash"] = hashlib.sha256(
            (host + command + str(result.get("return_code"))).encode()
        ).hexdigest().upper()
        # Base上报
        base_ok = self._report_to_base(host, command, result)
        return {
            "local_snapshot": local_path,
            "base_reported": base_ok,
            "reported_at": datetime.now().isoformat(),
        }


def make_report_hook(reporter: MemoryGatewayReporter):
    """生成可注册到 BatchSSHExecutor 的上报钩子"""
    def hook(host: str, command: str, result: Dict):
        reporter.report(host, command, result)
    return hook
