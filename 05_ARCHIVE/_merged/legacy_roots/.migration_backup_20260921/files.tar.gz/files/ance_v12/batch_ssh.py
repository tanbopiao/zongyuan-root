"""
ANCE 批量SSH执行器 V1.2
多主机批量执行 + 命令并行执行 + 执行结果缓存 + 命令模板库
依赖：ssh_adapter.SSHAdapter（纯paramiko）
"""
import hashlib
import json
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict, List, Optional, Callable

from .ssh_adapter import SSHAdapter


# ---------- 命令模板库 ----------
class CommandTemplate:
    """命令模板库：按名称取模板并渲染参数"""

    def __init__(self, template_file: Optional[str] = None):
        self._templates: Dict[str, Dict] = {}
        self._template_file = template_file or os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "command_templates.json")
        self._load()

    def _load(self):
        if os.path.exists(self._template_file):
            with open(self._template_file, "r", encoding="utf-8") as f:
                self._templates = json.load(f)

    def list(self) -> List[str]:
        return list(self._templates.keys())

    def get(self, name: str) -> Optional[Dict]:
        return self._templates.get(name)

    def render(self, name: str, params: Optional[Dict] = None) -> str:
        """渲染模板命令，替换 {param} 占位符"""
        tpl = self._templates.get(name)
        if not tpl:
            raise KeyError(f"模板不存在: {name}，可用: {self.list()}")
        command = tpl["command"]
        params = params or {}
        # 校验必填参数
        for p in tpl.get("params", {}):
            if p not in params:
                # 带默认值的参数可选
                continue
        return command.format(**params)

    def get_timeout(self, name: str) -> int:
        tpl = self._templates.get(name, {})
        return int(tpl.get("timeout", 30))


# ---------- 结果缓存 ----------
class ResultCache:
    """执行结果缓存：相同命令TTL内复用"""

    def __init__(self, ttl: int = 300, max_entries: int = 1000):
        self._ttl = ttl
        self._max = max_entries
        self._store: Dict[str, Dict] = {}  # key -> {result, ts}

    def _key(self, host: str, command: str) -> str:
        raw = f"{host}|{command}"
        return hashlib.sha256(raw.encode()).hexdigest()

    def get(self, host: str, command: str):
        key = self._key(host, command)
        entry = self._store.get(key)
        if not entry:
            return None
        if time.time() - entry["ts"] > self._ttl:
            self._store.pop(key, None)
            return None
        return entry["result"]

    def put(self, host: str, command: str, result: Dict):
        key = self._key(host, command)
        self._store[key] = {"result": result, "ts": time.time()}
        # 简单LRU裁剪
        if len(self._store) > self._max:
            oldest = min(self._store, key=lambda k: self._store[k]["ts"])
            self._store.pop(oldest, None)

    def clear(self):
        self._store.clear()

    def size(self) -> int:
        return len(self._store)


# ---------- 主机配置 ----------
class HostConfig:
    """主机连接配置"""

    def __init__(self, host: str, username: str = "root",
                 key_file: Optional[str] = None, password: Optional[str] = None,
                 port: int = 22, timeout: int = 30):
        self.host = host
        self.username = username
        self.key_file = key_file
        self.password = password
        self.port = port
        self.timeout = timeout

    @classmethod
    def from_dict(cls, d: Dict) -> "HostConfig":
        return cls(
            host=d["host"],
            username=d.get("username", "root"),
            key_file=d.get("key_file"),
            password=d.get("password"),
            port=int(d.get("port", 22)),
            timeout=int(d.get("timeout", 30)),
        )


# ---------- 批量执行器 ----------
class BatchSSHExecutor:
    """多主机批量 + 并行 + 缓存 + 模板 执行器"""

    def __init__(self, hosts: List[HostConfig],
                 cache_ttl: int = 300,
                 max_workers: int = 5,
                 templates: Optional[CommandTemplate] = None):
        self.hosts = hosts
        self.cache = ResultCache(ttl=cache_ttl)
        self.max_workers = max_workers
        self.templates = templates or CommandTemplate()
        self._report_hooks: List[Callable] = []

    def add_report_hook(self, hook: Callable):
        """注册结果上报钩子（如记忆网关）"""
        self._report_hooks.append(hook)

    def _run_one(self, hc: HostConfig, command: str, timeout: Optional[int],
                 use_cache: bool) -> Dict:
        # 缓存命中
        if use_cache:
            cached = self.cache.get(hc.host, command)
            if cached is not None:
                return {**cached, "cache_hit": True}

        # 新建连接执行（每主机独立，可并行）
        adapter = SSHAdapter(host=hc.host, username=hc.username,
                             key_file=hc.key_file, password=hc.password,
                             port=hc.port, timeout=hc.timeout)
        result = adapter.execute(command, timeout=timeout)
        adapter.close()

        result["cache_hit"] = False
        if use_cache and result["success"]:
            self.cache.put(hc.host, command, result)

        # 触发上报钩子
        for hook in self._report_hooks:
            try:
                hook(hc.host, command, result)
            except Exception:
                pass
        return result

    def execute(self, command: str, timeout: Optional[int] = None,
                use_cache: bool = True) -> List[Dict]:
        """在全部主机上并行执行同一命令"""
        results = []
        with ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futures = {
                pool.submit(self._run_one, hc, command, timeout, use_cache): hc.host
                for hc in self.hosts
            }
            for fut in as_completed(futures):
                host = futures[fut]
                try:
                    r = fut.result()
                    r["host"] = host
                    results.append(r)
                except Exception as e:
                    results.append({"success": False, "host": host,
                                    "stdout": "", "stderr": str(e),
                                    "return_code": -1, "cache_hit": False})
        return results

    def execute_template(self, template_name: str,
                         params: Optional[Dict] = None,
                         timeout: Optional[int] = None,
                         use_cache: bool = True) -> List[Dict]:
        """按模板渲染后在全部主机执行"""
        command = self.templates.render(template_name, params)
        timeout = timeout or self.templates.get_timeout(template_name)
        return self.execute(command, timeout=timeout, use_cache=use_cache)

    def execute_host_command(self, host: str, command: str,
                             timeout: Optional[int] = None,
                             use_cache: bool = True) -> Optional[Dict]:
        """对单台主机执行（按host匹配）"""
        for hc in self.hosts:
            if hc.host == host:
                r = self._run_one(hc, command, timeout, use_cache)
                r["host"] = host
                return r
        return None

    def summary(self, results: List[Dict]) -> Dict:
        """聚合结果统计"""
        total = len(results)
        success = sum(1 for r in results if r.get("success"))
        failed = total - success
        cache_hits = sum(1 for r in results if r.get("cache_hit"))
        return {
            "total": total,
            "success": success,
            "failed": failed,
            "cache_hits": cache_hits,
            "cache_size": self.cache.size(),
            "success_rate": round(success / total, 3) if total else 0,
        }
