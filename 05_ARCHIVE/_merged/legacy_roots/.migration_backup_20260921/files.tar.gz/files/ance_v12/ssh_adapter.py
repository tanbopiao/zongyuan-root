"""
ANCE SSH适配器 V1.2
纯paramiko实现：完全不依赖系统SSH/SCP客户端，规避Shell转义问题。
- 命令以参数数组传入 exec_command，不经 shell 拼接，无注入风险
- 上传/下载走 SFTP（paramiko.SFTPClient），不依赖系统 scp
- 向后兼容：保留原 execute / execute_batch / upload / download / connect / close 接口
"""
import time
import hashlib
from typing import Optional, List, Dict

# 依赖必须显式声明；paramiko未安装时给出明确错误而非静默回退
_REQUIRE_PARAMIKO = None


def _get_paramiko():
    global _REQUIRE_PARAMIKO
    if _REQUIRE_PARAMIKO is None:
        import paramiko
        _REQUIRE_PARAMIKO = paramiko
    return _REQUIRE_PARAMIKO


class SSHAdapter:
    """纯paramiko SSH远程执行适配器"""

    def __init__(self, host: str, username: str = "root",
                 key_file: Optional[str] = None, password: Optional[str] = None,
                 port: int = 22, timeout: int = 30,
                 banner_timeout: Optional[int] = None,
                 auth_timeout: Optional[int] = None):
        self.host = host
        self.username = username
        self.key_file = key_file
        self.password = password
        self.port = port
        self.timeout = timeout
        self._client = None
        self._sftp = None
        # paramiko 专属连接参数
        self._banner_timeout = banner_timeout or timeout
        self._auth_timeout = auth_timeout or timeout

    # ---------- 连接 ----------
    def connect(self) -> bool:
        """建立paramiko SSH连接（支持密钥/密码）"""
        try:
            paramiko = _get_paramiko()
            self._client = paramiko.SSHClient()
            self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

            connect_kwargs = {
                "hostname": self.host,
                "port": self.port,
                "username": self.username,
                "timeout": self.timeout,
                "banner_timeout": self._banner_timeout,
                "auth_timeout": self._auth_timeout,
                "allow_agent": True,
                "look_for_keys": True,
            }
            if self.key_file:
                connect_kwargs["key_filename"] = self.key_file
            elif self.password:
                connect_kwargs["password"] = self.password

            self._client.connect(**connect_kwargs)
            return True
        except Exception as e:
            # 明确报错，不静默回退 subprocess（V1.2 根因修复）
            print(f"SSH连接失败({self.host}): {e}")
            self._client = None
            return False

    def is_connected(self) -> bool:
        return self._client is not None

    # ---------- 命令执行（无shell转义） ----------
    def execute(self, command: str, timeout: Optional[int] = None) -> Dict:
        """执行远程命令——参数直接传给 exec_command，不经shell拼接，杜绝转义/注入"""
        if not self._client:
            if not self.connect():
                return {"success": False, "stdout": "", "stderr": "连接失败",
                        "return_code": -1, "host": self.host}

        timeout = timeout or self.timeout
        try:
            # 关键：command 作为单个 argv 传给远端 shell，非本地拼接
            stdin, stdout, stderr = self._client.exec_command(command, timeout=timeout)
            out = stdout.read().decode("utf-8", errors="replace")
            err = stderr.read().decode("utf-8", errors="replace")
            code = stdout.channel.recv_exit_status()
            return {
                "success": code == 0,
                "stdout": out,
                "stderr": err,
                "return_code": code,
                "host": self.host,
            }
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e),
                    "return_code": -1, "host": self.host}

    def execute_batch(self, commands: List[str], delay: float = 0.5,
                      stop_on_error: bool = True) -> List[Dict]:
        """串行批量执行命令"""
        results = []
        for cmd in commands:
            result = self.execute(cmd)
            results.append(result)
            if stop_on_error and not result["success"]:
                break
            time.sleep(delay)
        return results

    # ---------- SFTP 传输（无scp依赖） ----------
    def _get_sftp(self):
        """惰性获取SFTP客户端"""
        if self._sftp is None:
            if not self._client:
                self.connect()
            self._sftp = self._client.open_sftp()
        return self._sftp

    def upload(self, local_path: str, remote_path: str) -> bool:
        """SFTP上传文件（不依赖系统scp）"""
        try:
            sftp = self._get_sftp()
            sftp.put(local_path, remote_path)
            return True
        except Exception as e:
            print(f"SFTP上传失败: {e}")
            return False

    def download(self, remote_path: str, local_path: str) -> bool:
        """SFTP下载文件（不依赖系统scp）"""
        try:
            sftp = self._get_sftp()
            sftp.get(remote_path, local_path)
            return True
        except Exception as e:
            print(f"SFTP下载失败: {e}")
            return False

    def mkdir(self, remote_path: str, mode: int = 0o755) -> bool:
        """SFTP创建远程目录（含父目录）"""
        try:
            sftp = self._get_sftp()
            parts = remote_path.strip("/").split("/")
            cur = ""
            for p in parts:
                cur += "/" + p
                try:
                    sftp.stat(cur)
                except FileNotFoundError:
                    sftp.mkdir(cur, mode)
            return True
        except Exception as e:
            print(f"SFTP创建目录失败: {e}")
            return False

    # ---------- 连接签名/工具 ----------
    def command_hash(self, command: str) -> str:
        """命令哈希（供缓存使用）"""
        return hashlib.sha256(command.encode()).hexdigest()

    def close(self):
        """关闭连接"""
        if self._sftp:
            try:
                self._sftp.close()
            except Exception:
                pass
            self._sftp = None
        if self._client:
            try:
                self._client.close()
            except Exception:
                pass
            self._client = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *args):
        self.close()
