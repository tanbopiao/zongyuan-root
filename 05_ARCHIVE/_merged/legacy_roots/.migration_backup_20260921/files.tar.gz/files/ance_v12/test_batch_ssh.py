"""
ANCE V1.2 单元测试：转义 / 缓存 / 模板 / 多主机并行 / 上报
运行：python3 -m pytest test_batch_ssh.py -v  （或 python3 test_batch_ssh.py）
"""
import os
import sys
import json
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from adapters.ssh_adapter import SSHAdapter
from adapters.batch_ssh import CommandTemplate, ResultCache, HostConfig, BatchSSHExecutor
from adapters.memory_gateway_report import MemoryGatewayReporter


class TestSSHAdapterNoShell(unittest.TestCase):
    """验证纯paramiko、无subprocess转义"""

    def test_no_subprocess_ssh_scp(self):
        """源码中不得再出现 subprocess ssh/scp 拼接"""
        src = open(os.path.join(os.path.dirname(__file__), "adapters", "ssh_adapter.py")).read()
        self.assertNotIn("subprocess.run", src, "不应再使用 subprocess 执行ssh")
        self.assertNotIn("ssh -o", src, "不应再拼接系统ssh命令")
        self.assertNotIn("scp -o", src, "不应再依赖系统scp")
        self.assertIn("open_sftp", src, "应使用SFTP传输")
        self.assertIn("exec_command", src, "应使用paramiko exec_command")

    def test_import_ok(self):
        a = SSHAdapter(host="127.0.0.1")
        self.assertFalse(a.is_connected())
        self.assertEqual(a.command_hash("uptime"), a.command_hash("uptime"))


class TestCommandTemplate(unittest.TestCase):
    """命令模板库"""

    def setUp(self):
        self.tpl = CommandTemplate()

    def test_list_has_templates(self):
        names = self.tpl.list()
        self.assertIn("health_check", names)
        self.assertIn("service_status", names)
        self.assertGreaterEqual(len(names), 5)

    def test_render_param(self):
        cmd = self.tpl.render("service_status", {"service_name": "nginx"})
        self.assertIn("nginx", cmd)
        self.assertNotIn("{service_name}", cmd)

    def test_render_missing_template(self):
        with self.assertRaises(KeyError):
            self.tpl.render("not_exist_template")


class TestResultCache(unittest.TestCase):
    """执行结果缓存"""

    def test_cache_hit_and_miss(self):
        cache = ResultCache(ttl=300)
        r = {"success": True, "return_code": 0}
        self.assertIsNone(cache.get("h1", "cmd1"))
        cache.put("h1", "cmd1", r)
        hit = cache.get("h1", "cmd1")
        self.assertEqual(hit["return_code"], 0)
        # 不同host不共享
        self.assertIsNone(cache.get("h2", "cmd1"))

    def test_cache_expiry(self):
        cache = ResultCache(ttl=0)  # 立即过期
        cache.put("h", "c", {"success": True})
        self.assertIsNone(cache.get("h", "c"))


class TestBatchExecutor(unittest.TestCase):
    """多主机 + 缓存 逻辑（不真实连接，mock execute）"""

    def test_summary(self):
        hc = [HostConfig(host="a"), HostConfig(host="b")]
        ex = BatchSSHExecutor(hosts=hc, max_workers=2)
        results = [
            {"success": True, "cache_hit": False, "return_code": 0},
            {"success": False, "cache_hit": False, "return_code": 1},
        ]
        s = ex.summary(results)
        self.assertEqual(s["total"], 2)
        self.assertEqual(s["success"], 1)
        self.assertEqual(s["failed"], 1)


class TestReporter(unittest.TestCase):
    """记忆网关上报模块（本地快照）"""

    def test_local_snapshot(self):
        rep = MemoryGatewayReporter(report_dir="/tmp/ance_test_reports")
        path = rep._save_local_snapshot("h1", "echo x",
                                        {"success": True, "return_code": 0})
        self.assertTrue(os.path.exists(path))
        with open(path) as f:
            data = json.load(f)
        self.assertEqual(data["host"], "h1")
        self.assertTrue(data["hash"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
