"""
ANCE 无SSH通讯协议 TLS 支持
为 9120 网关提供 HTTPS 加密传输。
- 自签证书生成（测试/内网）
- 服务端 ssl 包装（HTTPServer → HTTPS）
- 客户端 HTTPS 支持（CommClient 已用 urllib，支持 https）

溯源标识：Ω₀⊂⊙∞⊂Ω | DID-BR-000002
"""
import ipaddress
import os
import ssl
import subprocess
from http.server import HTTPServer
from typing import Optional, Tuple


def generate_self_signed(cert_dir: str, common_name: str = "comm-gateway-9120",
                         days: int = 825) -> Tuple[str, str]:
    """生成自签证书（openssl），返回 (cert_path, key_path)"""
    os.makedirs(cert_dir, exist_ok=True)
    cert_path = os.path.join(cert_dir, "server.crt")
    key_path = os.path.join(cert_dir, "server.key")
    if os.path.exists(cert_path) and os.path.exists(key_path):
        return cert_path, key_path
    cmd = [
        "openssl", "req", "-x509", "-newkey", "rsa:2048",
        "-keyout", key_path, "-out", cert_path,
        "-days", str(days), "-nodes",
        "-subj", f"/CN={common_name}",
        "-addext", "subjectAltName=DNS:localhost,IP:127.0.0.1",
    ]
    subprocess.run(cmd, check=True, capture_output=True)
    # 权限收紧
    os.chmod(key_path, 0o600)
    return cert_path, key_path


def wrap_tls(server: HTTPServer, certfile: str, keyfile: str,
             cert_dir: Optional[str] = None) -> HTTPServer:
    """把 HTTPServer 包装为 TLS（HTTPS）"""
    if cert_dir and (not certfile or not keyfile):
        certfile, keyfile = generate_self_signed(cert_dir)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(certfile, keyfile)
    server.socket = ctx.wrap_socket(server.socket, server_side=True)
    return server


def in_cidr(ip: str, cidrs) -> bool:
    """判断 IP 是否在某 CIDR 网段列表内"""
    if not cidrs:
        return False
    try:
        addr = ipaddress.ip_address(ip)
        for c in cidrs:
            try:
                net = ipaddress.ip_network(c, strict=False)
                if addr in net:
                    return True
            except ValueError:
                continue
    except ValueError:
        return False
    return False
