# 无SSH通讯协议 COMM-PROTO-V1.0 设计文档
溯源标识：Ω₀⊂⊙∞⊂Ω | DID-BR-000002 | 同源节点 Ω-TAN-7-001 | 火斗云智 AIOS 内部技术文档

## 一、协议定位
基于 **9120 记忆网关双向通道**（审批已通过）构建的 HTTP/JSON 远程通讯协议，**完全替代 SSH 连接**。
与同源协议（HOMO-PROTO-V1）及云内核 API 协议（API-PROTO-V1.0）同源共栈，沿用 HMAC-SHA256 + 时间戳防重放体系。

## 二、与 SSH 方案对比
| 维度 | SSH方案（V1.2） | 无SSH通讯协议（本协议） |
|---|---|---|
| 传输通道 | SSH（22端口） | HTTP/JSON（9120网关） |
| 鉴权 | 密钥/密码 | HMAC-SHA256 签名 + 时间戳窗口 |
| 命令传输 | 命令字符串 | 命令 + argv 数组分离（JSON封装） |
| 注入风险 | 需防shell转义 | 无shell拼接，天然防注入 |
| 双向 | 单向执行 | 命令下发 + 结果上报 双向 |
| 握手点 | 每台独立SSH | 唯一9120记忆网关（双隔离公理AAB） |

## 三、协议核心设计

### 1. 统一消息结构
- 命令与参数分离：`command`(可执行文件/模板名) + `argv`(参数数组)，杜绝 shell 拼接
- 复合命令（&& / || / |）由受限解析器拆分，逐命令执行，有限白名单，禁止重定向/子shell/变量展开

### 2. 签名与防重放
- HMAC-SHA256：`signature = HMAC(secret, timestamp|nonce|canonical_body)`
- 时间戳窗口 300s，防重放
- `hmac.compare_digest` 防时序攻击

### 3. 双向通道
- 命令下发：client → 9120 网关 `/comm`（exec/template/ping/report）
- 结果上报：服务端执行后写本地内核快照 + 记忆网关（受控写入侧）

### 4. 接口兼容
- `RemoteHTTPExecutor` 与 `BatchSSHExecutor` 同接口：execute / execute_template / summary
- 可无缝替换 SSH 执行后端

## 四、模块清单
| 文件 | 说明 |
|---|---|
| `adapters/comm_protocol/__init__.py` | 协议核心：签名/防重放/统一消息/客户端/服务端基类 |
| `adapters/comm_protocol/gateway_server.py` | 9120网关服务端：签名校验+受限命令执行+模板+缓存+上报 |
| `adapters/comm_protocol/remote_executor.py` | 无SSH远程执行器（batch兼容） |

## 五、安全设计
- 命令经 JSON 封装传输，服务端 `shell=False` 执行，杜绝注入
- 复合命令白名单分隔符（&&/||/|），分号/重定向/子shell被拒
- 单测验证：参数注入/分号注入均不产生副作用文件
- HMAC 签名失败返回 401，篡改/过期拒绝

## 六、测试结果
- 单元测试 17/17 通过（OK）
- 端到端演示通过：ping / exec / template(health_check复合) / RemoteHTTPExecutor批量

## 七、部署方式
```bash
# 服务端（每台目标机启动，或用 systemd 常驻）
cd ai-native-ops
python3 -m adapters.comm_protocol.gateway_server --port 9120 --secret <共享密钥>

# 客户端（主控下发命令）
from adapters.comm_protocol.remote_executor import RemoteHTTPExecutor
ex = RemoteHTTPExecutor(["http://目标机:9120"], "<共享密钥>")
ex.execute("/bin/echo hello")
```
