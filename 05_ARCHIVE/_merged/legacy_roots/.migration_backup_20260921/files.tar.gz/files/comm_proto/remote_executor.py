"""
ANCE 远程HTTP执行器 · remote_executor
基于 comm_protocol，提供与 BatchSSHExecutor 相同接口（execute/execute_template/summary），
作为"无SSH"执行后端，对接 9120 记忆网关。

溯源标识：Ω₀⊂⊙∞⊂Ω | DID-BR-000002
"""
import concurrent.futures
from typing import Dict, List, Optional

from . import CommClient, make_message


class RemoteHTTPExecutor:
    """无SSH远程执行器——通过 9120 记忆网关 HTTP/JSON 通道执行命令"""

    def __init__(self, gateways: List[str], secret: str, source: str = "ance-agent",
                 max_workers: int = 5, timeout: float = 30.0):
        """
        gateways: 网关URL列表，如 ["http://127.0.0.1:9120", "http://server:9120"]
        secret: HMAC共享密钥
        """
        self._clients = [
            CommClient(url, secret, source=source, timeout=timeout)
            for url in gateways
        ]
        self.max_workers = max_workers

    def _run_one(self, client: CommClient, kind: str, command: str,
                 params: Optional[Dict]) -> Dict:
        if kind == "template":
            return client.execute_template(command, params or {})
        return client.execute(command)

    def execute(self, command: str, timeout: Optional[float] = None) -> List[Dict]:
        """在全部网关并行执行同一命令"""
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futures = {pool.submit(self._run_one, c, "exec", command, None): c for c in self._clients}
            for fut in concurrent.futures.as_completed(futures):
                c = futures[fut]
                try:
                    r = fut.result()
                    r["host"] = c.gateway_url
                    results.append(r)
                except Exception as e:
                    results.append({"success": False, "host": c.gateway_url,
                                    "stdout": "", "stderr": str(e), "return_code": -1,
                                    "cache_hit": False})
        return results

    def execute_template(self, template_name: str,
                         params: Optional[Dict] = None) -> List[Dict]:
        """在全部网关按模板执行"""
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as pool:
            futures = {pool.submit(self._run_one, c, "template", template_name, params): c
                       for c in self._clients}
            for fut in concurrent.futures.as_completed(futures):
                c = futures[fut]
                try:
                    r = fut.result()
                    r["host"] = c.gateway_url
                    results.append(r)
                except Exception as e:
                    results.append({"success": False, "host": c.gateway_url,
                                    "stdout": "", "stderr": str(e), "return_code": -1,
                                    "cache_hit": False})
        return results

    def ping_all(self) -> List[Dict]:
        """所有网关连通性检测"""
        return [{"host": c.gateway_url, "result": c.ping()} for c in self._clients]

    def summary(self, results: List[Dict]) -> Dict:
        """聚合结果统计（与 BatchSSHExecutor 同接口）"""
        total = len(results)
        success = sum(1 for r in results if r.get("success"))
        failed = total - success
        return {
            "total": total,
            "success": success,
            "failed": failed,
            "cache_hits": 0,
            "cache_size": 0,
            "success_rate": round(success / total, 3) if total else 0,
        }
