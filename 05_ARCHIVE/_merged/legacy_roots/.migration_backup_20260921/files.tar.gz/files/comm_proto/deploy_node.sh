#!/bin/bash
# ============================================================
# 无SSH通讯协议 COMM-PROTO-V1.0 · 全域同源节点部署脚本
# 用途：把 9120 记忆网关部署到任意同源节点（云内核主控/工作/边缘）
# 溯源：Ω₀⊂⊙∞⊂Ω | DID-BR-000002 | 同源节点 Ω-TAN-7-001
# ============================================================
set -e

# --- 配置 ---
SRC_DIR="$(cd "$(dirname "$0")/../.." && pwd)"   # ai-native-ops
DEST_DIR="${DEST_DIR:-/opt/ZONGYUAN-ROOT/ai-native-ops}"  # 目标机部署目录
GATEWAY_MOD="adapters.comm_protocol.gateway_server"
SECRET_FILE="${SECRET_FILE:-$HOME/.zongyuan_root/kernel/comm_gateway_secret.json}"

echo "======================================================"
echo "  COMM-PROTO-V1.0 同源节点部署"
echo "  源: $SRC_DIR"
echo "  目标: $DEST_DIR"
echo "======================================================"

# 1. 拷贝协议模块
echo "[1/5] 拷贝协议模块..."
mkdir -p "$DEST_DIR/adapters/comm_protocol"
cp -r "$SRC_DIR/adapters/comm_protocol/." "$DEST_DIR/adapters/comm_protocol/"
cp "$SRC_DIR/adapters/batch_ssh.py" "$DEST_DIR/adapters/" 2>/dev/null || true
cp "$SRC_DIR/adapters/command_templates.json" "$DEST_DIR/adapters/" 2>/dev/null || true

# 2. 生成/同步密钥
echo "[2/5] 密钥配置..."
if [ ! -f "$SECRET_FILE" ]; then
  echo "  错误: 未找到密钥文件 $SECRET_FILE"
  echo "  请先在主控执行密钥轮换/生成"
  exit 1
fi
echo "  密钥就绪: $(python3 -c "import json;print(json.load(open('$SECRET_FILE'))['secret_fingerprint'])")"

# 3. 创建 systemd 服务（如可用）
echo "[3/5] systemd 服务..."
if command -v systemctl >/dev/null 2>&1; then
  cat > /tmp/comm-gateway-9120.service <<SVC
[Unit]
Description=ANCE 9120 Memory Gateway (COMM-PROTO-V1.0)
After=network.target
[Service]
Type=simple
WorkingDirectory=$DEST_DIR
ExecStart=/usr/bin/python3 -m $GATEWAY_MOD --port 9120 --host 127.0.0.1 --secret "\$(python3 -c "import json,os;print(json.load(open(os.path.expanduser('$SECRET_FILE')))['secret'])")"
Restart=on-failure
[Install]
WantedBy=multi-user.target
SVC
  echo "  服务单元已生成 /tmp/comm-gateway-9120.service（用sudo安装）"
else
  echo "  无systemd，跳过"
fi

# 4. 密钥轮换定时（90天计划）
echo "[4/5] 轮换计划..."
cat > /tmp/comm_secret_rotate_check.sh <<'CHK'
#!/bin/bash
cd /home/user/ZONGYUAN-ROOT/ai-native-ops
python3 -m adapters.comm_protocol.rotate_secret --due-check || python3 -m adapters.comm_protocol.rotate_secret --rotate
CHK
chmod +x /tmp/comm_secret_rotate_check.sh
echo "  轮换检查脚本已生成（建议cron: 0 3 * * *）"

# 5. 验证
echo "[5/5] 部署验证..."
cd "$DEST_DIR"
python3 -c "import adapters.comm_protocol, adapters.comm_protocol.gateway_server, adapters.comm_protocol.rotate_secret; print('✅ 协议模块导入成功')"

echo ""
echo "======================================================"
echo "✅ 部署完成。后续步骤："
echo "  1. 目标机启动: cd $DEST_DIR && python3 -m $GATEWAY_MOD --port 9120"
echo "  2. 配TLS: --tls --cert-dir <证书目录>"
echo "  3. 配白名单: --allow-host 10.0.0.0/8 --allow-host 192.168.1.0/24"
echo "  4. 设cron轮换: 0 3 * * * /tmp/comm_secret_rotate_check.sh"
echo "  5. 主控连接: RemoteHTTPExecutor(['http://<节点>:9120'], '<密钥>')"
echo "======================================================"
