"""
ANCE 无SSH通讯协议 V1.0 单元测试
验证：签名/防重放 / 命令JSON封装（无shell注入） / 客户端-服务端双向通信 / 模板 / 缓存
运行：python3 -m pytest test_comm_protocol.py -v （或 python3 test_comm_protocol.py）
"""
import json
import os
import sys
import threading
import time
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__)))

from adapters.comm_protocol import (
    CommClient, CommServer, compute_signature, verify_signature,
    make_message, make_response, TraceMixin,
)
from adapters.comm_protocol.gateway_server import (
    CommGatewayServer, _ExecCommand, start_server,
)
from adapters.comm_protocol.remote_executor import RemoteHTTPExecutor

SECRET = "test-secret-9120"


class TestSignature(unittest.TestCase):
    """HMAC签名 + 防重放"""

    def test_sign_verify_ok(self):
        body = {"a": 1, "b": "x"}
        ts = str(time.time())
        nonce = "abc123"
        sig = compute_signature(SECRET, body, ts, nonce)
        self.assertTrue(verify_signature(SECRET, body, ts, nonce, sig))

    def test_tamper_rejected(self):
        body = {"a": 1}
        ts = str(time.time())
        nonce = "n1"
        sig = compute_signature(SECRET, body, ts, nonce)
        # 篡改body
        self.assertFalse(verify_signature(SECRET, {"a": 2}, ts, nonce, sig))

    def test_wrong_secret_rejected(self):
        body = {"a": 1}
        ts = str(time.time())
        nonce = "n1"
        sig = compute_signature(SECRET, body, ts, nonce)
        self.assertFalse(verify_signature("other", body, ts, nonce, sig))

    def test_replay_rejected(self):
        """过期时间戳被拒"""
        body = {"a": 1}
        old_ts = str(time.time() - 1000)  # 16分钟前
        nonce = "n1"
        sig = compute_signature(SECRET, body, old_ts, nonce)
        self.assertFalse(verify_signature(SECRET, body, old_ts, nonce, sig, replay_window=300))


class TestMessageStructure(unittest.TestCase):
    """命令JSON封装——command与argv分离，无shell拼接"""

    def test_exec_message(self):
        m = make_message("exec", "node-1", command="/bin/echo", argv=["hello"])
        self.assertEqual(m["type"], "exec")
        self.assertEqual(m["command"], "/bin/echo")
        self.assertEqual(m["argv"], ["hello"])
        # 命令与参数分离，无拼接
        self.assertNotIn(";", json.dumps([m["command"], m["argv"]]))

    def test_trace_present(self):
        m = make_message("ping", "node")
        self.assertEqual(m["did"], TraceMixin.DID)
        self.assertEqual(m["trace"], TraceMixin.TRACE)


class TestServerValidation(unittest.TestCase):
    """服务端签名校验"""

    def setUp(self):
        self.server = CommGatewayServer(SECRET)

    def test_valid_request_accepted(self):
        body = make_message("ping", "test")
        ts = str(time.time())
        nonce = "abc"
        sig = compute_signature(SECRET, body, ts, nonce)
        headers = {"X-ZR-Hmac-Signature": sig, "X-ZR-Timestamp": ts, "X-ZR-Nonce": nonce,
                   "X-ZR-Protocol-Version": "COMM-PROTO-V1.0"}
        resp = self.server.handle(body, headers)
        self.assertTrue(resp["success"])
        self.assertTrue(resp["data"]["pong"])

    def test_invalid_signature_rejected(self):
        body = make_message("ping", "test")
        ts = str(time.time())
        sig = compute_signature("wrong", body, ts, "n")
        headers = {"X-ZR-Hmac-Signature": sig, "X-ZR-Timestamp": ts, "X-ZR-Nonce": "n",
                   "X-ZR-Protocol-Version": "COMM-PROTO-V1.0"}
        resp = self.server.handle(body, headers)
        self.assertFalse(resp["success"])
        self.assertEqual(resp["status_code"], 401)


class TestLocalExec(unittest.TestCase):
    """本地命令执行（无shell注入）"""

    def test_echo(self):
        r = _ExecCommand.run("/bin/echo", ["comm_protocol_ok"])
        self.assertTrue(r["success"])
        self.assertIn("comm_protocol_ok", r["stdout"])

    def test_no_shell_injection(self):
        """参数中含shell元字符不得执行注入"""
        r = _ExecCommand.run("/bin/echo", ["safe; touch /tmp/pwned"])
        self.assertTrue(r["success"])
        # 未创建注入文件
        self.assertFalse(os.path.exists("/tmp/pwned"))

    def test_unknown_command(self):
        r = _ExecCommand.run("/nonexistent_cmd_xyz")
        self.assertFalse(r["success"])
        self.assertEqual(r["return_code"], 127)

    def test_semicolon_injection_rejected(self):
        """分号注入不得执行第二条命令"""
        r = _ExecCommand.run("/bin/echo safe; touch /tmp/pwned_semicolon")
        self.assertTrue(r["success"])
        self.assertFalse(os.path.exists("/tmp/pwned_semicolon"))

    def test_composite_and(self):
        """&& 复合命令正常执行"""
        r = _ExecCommand.run("/bin/echo a && /bin/echo b")
        self.assertTrue(r["success"])
        self.assertIn("b", r["stdout"])


class TestEndToEnd(unittest.TestCase):
    """客户端-服务端双向通信（本地真实HTTP）"""

    @classmethod
    def setUpClass(cls):
        cls.server = start_server(SECRET, port=9121, host="127.0.0.1")
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        time.sleep(0.5)

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def test_ping(self):
        c = CommClient("http://127.0.0.1:9121", SECRET)
        r = c.ping()
        self.assertTrue(r.get("success"))
        self.assertTrue(r["data"]["pong"])

    def test_exec_echo(self):
        c = CommClient("http://127.0.0.1:9121", SECRET)
        r = c.execute("/bin/echo comm_http_ok")
        self.assertTrue(r["success"])
        self.assertIn("comm_http_ok", r["stdout"])

    def test_remote_executor_multi(self):
        ex = RemoteHTTPExecutor(["http://127.0.0.1:9121"], SECRET)
        results = ex.execute("/bin/echo multi")
        self.assertEqual(len(results), 1)
        s = ex.summary(results)
        self.assertEqual(s["total"], 1)
        self.assertEqual(s["success"], 1)

    def test_template_via_gateway(self):
        c = CommClient("http://127.0.0.1:9121", SECRET)
        # health_check 模板
        r = c.send(make_message("template", "test", command="health_check"))
        self.assertTrue(r.get("success"))
        self.assertIn("HEALTH_OK", r.get("data", {}).get("stdout", ""))


if __name__ == "__main__":
    unittest.main(verbosity=2)
