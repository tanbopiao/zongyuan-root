"""
ANCE 9120 记忆网关服务端 · comm_gateway_server
基于 comm_protocol 的 HTTP/JSON 服务端，监听 9120，接收签名命令并在本地执行。

功能：
  - HMAC 签名校验 + 时间戳防重放
  - 命令本地执行（subprocess list 形式，无 shell 拼接）
  - 模板命令渲染执行（复用 command_templates.json）
  - 结果缓存（复用 ResultCache）
  - 双向上报：执行结果写本地内核快照 + 飞书Base台账（记忆网关）
  - 与 BatchSSHExecutor 对接：可作为"无 SSH"执行后端

溯源标识：Ω₀⊂⊙∞⊂Ω | DID-BR-000002
"""
import json
import os
import subprocess
import sys
import threading
import time
from collections import defaultdict
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Dict, Optional, List

from . import (
    CommServer, make_response, TraceMixin,
    HDR_PROTOCOL, HDR_SIGNATURE, HDR_TIMESTAMP, HDR_NONCE, HDR_SOURCE, HDR_TRACE,
)
from ..batch_ssh import CommandTemplate, ResultCache

DEFAULT_PORT = 9120
TRACE = "Ω₀⊂⊙∞⊂Ω"


class RateLimiter:
    """滑动窗口限流器：按来源IP + 窗口计数"""

    def __init__(self, max_per_window: int = 120, window_seconds: int = 60):
        self.max = max_per_window
        self.window = window_seconds
        self._counts: Dict[str, List[float]] = defaultdict(list)
        self._lock = threading.Lock()

    def allow(self, key: str) -> bool:
        now = time.time()
        with self._lock:
            ts_list = self._counts[key]
            # 清理窗口外记录
            cutoff = now - self.window
            self._counts[key] = [t for t in ts_list if t > cutoff]
            if len(self._counts[key]) >= self.max:
                return False
            self._counts[key].append(now)
            return True


def _flatten(groups: list) -> list:
    """把多个 token 组展平为单个 argv 列表（命令段内参数）"""
    out = []
    for g in groups:
        out.extend(g)
    return out


class _ExecCommand:
    """在服务端本地执行命令（无 shell 注入：argv 数组 + 受限复合命令解析）"""

    # 允许的复合分隔符（有限白名单，杜绝任意 shell 语法注入）
    _SEPARATORS = ("&&", "||", "|")

    @staticmethod
    def run(command: str, argv: Optional[list] = None,
            timeout: Optional[float] = None) -> Dict:
        """subprocess list 形式执行，绝不经完整 shell 拼接。
        复合命令（&& / || / |）由受限解析器拆分为子命令序列，逐个执行。"""
        timeout = timeout or 60
        if argv:
            # 若带参数，command 为可执行文件路径（单命令）
            return _ExecCommand._run_single(command, list(argv), timeout)
        # 无参数：解析复合命令
        segments = _ExecCommand._split_safe(command)
        if len(segments) == 1:
            return _ExecCommand._run_single(segments[0][0], segments[0][1:], timeout)
        # 复合命令：按顺序执行，&& 遇错停，|| 遇对停
        return _ExecCommand._run_sequence(segments, timeout)

    @staticmethod
    def _split_safe(command: str) -> list:
        """受限解析：按允许的分隔符拆分，返回 [(exe, argv...), ...]
        不允许重定向/子shell/变量展开等危险语法，仅支持命令拼接。
        每个命令段用 shlex 安全分词为 argv 列表。"""
        import shlex
        parts = [p.strip() for p in command.replace("&&", "\x00&&\x00")
                 .replace("||", "\x00||\x00").replace("|", "\x00|\x00")
                 .split("\x00") if p.strip()]
        segments = []
        current = []
        for p in parts:
            if p in ("&&", "||", "|"):
                if current:
                    segments.append(_flatten(current))
                segments.append(p)
                current = []
            else:
                # 安全分词当前段为 argv 列表
                try:
                    tokens = shlex.split(p)
                except ValueError:
                    tokens = [p]
                if tokens:
                    current.append(tokens)
        if current:
            segments.append(_flatten(current))
        return segments

    @staticmethod
    def _run_sequence(segments: list, timeout: float) -> Dict:
        """执行命令序列（&& || | 语义）"""
        last = None
        stop_on = None  # None=正常顺序; "&&"遇错停; "||"遇对停
        i = 0
        while i < len(segments):
            seg = segments[i]
            if isinstance(seg, list):
                exe = seg[0]
                args = seg[1:]
                last = _ExecCommand._run_single(exe, args, timeout)
                if stop_on == "&&" and not last["success"]:
                    break
                if stop_on == "||" and last["success"]:
                    break
                stop_on = None
            else:  # 分隔符
                stop_on = seg
            i += 1
        if last is None:
            return {"success": False, "stdout": "", "stderr": "空命令",
                    "return_code": 2}
        return last

    @staticmethod
    def _run_single(exe: str, args: list, timeout: float) -> Dict:
        """执行单个命令（argv 数组，无 shell）"""
        try:
            proc = subprocess.run(
                [exe] + args, capture_output=True, text=True, timeout=timeout,
                shell=False,  # 关键：禁 shell，杜绝注入
            )
            return {
                "success": proc.returncode == 0,
                "stdout": proc.stdout,
                "stderr": proc.stderr,
                "return_code": proc.returncode,
            }
        except FileNotFoundError:
            return {"success": False, "stdout": "", "stderr": f"命令不存在: {exe}",
                    "return_code": 127}
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": f"执行超时({timeout}s)",
                    "return_code": 124}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "return_code": -1}


class CommGatewayServer(CommServer):
    """9120 记忆网关服务端"""

    # 命令白名单（可执行文件 basename），默认只允许安全运维命令
    DEFAULT_COMMAND_ALLOWLIST = [
        "uptime", "free", "df", "ps", "echo", "cat", "tail", "head",
        "systemctl", "docker", "nginx", "ss", "netstat", "ls", "who",
        "date", "hostname", "uname", "top", "vmstat", "mpstat", "du",
        "curl", "wget", "ping",
    ]

    def __init__(self, secret: str, replay_window: int = 300,
                 report_dir: Optional[str] = None,
                 allowed_hosts: Optional[List[str]] = None,
                 command_allowlist: Optional[List[str]] = None,
                 rate_limit_per_min: int = 120):
        super().__init__(secret, replay_window)
        self.templates = CommandTemplate()
        self.cache = ResultCache(ttl=300)
        self.report_dir = report_dir or os.path.expanduser(
            "~/.zongyuan_root/kernel/comm_reports")
        os.makedirs(self.report_dir, exist_ok=True)
        # ---- 安全加固 ----
        self.allowed_hosts = set(allowed_hosts or [])  # IP白名单，空=允许所有（由签名保护）
        self.command_allowlist = set(
            command_allowlist or self.DEFAULT_COMMAND_ALLOWLIST)
        self.rate_limiter = RateLimiter(max_per_window=rate_limit_per_min)
        self.audit_log = []  # 审计日志（内存）
        self.audit_lock = threading.Lock()

    # ---------- 安全校验 ----------
    def check_ip(self, client_ip: str) -> bool:
        """IP 白名单校验"""
        if not self.allowed_hosts:
            return True
        return client_ip in self.allowed_hosts

    def check_command_allowed(self, command: str, argv: Optional[list]) -> Optional[str]:
        """命令白名单校验：返回拒绝原因或 None"""
        if argv:
            exe = command
        else:
            segments = _ExecCommand._split_safe(command)
            exe = segments[0][0] if segments and isinstance(segments[0], list) else command
        base = os.path.basename(exe) if isinstance(exe, str) else str(exe)
        if base not in self.command_allowlist:
            return f"命令不在白名单: {base}"
        return None

    def audit(self, action: str, client_ip: str, msg_id: str, result: str,
              detail: str = ""):
        """记录审计日志"""
        with self.audit_lock:
            self.audit_log.append({
                "time": time.strftime("%Y-%m-%d %H:%M:%S"),
                "action": action, "client_ip": client_ip,
                "msg_id": msg_id, "result": result, "detail": detail,
            })
            if len(self.audit_log) > 2000:
                self.audit_log = self.audit_log[-1000:]

    # ---------- 消息处理器 ----------
    def _on_ping(self, body: Dict) -> Dict:
        return make_response(body.get("msg_id", ""), True,
                             data={"pong": True, "server": "comm-gateway-9120",
                                   "node": TraceMixin.NODE})

    def _on_exec(self, body: Dict) -> Dict:
        """执行命令（command + argv 分离）"""
        command = body.get("command", "")
        argv = body.get("argv") or []
        # 命令白名单校验
        deny = self.check_command_allowed(command, argv)
        if deny:
            self.audit("exec", getattr(self, "_current_client_ip", "?"), body.get("msg_id", ""),
                       "denied", deny)
            return make_response(body.get("msg_id", ""), False,
                                 error={"code": 403, "msg": deny}, status_code=403)

        cache_key = f"{command}|{json.dumps(argv, sort_keys=True)}"

        # 缓存命中
        cached = self.cache.get("local", cache_key)
        if cached is not None:
            return make_response(body.get("msg_id", ""), True,
                                 data={**cached, "cache_hit": True})

        result = _ExecCommand.run(command, argv, timeout=body.get("timeout"))
        if result["success"]:
            self.cache.put("local", cache_key, result)
        result["cache_hit"] = False
        self._report(body, result)
        self.audit("exec", getattr(self, "_current_client_ip", "?"), body.get("msg_id", ""),
                   "ok" if result["success"] else "fail",
                   f"{command} rc={result['return_code']}")
        return make_response(body.get("msg_id", ""), result["success"], data=result,
                             status_code=0 if result["success"] else 500)

    def _on_template(self, body: Dict) -> Dict:
        """模板命令执行"""
        name = body.get("command", "")
        params = body.get("params") or {}
        try:
            command = self.templates.render(name, params)
            timeout = self.templates.get_timeout(name)
        except KeyError as e:
            return make_response(body.get("msg_id", ""), False,
                                 error={"code": 1001, "msg": str(e)}, status_code=404)
        # 命令白名单校验（模板渲染后）
        deny = self.check_command_allowed(command, None)
        if deny:
            self.audit("template", getattr(self, "_current_client_ip", "?"), body.get("msg_id", ""),
                       "denied", deny)
            return make_response(body.get("msg_id", ""), False,
                                 error={"code": 403, "msg": deny}, status_code=403)

        result = _ExecCommand.run(command, timeout=timeout)
        self._report(body, result)
        self.audit("template", getattr(self, "_current_client_ip", "?"), body.get("msg_id", ""),
                   "ok" if result["success"] else "fail", name)
        return make_response(body.get("msg_id", ""), result["success"], data=result,
                             status_code=0 if result["success"] else 500)

    # ---------- 上报 ----------
    def _report(self, body: Dict, result: Dict):
        """执行结果写入本地内核快照（记忆网关双向通道：受控写入侧）"""
        try:
            entry = {
                "type": "COMM_EXEC_REPORT",
                "msg_id": body.get("msg_id"),
                "command": body.get("command"),
                "params": body.get("params"),
                "success": result.get("success"),
                "return_code": result.get("return_code"),
                "stdout_summary": (result.get("stdout") or "")[:300],
                "stderr_summary": (result.get("stderr") or "")[:200],
                "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
                "did": TraceMixin.DID,
                "trace": TRACE,
            }
            fname = f"comm_exec_{time.strftime('%Y%m%d_%H%M%S')}_{int(time.time()*1000)%100000:05d}.json"
            with open(os.path.join(self.report_dir, fname), "w", encoding="utf-8") as f:
                json.dump(entry, f, ensure_ascii=False, indent=1)
        except Exception:
            pass


class _Handler(BaseHTTPRequestHandler):
    server: CommGatewayServer

    def log_message(self, fmt, *args):
        pass

    def _read_body(self) -> Dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return {}

    @property
    def _gateway(self) -> CommGatewayServer:
        """访问真正的网关实例（self.server.handle 绑定到 gateway）"""
        return self.server.handle  # type: ignore

    def do_POST(self):
        client_ip = self.client_address[0]
        path = self.path.split("?")[0]
        if path != "/comm":
            self._send({"success": False, "error": "not_found"}, 404)
            return
        gw = self._gateway
        # ---- 安全加固：IP 白名单 ----
        if not gw.check_ip(client_ip):
            gw.audit("ip_deny", client_ip, "-", "denied")
            self._send({"success": False, "error": "forbidden"}, 403)
            return
        # ---- 安全加固：限流 ----
        if not gw.rate_limiter.allow(client_ip):
            gw.audit("rate_limit", client_ip, "-", "throttled")
            self._send({"success": False, "error": "too_many_requests"}, 429)
            return
        body = self._read_body()
        headers = {
            HDR_PROTOCOL: self.headers.get(HDR_PROTOCOL, ""),
            HDR_SIGNATURE: self.headers.get(HDR_SIGNATURE, ""),
            HDR_TIMESTAMP: self.headers.get(HDR_TIMESTAMP, ""),
            HDR_NONCE: self.headers.get(HDR_NONCE, ""),
            HDR_SOURCE: self.headers.get(HDR_SOURCE, ""),
            HDR_TRACE: self.headers.get(HDR_TRACE, ""),
        }
        # client_ip 通过内部字段传给 handle（不污染 body，避免破坏签名）
        resp = gw.handle(body, headers, client_ip=client_ip)
        self._send(resp, resp.get("status_code", 200) if resp.get("status_code", 200) != 0 else 200)

    def do_GET(self):
        client_ip = self.client_address[0]
        path = self.path.split("?")[0]
        gw = self._gateway
        if path == "/health":
            self._send({"status": "healthy", "gateway": "comm-9120",
                        "protocol": "COMM-PROTO-V1.0", "trace": TRACE})
        elif path == "/audit":
            # 审计日志（仅限本地/白名单IP）
            if not gw.check_ip(client_ip):
                self._send({"success": False, "error": "forbidden"}, 403)
                return
            self._send({"audit_log": gw.audit_log[-50:]})
        else:
            self._send({"success": False, "error": "not_found"}, 404)

    def _send(self, data: Dict, status: int = 200):
        body = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def start_server(secret: str, port: int = DEFAULT_PORT, host: str = "127.0.0.1",
                 report_dir: Optional[str] = None,
                 allowed_hosts: Optional[List[str]] = None,
                 command_allowlist: Optional[List[str]] = None,
                 rate_limit_per_min: int = 120) -> HTTPServer:
    """启动 9120 记忆网关服务端（默认绑定127.0.0.1，安全收紧）"""
    gateway = CommGatewayServer(secret, report_dir=report_dir,
                                allowed_hosts=allowed_hosts,
                                command_allowlist=command_allowlist,
                                rate_limit_per_min=rate_limit_per_min)
    server = HTTPServer((host, port), _Handler)
    # 绑定 gateway 实例到 server.handle（handler 通过 self.server.handle 访问网关）
    server.handle = gateway  # type: ignore
    return server


def main():
    import argparse
    parser = argparse.ArgumentParser(description="ANCE 9120 记忆网关服务端（无SSH通讯）")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--host", default="127.0.0.1",
                        help="绑定地址，默认仅本机；如需内网访问用内网IP，勿用0.0.0.0")
    parser.add_argument("--secret", default=os.environ.get("COMM_SECRET", "zongyuan-root-9120-secret"))
    parser.add_argument("--report-dir", default=None)
    parser.add_argument("--allow-host", action="append", default=[],
                        help="IP白名单（可多次），默认空=允许所有（由签名保护）")
    parser.add_argument("--allow-command", action="append", default=[],
                        help="命令白名单扩展（可多次）")
    parser.add_argument("--rate-limit", type=int, default=120,
                        help="每IP每分钟请求上限")
    args = parser.parse_args()

    # 合并命令白名单：默认 + 扩展
    allowlist = CommGatewayServer.DEFAULT_COMMAND_ALLOWLIST + args.allow_command

    print("=" * 60)
    print("  9120 记忆网关服务端 · 无SSH通讯协议 [SECURE]")
    print("  COMM-PROTO-V1.0 | " + TRACE + " | DID-BR-000002")
    print(f"  监听: {args.host}:{args.port}")
    print(f"  IP白名单: {args.allow_host or '全部(签名保护)'}")
    print(f"  命令白名单: {len(allowlist)}个 | 限流: {args.rate_limit}/min/IP")
    print("  功能: 签名校验 | 命令白名单 | IP白名单 | 限流 | 审计 | 双向上报")
    print("=" * 60)
    server = start_server(args.secret, args.port, args.host, args.report_dir,
                          allowed_hosts=args.allow_host,
                          command_allowlist=allowlist,
                          rate_limit_per_min=args.rate_limit)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[SHUTDOWN] 已停止")
        server.server_close()


if __name__ == "__main__":
    main()
