"""
ANCE 无SSH通讯协议 V1.0 · comm_protocol
基于 9120 记忆网关双向通道的 HTTP/JSON 远程通讯协议，完全替代 SSH 连接。

核心设计：
  1. 统一请求/响应结构（继承 ZR-PROTO-V1.0 溯源体系）
  2. HMAC-SHA256 签名 + 时间戳窗口，防重放/防篡改
  3. 命令以 JSON 字段封装（command + argv 数组），绝不拼接 shell，杜绝注入
  4. 双向通道：命令下发（client→server）+ 结果上报（server→client）
  5. 与 BatchSSHExecutor 接口兼容：execute / execute_template / summary

溯源标识：Ω₀⊂⊙∞⊂Ω | DID-BR-000002 | 同源节点 Ω-TAN-7-001
"""
import hashlib
import hmac
import json
import time
import uuid
import urllib.request
import urllib.error
from typing import Dict, List, Optional, Any, Union

PROTOCOL_VERSION = "COMM-PROTO-V1.0"
PROTOCOL_MAGIC = "ZR-COMM"
DEFAULT_PORT = 9120

# 协议头
HDR_PROTOCOL = "X-ZR-Protocol-Version"
HDR_SIGNATURE = "X-ZR-Hmac-Signature"
HDR_TIMESTAMP = "X-ZR-Timestamp"
HDR_NONCE = "X-ZR-Nonce"
HDR_SOURCE = "X-ZR-Source-Service"
HDR_TRACE = "X-ZR-Trace-Hash"


# ============================================================
# 溯源与签名
# ============================================================
class TraceMixin:
    """溯源标识"""

    DID = "DID-BR-000002"
    TRACE = "Ω₀⊂⊙∞⊂Ω"
    NODE = "Ω-TAN-7-001"


def compute_signature(secret: str, body: Union[Dict, bytes], timestamp: str,
                      nonce: str) -> str:
    """HMAC-SHA256 签名：对规范化消息签名"""
    if isinstance(body, dict):
        canonical = json.dumps(body, sort_keys=True, separators=(",", ":"))
    else:
        canonical = body.decode("utf-8") if isinstance(body, bytes) else str(body)
    message = f"{timestamp}|{nonce}|{canonical}".encode("utf-8")
    return hmac.new(secret.encode("utf-8"), message, hashlib.sha256).hexdigest()


def verify_signature(secret: str, body: Union[Dict, bytes], timestamp: str,
                     nonce: str, signature: str, replay_window: int = 300) -> bool:
    """验证签名 + 时间戳防重放"""
    # 1. 时间戳窗口校验
    try:
        ts = float(timestamp)
    except (TypeError, ValueError):
        return False
    if abs(time.time() - ts) > replay_window:
        return False
    # 2. 签名校验（hmac.compare_digest 防时序攻击）
    expect = compute_signature(secret, body, timestamp, nonce)
    return hmac.compare_digest(expect, signature)


# ============================================================
# 统一消息结构
# ============================================================
def make_message(cmd_type: str, target: str, command: str = "",
                 argv: Optional[List[str]] = None, params: Optional[Dict] = None,
                 source: str = "ance-agent") -> Dict:
    """构造命令下发消息——command 与 argv 分离，杜绝 shell 拼接"""
    return {
        "protocol_version": PROTOCOL_VERSION,
        "magic": PROTOCOL_MAGIC,
        "msg_id": "MSG-" + uuid.uuid4().hex[:12].upper(),
        "type": cmd_type,          # exec / template / ping / report
        "target": target,          # 目标服务/节点
        "source": source,
        "command": command,        # 命令名（模板名或可执行名）
        "argv": argv or [],        # 参数数组（安全，不拼接）
        "params": params or {},    # 模板参数
        "created_at": time.time(),
        "did": TraceMixin.DID,
        "trace": TraceMixin.TRACE,
        "node": TraceMixin.NODE,
    }


def make_response(msg_id: str, success: bool, data: Any = None,
                  error: Optional[Dict] = None, status_code: int = 200) -> Dict:
    """构造统一响应"""
    return {
        "protocol_version": PROTOCOL_VERSION,
        "msg_id": msg_id,
        "success": success,
        "data": data,
        "error": error,
        "status_code": status_code,
        "received_at": time.time(),
        "trace": TraceMixin.TRACE,
    }


# ============================================================
# 客户端：发送命令到 9120 网关
# ============================================================
class CommClient:
    """通讯协议客户端——向远程 9120 网关下发命令并接收结果"""

    def __init__(self, gateway_url: str, secret: str, source: str = "ance-agent",
                 timeout: float = 30.0, replay_window: int = 300):
        self.gateway_url = gateway_url.rstrip("/")
        self.secret = secret
        self.source = source
        self.timeout = timeout
        self.replay_window = replay_window

    def _sign_request(self, body: Dict) -> Dict:
        """对请求体签名，返回 headers"""
        timestamp = str(time.time())
        nonce = uuid.uuid4().hex[:16]
        sig = compute_signature(self.secret, body, timestamp, nonce)
        return {
            HDR_PROTOCOL: PROTOCOL_VERSION,
            HDR_SIGNATURE: sig,
            HDR_TIMESTAMP: timestamp,
            HDR_NONCE: nonce,
            HDR_SOURCE: self.source,
            "Content-Type": "application/json; charset=utf-8",
        }

    def send(self, body: Dict) -> Dict:
        """发送消息到网关"""
        headers = self._sign_request(body)
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            self.gateway_url + "/comm",
            data=data, headers=headers, method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                return json.loads(e.read().decode("utf-8"))
            except Exception:
                return make_response("", False, error={"code": e.code, "msg": str(e)},
                                     status_code=e.code)
        except Exception as e:
            return make_response("", False, error={"code": 502, "msg": str(e)},
                                 status_code=502)

    # ---- 高层操作：与 BatchSSHExecutor 兼容 ----
    def execute(self, command: str, timeout: Optional[float] = None) -> Dict:
        """执行远程命令（command 作为单个可执行文件路径，argv 为空）"""
        body = make_message("exec", self.source, command=command)
        resp = self.send(body)
        return {
            "success": resp.get("success", False),
            "stdout": resp.get("data", {}).get("stdout", "") if isinstance(resp.get("data"), dict) else "",
            "stderr": resp.get("data", {}).get("stderr", "") if isinstance(resp.get("data"), dict) else str(resp.get("error", "")),
            "return_code": resp.get("data", {}).get("return_code", -1) if isinstance(resp.get("data"), dict) else -1,
            "host": self.gateway_url,
            "cache_hit": False,
        }

    def execute_template(self, template_name: str, params: Optional[Dict] = None) -> Dict:
        """按模板执行（模板在服务端渲染）"""
        body = make_message("template", self.source, command=template_name, params=params or {})
        resp = self.send(body)
        return {
            "success": resp.get("success", False),
            "stdout": resp.get("data", {}).get("stdout", "") if isinstance(resp.get("data"), dict) else "",
            "stderr": resp.get("data", {}).get("stderr", "") if isinstance(resp.get("data"), dict) else str(resp.get("error", "")),
            "return_code": resp.get("data", {}).get("return_code", -1) if isinstance(resp.get("data"), dict) else -1,
            "host": self.gateway_url,
            "cache_hit": False,
        }

    def ping(self) -> Dict:
        """连通性检测"""
        body = make_message("ping", self.source)
        return self.send(body)


# ============================================================
# 服务端基类：校验签名并分发（由具体 daemon 继承）
# ============================================================
class CommServer:
    """通讯协议服务端基类——负责签名校验与消息分发"""

    def __init__(self, secret: str, replay_window: int = 300):
        self.secret = secret
        self.replay_window = replay_window

    def validate(self, body: Dict, headers: Dict) -> Optional[Dict]:
        """校验协议版本+签名+时间戳，返回错误响应或 None"""
        if body.get("protocol_version") != PROTOCOL_VERSION:
            return make_response(body.get("msg_id", ""), False,
                                 error={"code": 1000, "msg": "协议版本不兼容"},
                                 status_code=400)
        sig = headers.get(HDR_SIGNATURE, "")
        ts = headers.get(HDR_TIMESTAMP, "")
        nonce = headers.get(HDR_NONCE, "")
        if not verify_signature(self.secret, body, ts, nonce, sig, self.replay_window):
            return make_response(body.get("msg_id", ""), False,
                                 error={"code": 1003, "msg": "签名校验失败或时间戳过期"},
                                 status_code=401)
        return None

    def handle(self, body: Dict, headers: Dict) -> Dict:
        """处理消息：校验 + 分发到消息类型处理器"""
        # 校验
        err = self.validate(body, headers)
        if err:
            return err
        # 分发
        cmd_type = body.get("type")
        handler = getattr(self, f"_on_{cmd_type}", None)
        if handler is None:
            return make_response(body.get("msg_id", ""), False,
                                 error={"code": 1001, "msg": f"未知消息类型: {cmd_type}"},
                                 status_code=404)
        return handler(body)
