"""
ANCE 无SSH通讯协议 V1.0 · comm_protocol
基于 9120 记忆网关双向通道的 HTTP/JSON 远程通讯协议，完全替代 SSH 连接。

核心设计：
  1. 统一请求/响应结构（继承 ZR-PROTO-V1.0 溯源体系）
  2. HMAC-SHA256 签名 + 时间戳窗口，防重放/防篡改
  3. 命令以 JSON 字段封装（command + argv 数组），绝不拼接 shell，杜绝注入
  4. 双向通道：命令下发（client→server）+ 结果上报（server→client）
  5. 与 BatchSSHExecutor 接口兼容：execute / execute_template / summary

溯源标识：Ω₀⊂⊙∞⊂Ω | DID-BR-000002 | 同源节点 Ω-TAN-7-001
"""
import hashlib
import hmac
import json
import os
import time
import uuid
import urllib.request
import urllib.error
from typing import Dict, List, Optional, Any, Union

PROTOCOL_VERSION = "COMM-PROTO-V1.0"
PROTOCOL_MAGIC = "ZR-COMM"
DEFAULT_PORT = 9120

# 协议头
HDR_PROTOCOL = "X-ZR-Protocol-Version"
HDR_SIGNATURE = "X-ZR-Hmac-Signature"
HDR_TIMESTAMP = "X-ZR-Timestamp"
HDR_NONCE = "X-ZR-Nonce"
HDR_SOURCE = "X-ZR-Source-Service"
HDR_TRACE = "X-ZR-Trace-Hash"


# ============================================================
# 溯源与签名
# ============================================================
class TraceMixin:
    """溯源标识"""

    DID = "DID-BR-000002"
    TRACE = "Ω₀⊂⊙∞⊂Ω"
    NODE = "Ω-TAN-7-001"


def compute_signature(secret: str, body: Union[Dict, bytes], timestamp: str,
                      nonce: str) -> str:
    """HMAC-SHA256 签名：对规范化消息签名"""
    if isinstance(body, dict):
        canonical = json.dumps(body, sort_keys=True, separators=(",", ":"))
    else:
        canonical = body.decode("utf-8") if isinstance(body, bytes) else str(body)
    message = f"{timestamp}|{nonce}|{canonical}".encode("utf-8")
    return hmac.new(secret.encode("utf-8"), message, hashlib.sha256).hexdigest()


def verify_signature(secret: str, body: Union[Dict, bytes], timestamp: str,
                     nonce: str, signature: str, replay_window: int = 300) -> bool:
    """验证签名 + 时间戳防重放"""
    # 1. 时间戳窗口校验
    try:
        ts = float(timestamp)
    except (TypeError, ValueError):
        return False
    if abs(time.time() - ts) > replay_window:
        return False
    # 2. 签名校验（hmac.compare_digest 防时序攻击）
    expect = compute_signature(secret, body, timestamp, nonce)
    return hmac.compare_digest(expect, signature)


def verify_signature_detailed(secret: str, body: Union[Dict, bytes], timestamp: str,
                              nonce: str, signature: str,
                              replay_window: int = 300) -> Dict:
    """签名+时间戳分步校验，返回精确失败原因（时钟漂移/签名错误/参数缺失）。

    P0加固：区分时钟漂移与签名错误，便于诊断与运维告警。
    返回 {"ok": bool, "reason": str, "code": int}
    """
    if not timestamp or not nonce or not signature:
        return {"ok": False, "reason": "缺少时间戳/随机数/签名", "code": 1003}
    try:
        ts = float(timestamp)
    except (TypeError, ValueError):
        return {"ok": False, "reason": "时间戳格式非法", "code": 1003}
    skew = abs(time.time() - ts)
    if skew > replay_window:
        # 时钟漂移/时间戳过期（P0-2：显式区分）
        return {"ok": False, "reason": f"时间戳过期或时钟漂移(偏差{int(skew)}s>窗口{replay_window}s)",
                "code": 1004}
    expect = compute_signature(secret, body, timestamp, nonce)
    if not hmac.compare_digest(expect, signature):
        return {"ok": False, "reason": "签名不匹配", "code": 1003}
    return {"ok": True, "reason": "", "code": 0}


# ============================================================
# 统一消息结构
# ============================================================
def make_message(cmd_type: str, target: str, command: str = "",
                 argv: Optional[List[str]] = None, params: Optional[Dict] = None,
                 source: str = "ance-agent") -> Dict:
    """构造命令下发消息——command 与 argv 分离，杜绝 shell 拼接"""
    return {
        "protocol_version": PROTOCOL_VERSION,
        "magic": PROTOCOL_MAGIC,
        "msg_id": "MSG-" + uuid.uuid4().hex[:12].upper(),
        "type": cmd_type,          # exec / template / ping / report
        "target": target,          # 目标服务/节点
        "source": source,
        "command": command,        # 命令名（模板名或可执行名）
        "argv": argv or [],        # 参数数组（安全，不拼接）
        "params": params or {},    # 模板参数
        "created_at": time.time(),
        "did": TraceMixin.DID,
        "trace": TraceMixin.TRACE,
        "node": TraceMixin.NODE,
    }


def make_response(msg_id: str, success: bool, data: Any = None,
                  error: Optional[Dict] = None, status_code: int = 200) -> Dict:
    """构造统一响应"""
    return {
        "protocol_version": PROTOCOL_VERSION,
        "msg_id": msg_id,
        "success": success,
        "data": data,
        "error": error,
        "status_code": status_code,
        "received_at": time.time(),
        "trace": TraceMixin.TRACE,
    }


# ============================================================
# 客户端：发送命令到 9120 网关
# ============================================================
class CommClient:
    """通讯协议客户端——向远程 9120 网关下发命令并接收结果"""

    def __init__(self, gateway_url: str, secret: str, source: str = "ance-agent",
                 timeout: float = 30.0, replay_window: int = 300):
        self.gateway_url = gateway_url.rstrip("/")
        self.secret = secret
        self.source = source
        self.timeout = timeout
        self.replay_window = replay_window

    def _sign_request(self, body: Dict) -> Dict:
        """对请求体签名，返回 headers"""
        timestamp = str(time.time())
        nonce = uuid.uuid4().hex[:16]
        sig = compute_signature(self.secret, body, timestamp, nonce)
        return {
            HDR_PROTOCOL: PROTOCOL_VERSION,
            HDR_SIGNATURE: sig,
            HDR_TIMESTAMP: timestamp,
            HDR_NONCE: nonce,
            HDR_SOURCE: self.source,
            "Content-Type": "application/json; charset=utf-8",
        }

    def send(self, body: Dict) -> Dict:
        """发送消息到网关"""
        headers = self._sign_request(body)
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        req = urllib.request.Request(
            self.gateway_url + "/comm",
            data=data, headers=headers, method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                return json.loads(e.read().decode("utf-8"))
            except Exception:
                return make_response("", False, error={"code": e.code, "msg": str(e)},
                                     status_code=e.code)
        except Exception as e:
            return make_response("", False, error={"code": 502, "msg": str(e)},
                                 status_code=502)

    # ---- 高层操作：与 BatchSSHExecutor 兼容 ----
    def execute(self, command: str, timeout: Optional[float] = None) -> Dict:
        """执行远程命令（command 作为单个可执行文件路径，argv 为空）"""
        body = make_message("exec", self.source, command=command)
        resp = self.send(body)
        return {
            "success": resp.get("success", False),
            "stdout": resp.get("data", {}).get("stdout", "") if isinstance(resp.get("data"), dict) else "",
            "stderr": resp.get("data", {}).get("stderr", "") if isinstance(resp.get("data"), dict) else str(resp.get("error", "")),
            "return_code": resp.get("data", {}).get("return_code", -1) if isinstance(resp.get("data"), dict) else -1,
            "host": self.gateway_url,
            "cache_hit": False,
        }

    def execute_template(self, template_name: str, params: Optional[Dict] = None) -> Dict:
        """按模板执行（模板在服务端渲染）"""
        body = make_message("template", self.source, command=template_name, params=params or {})
        resp = self.send(body)
        return {
            "success": resp.get("success", False),
            "stdout": resp.get("data", {}).get("stdout", "") if isinstance(resp.get("data"), dict) else "",
            "stderr": resp.get("data", {}).get("stderr", "") if isinstance(resp.get("data"), dict) else str(resp.get("error", "")),
            "return_code": resp.get("data", {}).get("return_code", -1) if isinstance(resp.get("data"), dict) else -1,
            "host": self.gateway_url,
            "cache_hit": False,
        }

    def ping(self) -> Dict:
        """连通性检测"""
        body = make_message("ping", self.source)
        return self.send(body)


# ============================================================
# 服务端基类：校验签名并分发（由具体 daemon 继承）
# ============================================================
class CommServer:
    """通讯协议服务端基类——负责签名校验与消息分发"""

    def __init__(self, secret: str, replay_window: int = 300,
                 revoked_secrets: Optional[set] = None,
                 revoked_file: str = ""):
        self.secret = secret
        self.replay_window = replay_window
        # ---- P0-1：密钥即时吊销黑名单 ----
        self.revoked_secrets = set(revoked_secrets or [])
        self.revoked_file = revoked_file or os.path.expanduser(
            "~/.zongyuan_root/kernel/comm_revoked.json")
        self._load_revoked()

    # ---------- P0-1：密钥吊销黑名单 ----------
    def _load_revoked(self) -> None:
        """从吊销文件加载已吊销密钥指纹列表"""
        try:
            if os.path.exists(self.revoked_file):
                with open(self.revoked_file) as f:
                    data = json.load(f)
                self.revoked_secrets = set(data.get("revoked", []))
        except Exception:
            self.revoked_secrets = set()

    def _save_revoked(self) -> None:
        """持久化吊销列表（0600 权限）"""
        try:
            os.makedirs(os.path.dirname(self.revoked_file), exist_ok=True)
            with open(self.revoked_file, "w") as f:
                json.dump({"revoked": sorted(self.revoked_secrets),
                           "updated_at": time.time()}, f, indent=1)
            os.chmod(self.revoked_file, 0o600)
        except Exception:
            pass

    def revoke_secret(self, secret: str) -> bool:
        """即时吊销一个密钥（立即生效，不等宽限期）。

        支持传入密钥原文（自动算指纹）或指纹（16位大写）。
        返回 True 表示吊销成功。
        """
        fp = secret
        if len(secret) > 16 or "-" in secret:
            # 密钥原文 → 指纹（与 rotate_secret.fingerprint 一致：SHA256前16位大写）
            import hashlib as _hl
            fp = _hl.sha256(secret.encode()).hexdigest()[:16].upper()
        fp = fp.upper()
        self.revoked_secrets.add(fp)
        self._save_revoked()
        return True

    def is_secret_revoked(self, secret: str) -> bool:
        """检查密钥是否已被吊销"""
        import hashlib as _hl
        fp = _hl.sha256(secret.encode()).hexdigest()[:16].upper()
        return fp in self.revoked_secrets

    def validate(self, body: Dict, headers: Dict) -> Optional[Dict]:
        """校验协议版本+签名+时间戳，返回错误响应或 None"""
        if body.get("protocol_version") != PROTOCOL_VERSION:
            return make_response(body.get("msg_id", ""), False,
                                 error={"code": 1000, "msg": "协议版本不兼容"},
                                 status_code=400)
        sig = headers.get(HDR_SIGNATURE, "")
        ts = headers.get(HDR_TIMESTAMP, "")
        nonce = headers.get(HDR_NONCE, "")
        # P0-1：密钥即时吊销——本服务端密钥被吊销则拒绝全部请求
        if self.is_secret_revoked(self.secret):
            return make_response(body.get("msg_id", ""), False,
                                 error={"code": 1005, "msg": "服务端密钥已被吊销，请轮换"},
                                 status_code=403)
        # P0-2：分步校验（时钟漂移 vs 签名错误 明确区分）
        v = verify_signature_detailed(self.secret, body, ts, nonce, sig,
                                      self.replay_window)
        if not v["ok"]:
            return make_response(body.get("msg_id", ""), False,
                                 error={"code": v["code"], "msg": v["reason"]},
                                 status_code=401)
        return None

    def handle(self, body: Dict, headers: Dict, client_ip: str = "") -> Dict:
        """处理消息：校验 + 分发到消息类型处理器"""
        # 校验
        err = self.validate(body, headers)
        if err:
            return err
        # 分发
        cmd_type = body.get("type")
        handler = getattr(self, f"_on_{cmd_type}", None)
        if handler is None:
            return make_response(body.get("msg_id", ""), False,
                                 error={"code": 1001, "msg": f"未知消息类型: {cmd_type}"},
                                 status_code=404)
        # 传递 client_ip 供审计
        self._current_client_ip = client_ip
        return handler(body)
