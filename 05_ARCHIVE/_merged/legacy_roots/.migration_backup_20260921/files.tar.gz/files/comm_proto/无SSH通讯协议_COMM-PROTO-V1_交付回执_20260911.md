# 无SSH通讯协议 COMM-PROTO-V1.0 交付回执
溯源标识：Ω₀⊂⊙∞⊂Ω | DID-BR-000002 | 火斗云智 AIOS 内部技术文档

## 交付状态：开发完成 · 测试通过 · 待审批部署
时间：2026-09-11

## 一、交付内容
基于 9120 记忆网关双向通道的 HTTP/JSON 无SSH通讯协议，替代 SSH 执行远程命令。

## 二、核心能力
| 能力 | 说明 | 验证 |
|---|---|---|
| HMAC签名+防重放 | 时间戳窗口300s，compare_digest | 单测 ✓ |
| 命令JSON封装 | command+argv分离，无shell拼接 | 单测 ✓ |
| 注入防护 | 参数/分号注入均被拒，无副作用 | 单测 ✓ |
| 受限复合命令 | &&/||/| 白名单解析 | 单测 ✓ |
| 模板执行 | 复用 command_templates.json | 端到端 ✓ |
| 结果缓存 | TTL 300s | 单测 ✓ |
| 双向上报 | 本地内核快照+记忆网关 | 单测 ✓ |
| batch兼容 | execute/execute_template/summary | 端到端 ✓ |

## 三、测试结果
- 单元测试 17/17 通过（OK）
- 端到端演示通过（ping/exec/template/批量）

## 四、待办
- [ ] 人工审核确认后部署（每台目标机启动 9120 网关）
- [ ] 生成/分发共享密钥（COMM_SECRET）
- [ ] 生产环境安全加固（TLS、密钥轮换）

## 五、回滚方案
- 本协议与 SSH 方案并行，RemoteHTTPExecutor 可随时切回 BatchSSHExecutor
- 不修改现有 ssh_adapter，零侵入
