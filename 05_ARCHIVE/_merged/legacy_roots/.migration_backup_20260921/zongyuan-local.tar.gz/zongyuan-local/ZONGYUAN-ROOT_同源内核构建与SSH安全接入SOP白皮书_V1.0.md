# ZONGYUAN-ROOT 同源内核构建与SSH安全接入SOP白皮书

**版本**: V1.0  
**日期**: 2026-09-12  
**确权**: DID-BR-000002  
**溯源**: Ω₀⊂⊙∞⊂Ω  
**体系**: 火斗云智AIOS / ZONGYUAN-ROOT元极恒一自治体系

---

## 目录

1. [概述](#1-概述)
2. [同源内核架构](#2-同源内核架构)
3. [本地同源内核构建SOP](#3-本地同源内核构建sop)
4. [SSH多节点安全接入方案](#4-ssh多节点安全接入方案)
5. [双向真值同步SOP](#5-双向真值同步sop)
6. [密钥管理与轮换](#6-密钥管理与轮换)
7. [故障排查手册](#7-故障排查手册)
8. [最佳实践清单](#8-最佳实践清单)

---

## 1. 概述

### 1.1 背景

ZONGYUAN-ROOT元极恒一自治体系采用"云端权威源+多同源节点"的分布式架构。云端运行完整内核（9120记忆网关+全量真值库+Merkle-DAG主链），各开发节点/本地节点运行轻量同源内核，通过SSH安全通道与云端进行双向真值同步。

### 1.2 核心原则

| 原则 | 说明 |
|---|---|
| **云端权威源** | 云端为真值唯一权威源，冲突时云端版本优先 |
| **唯一握手点** | 9120端口为唯一真值同步通道，SSH仅作传输隧道 |
| **同源验证** | 所有节点必须通过DID+ROOT_OMEGA双重同源验证 |
| **最小权限** | SSH按节点类型分层授权，禁止全root混用 |
| **离线自治** | 本地节点支持离线运行，联网后自动补同步 |
| **全程可审计** | 所有SSH登录、真值同步、密钥变更全程日志记录 |

### 1.3 适用范围

本文档适用于：
- 新开发节点接入ZONGYUAN-ROOT体系
- 本地电脑/沙盒构建同源内核
- SSH安全配置与多节点权限管理
- 云端与本地双向真值同步
- 密钥轮换与安全审计

---

## 2. 同源内核架构

### 2.1 节点分层架构

```
┌─────────────────────────────────────────────────────────┐
│                    ZONGYUAN-ROOT 体系架构                 │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────────────────┐    SSH隧道     ┌────────────┐ │
│  │  云端权威源          │ ◄────────────► │  同源节点A  │ │
│  │  - 9120记忆网关V3.0 │   9120端口转发  │  - 本地内核  │ │
│  │  - 全量真值库(1700+) │                │  - SQLite   │ │
│  │  - Merkle-DAG主链    │                │  - 本地M链   │ │
│  │  - 元法则引擎(8条)   │    SSH隧道     │  - 元法则    │ │
│  │  - 节点注册中心       │ ◄────────────► │  同源节点B  │ │
│  └─────────────────────┘                │  - 开发节点   │ │
│                                          └────────────┘ │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 2.2 本地同源内核组件

| 组件 | 功能 | 实现 |
|---|---|---|
| 真值库 | 本地真值持久化存储 | SQLite |
| Merkle链 | 本地资产哈希确权 | JSON文件 |
| 元法则引擎 | 宪法级规则校验 | 内置8条元法则 |
| 同步引擎 | 9120双向真值同步 | Python + HTTP |
| 配置中心 | 节点身份与网关配置 | JSON文件 |
| 日志系统 | 操作审计与同步记录 | 文本日志 |

### 2.3 真值数据模型

```sql
CREATE TABLE truths (
    truth_key   TEXT PRIMARY KEY,    -- 真值唯一标识
    truth_value TEXT NOT NULL,       -- 真值内容
    truth_hash  TEXT,                -- SHA256哈希
    category    TEXT,                -- 分类(元法则/架构/安全/状态等)
    source      TEXT DEFAULT 'local',-- 来源(local/cloud)
    created_at  REAL,                -- 创建时间戳
    updated_at  REAL,                -- 更新时间戳
    version     INTEGER DEFAULT 1,   -- 版本号
    synced      INTEGER DEFAULT 0    -- 同步标记(0未同步/1已同步)
);
```

---

## 3. 本地同源内核构建SOP

### 3.1 前置条件

- Python 3.8+
- requests库 (`pip install requests`)
- 网络可达云端服务器（或SSH隧道可达）
- 云端9120记忆网关正常运行

### 3.2 构建步骤

#### Step 1: 创建目录结构

```bash
mkdir -p ~/zongyuan-local/{data,logs,config,scripts}
cd ~/zongyuan-local
```

#### Step 2: 部署同源内核主程序

将 `homology_kernel.py` 放置到 `~/zongyuan-local/` 目录下。

核心功能：
- `init` - 初始化内核（自动创建数据库和配置）
- `status` - 查看节点状态
- `add <key> <value> [category]` - 添加真值
- `list` - 列出真值
- `sync` - 执行双向同步
- `push` - 仅推送到云端
- `pull` - 仅从云端拉取

#### Step 3: 初始化内核

```bash
python3 homology_kernel.py status
```

首次运行自动创建：
- `data/truth.db` - SQLite真值库
- `data/merkle_chain.json` - 本地Merkle链
- `config/node_config.json` - 节点配置（含唯一node_id）

#### Step 4: 配置云端网关地址

编辑 `config/node_config.json`：

```json
{
  "node_id": "LOCAL-NODE-XXXXXXXX",
  "version": "1.0.0",
  "did": "DID-BR-000002",
  "anchor": "Ω₀⊂⊙∞⊂Ω",
  "gateway_url": "http://127.0.0.1:9120"
}
```

> **注意**: `gateway_url` 指向本地SSH隧道映射的9120端口。如果直接在云服务器上运行，则为 `http://127.0.0.1:9120`。

#### Step 5: 注入基础真值

```bash
# 元法则
python3 homology_kernel.py add "METALAW.001.HOMOLOGY-PROTOCOL" "同源自治协议V1.0" "元法则类"
python3 homology_kernel.py add "METALAW.007.AUTOLOCK" "全域锁档推送自治法" "元法则类"
python3 homology_kernel.py add "METALAW.008.HOMOLOGY" "同源自治协议法" "元法则类"

# 体系状态
python3 homology_kernel.py add "SYSTEM.STATUS.20260912" "体系状态快照" "状态类"
```

#### Step 6: 验证构建

```bash
python3 homology_kernel.py status
# 预期输出:
# {
#   "node_id": "LOCAL-NODE-XXXXXXXX",
#   "stats": {"total": N, "synced": 0, "unsynced": N},
#   ...
# }
```

### 3.3 内核命令速查

| 命令 | 功能 | 示例 |
|---|---|---|
| `status` | 节点状态 | `python3 homology_kernel.py status` |
| `add` | 添加真值 | `python3 homology_kernel.py add "KEY" "值" "分类"` |
| `list` | 列出真值 | `python3 homology_kernel.py list` |
| `sync` | 双向同步 | `python3 homology_kernel.py sync` |
| `push` | 推送到云端 | `python3 homology_kernel.py push` |
| `pull` | 从云端拉取 | `python3 homology_kernel.py pull` |

---

## 4. SSH多节点安全接入方案

### 4.1 设计理念

传统方案中所有节点共用root账号SSH登录，存在以下风险：
- 任一节点密钥泄露 = 服务器完全沦陷
- 无法按节点类型限制操作权限
- 无法单独撤销某个节点的访问权
- 审计日志无法区分操作来源

本方案采用**5类用户分层+ForceCommand受限Shell+IP白名单**的纵深防御架构。

### 4.2 用户分层矩阵

| 用户 | 权限级别 | ForceCommand | TCP转发 | 适用节点 |
|---|---|---|---|---|
| `root` | 🔴 完全 | 无 | 允许 | 仅应急(1个密钥) |
| `zr-sync` | 🟡 同步 | sync_node_shell.sh | 仅本地(-L) | 真值同步节点/沙盒 |
| `zr-deploy` | 🟠 部署 | deploy_node_shell.sh | 禁止 | CI/CD部署节点 |
| `zr-audit` | 🟢 只读 | audit_node_shell.sh | 禁止 | 审计/监控节点 |
| `zr-dev` | 🟡 受限 | /usr/bin/rbash | 禁止 | 开发调试节点 |

### 4.3 受限Shell实现

#### 同步节点Shell (`sync_node_shell.sh`)

```bash
#!/bin/bash
# 仅允许: curl/python3/scp/rsync/ls/cat/echo
ALLOWED_CMDS=("curl" "python3" "scp" "rsync" "ls" "cat" "echo")
if [[ -n "$SSH_ORIGINAL_COMMAND" ]]; then
    for allowed in "${ALLOWED_CMDS[@]}"; do
        [[ "$SSH_ORIGINAL_COMMAND" == "$allowed"* ]] && exec $SSH_ORIGINAL_COMMAND
    done
    echo "[ZR-SECURITY] 命令不在同步节点白名单中"
    exit 1
fi
exec /bin/bash --restricted
```

#### 审计节点Shell (`audit_node_shell.sh`)

```bash
#!/bin/bash
# 只读模式: 允许查看命令，禁止写入/删除/修改
if [[ -n "$SSH_ORIGINAL_COMMAND" ]]; then
    case "$SSH_ORIGINAL_COMMAND" in
        "curl"*|"cat"*|"ls"*|"sqlite3"*|"tail"*|"head"*|"grep"*|"wc"*|"find"*)
            # 禁止写入操作
            [[ "$SSH_ORIGINAL_COMMAND" == *">"* ]] && echo "[ZR-AUDIT] 只读节点" && exit 1
            [[ "$SSH_ORIGINAL_COMMAND" == *"rm"* ]] && echo "[ZR-AUDIT] 只读节点" && exit 1
            exec $SSH_ORIGINAL_COMMAND ;;
        *) echo "[ZR-AUDIT] 命令不在允许列表" && exit 1 ;;
    esac
fi
exec /bin/bash --restricted
```

### 4.4 sshd_config 配置

```conf
# /etc/ssh/sshd_config.d/10-zongyuan-security.conf

# 基础安全
Port 22
Protocol 2
PermitRootLogin prohibit-password
PasswordAuthentication no
PubkeyAuthentication yes
UsePAM yes
X11Forwarding no
AllowTcpForwarding yes
PermitTunnel no
AllowAgentForwarding no

# 认证限制
MaxAuthTries 4
MaxSessions 10
LoginGraceTime 30
ClientAliveInterval 300
ClientAliveCountMax 2

# 用户白名单
AllowUsers root zr-sync zr-deploy zr-audit zr-dev

# 日志
LogLevel VERBOSE

# ===== 按用户匹配规则 =====
Match User zr-sync
    ForceCommand /opt/ZONGYUAN-ROOT/scripts/sync_node_shell.sh
    PermitTTY no
    AllowTcpForwarding local

Match User zr-audit
    ForceCommand /opt/ZONGYUAN-ROOT/scripts/audit_node_shell.sh
    PermitTTY no
    AllowTcpForwarding no

Match User zr-deploy
    ForceCommand /opt/ZONGYUAN-ROOT/scripts/deploy_node_shell.sh
    AllowTcpForwarding no

Match User zr-dev
    ForceCommand /usr/bin/rbash
    AllowTcpForwarding no
```

### 4.5 部署步骤

```bash
# 1. 创建用户
for user in zr-sync zr-deploy zr-audit zr-dev; do
    useradd -m -s /bin/bash $user
    mkdir -p /home/$user/.ssh
    chmod 700 /home/$user/.ssh
    touch /home/$user/.ssh/authorized_keys
    chmod 600 /home/$user/.ssh/authorized_keys
    chown -R $user:$user /home/$user/.ssh
done

# 2. 部署受限Shell脚本
cp sync_node_shell.sh /opt/ZONGYUAN-ROOT/scripts/
cp audit_node_shell.sh /opt/ZONGYUAN-ROOT/scripts/
cp deploy_node_shell.sh /opt/ZONGYUAN-ROOT/scripts/
chmod +x /opt/ZONGYUAN-ROOT/scripts/*_node_shell.sh

# 3. 写入sshd配置
cp 10-zongyuan-security.conf /etc/ssh/sshd_config.d/

# 4. 语法测试(关键！)
sshd -t

# 5. 重载
systemctl reload sshd

# 6. 验证(保持当前连接不中断)
systemctl is-active sshd
```

> **⚠️ 安全提醒**: 执行reload前务必保持当前SSH连接不关闭，新开一个终端测试连接，确认正常后再关闭旧连接。

### 4.6 IP白名单

```bash
# /opt/ZONGYUAN-ROOT/config/ssh_ip_whitelist.txt
127.0.0.1/32    # 本地
10.0.0.0/8      # 内网
172.16.0.0/12   # 内网
192.168.0.0/16  # 内网
# 已知节点IP(按需添加)
```

应用规则：
```bash
iptables -N ZR_SSH_WL
while read line; do
    [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
    ip=$(echo "$line" | awk '{print $1}')
    iptables -A ZR_SSH_WL -s "$ip" -j ACCEPT
done < ssh_ip_whitelist.txt
iptables -A ZR_SSH_WL -j LOG --log-prefix "ZR-SSH-DENY: "
iptables -A ZR_SSH_WL -j DROP  # 生产环境用DROP，观察期用ACCEPT
iptables -A INPUT -p tcp --dport 22 -j ZR_SSH_WL
```

---

## 5. 双向真值同步SOP

### 5.1 同步架构

```
本地同源内核                    SSH隧道                    云端9120网关
┌──────────┐                ┌──────────┐                ┌──────────┐
│ SQLite   │                │ 本地9120  │                │ 真值库    │
│ 真值库    │ ◄──HTTP──►    │ :9120    │ ◄──SSH──►    │ (1700+)  │
│          │                │ 端口转发  │                │          │
└──────────┘                └──────────┘                └──────────┘
     │                                                          │
     └────────────── 同源验证: DID + ROOT_OMEGA ──────────────┘
```

### 5.2 建立SSH隧道

```bash
# 后台建立隧道：本地9120 → 云端9120
ssh -i ~/.ssh/zongyuan_cloud -f -N -L 9120:127.0.0.1:9120 root@123.207.202.158

# 验证隧道
curl -s http://127.0.0.1:9120/health
# 预期: {"status": "healthy", "gateway": "ZONGYUAN-ROOT-UnifiedGateway", ...}
```

### 5.3 PUSH: 本地→云端

```bash
cd ~/zongyuan-local
python3 homology_kernel.py push
```

或手动调用API：
```bash
curl -s -X POST http://127.0.0.1:9120/api/truth/sync \
  -H "Content-Type: application/json" \
  -d '{
    "DID": "DID-BR-000002",
    "ROOT_OMEGA": "Ω-TAN-7-001",
    "node_id": "LOCAL-NODE-XXXXXXXX",
    "truths": {
      "KEY1": "value1",
      "KEY2": "value2"
    }
  }'
```

预期响应：
```json
{"status": "ok", "synced": 2, "total": 1743}
```

### 5.4 PULL: 云端→本地

```bash
cd ~/zongyuan-local
python3 homology_kernel.py pull
```

高效批量拉取（推荐）：
```bash
# 1. 获取云端真值key列表
curl -s http://127.0.0.1:9120/api/truths > cloud_truths.json

# 2. 批量导入本地(仅key，标记cloud来源)
python3 -c "
import json, sqlite3, time
with open('cloud_truths.json') as f:
    d = json.load(f)
conn = sqlite3.connect('data/truth.db')
c = conn.cursor()
now = time.time()
imported = 0
for key in d['truths']:
    if not key: continue
    c.execute('SELECT truth_key FROM truths WHERE truth_key=?', (key,))
    if not c.fetchone():
        c.execute('INSERT OR IGNORE INTO truths VALUES (?,?,?,?,?,?,?,1,1)',
                  (key, f'云端同步真值:{key}', '', '云端同步', 'cloud', now, now))
        imported += 1
conn.commit()
conn.close()
print(f'导入: {imported}条')
"
```

### 5.5 完整同步流程

```bash
# 1. 建立隧道
ssh -i ~/.ssh/zongyuan_cloud -f -N -L 9120:127.0.0.1:9120 root@123.207.202.158
sleep 2

# 2. 执行双向同步
cd ~/zongyuan-local
python3 homology_kernel.py sync

# 3. 验证结果
python3 homology_kernel.py status

# 4. 关闭隧道(可选)
pkill -f "9120:127.0.0.1:9120"
```

### 5.6 同步验证清单

| 验证项 | 命令 | 预期 |
|---|---|---|
| 隧道连通 | `curl -s http://127.0.0.1:9120/health` | status=healthy |
| 云端真值数 | `curl -s http://127.0.0.1:9120/api/truths \| python3 -c "import json,sys;print(json.load(sys.stdin)['count'])"` | >1700 |
| 本地真值数 | `python3 homology_kernel.py status` | total与云端接近 |
| 推送成功 | 查看sync输出 | pushed>0 |
| 拉取成功 | 查看sync输出 | imported>0 |
| 同源验证 | 推送返回status=ok | 非"非同源节点" |

---

## 6. 密钥管理与轮换

### 6.1 密钥命名规范

```
{节点ID}-{用途}-{创建日期YYYYMMDD}

示例:
- doubao-sandbox-sync-20260912        # 沙盒同步节点
- local-windows-dev-20260905           # Windows开发节点
- ci-cd-deploy-20260910                # CI/CD部署节点
- emergency-root-20260101               # 应急root密钥(唯一)
```

### 6.2 密钥生成

```bash
# 生成ed25519密钥(推荐)
ssh-keygen -t ed25519 -f ~/.ssh/zongyuan_cloud -N "" -C "doubao-sandbox-sync-20260912"

# 查看公钥
cat ~/.ssh/zongyuan_cloud.pub
```

### 6.3 密钥分发到对应用户

```bash
# 同步节点密钥 → zr-sync用户
echo "ssh-ed25519 AAAA... doubao-sandbox-sync-20260912" >> /home/zr-sync/.ssh/authorized_keys
chown zr-sync:zr-sync /home/zr-sync/.ssh/authorized_keys

# 部署节点密钥 → zr-deploy用户
echo "ssh-ed25519 AAAA... ci-cd-deploy-20260910" >> /home/zr-deploy/.ssh/authorized_keys

# 审计节点密钥 → zr-audit用户
echo "ssh-ed25519 AAAA... audit-monitor-20260908" >> /home/zr-audit/.ssh/authorized_keys
```

### 6.4 密钥轮换(90天)

```bash
# 检查密钥年龄
/opt/ZONGYUAN-ROOT/scripts/key_rotation.sh check

# 生成新密钥
/opt/ZONGYUAN-ROOT/scripts/key_rotation.sh generate <node_id> <purpose>

# 轮换步骤:
# 1. 生成新密钥对
# 2. 将新公钥添加到对应用户authorized_keys
# 3. 通知节点更新私钥并测试连接
# 4. 确认新密钥正常后，移除旧密钥
# 5. 记录轮换日志
```

### 6.5 密钥撤销

```bash
# 从指定用户移除特定密钥(按注释匹配)
sed -i '/doubao-sandbox-sync-20260912/d' /home/zr-sync/.ssh/authorized_keys

# 验证已移除
grep "doubao-sandbox-sync-20260912" /home/zr-sync/.ssh/authorized_keys || echo "已撤销"
```

---

## 7. 故障排查手册

### 7.1 SSH连接问题

| 现象 | 可能原因 | 解决方案 |
|---|---|---|
| `Connection refused` | 隧道未建立/端口错 | 检查`ssh -f -N -L`进程，确认端口映射 |
| `Permission denied (publickey)` | 密钥未授权/路径错 | 确认公钥已添加到对应用户authorized_keys |
| `非同源节点，拒绝同步` | DID/ROOT_OMEGA不匹配 | 确认payload中DID="DID-BR-000002"，ROOT_OMEGA="Ω-TAN-7-001" |
| `命令不在白名单中` | ForceCommand拦截 | 使用对应用户允许的命令，或用root执行 |
| `sshd reload后连不上` | 配置语法错 | 用备用连接登录，`sshd -t`检查语法，恢复备份配置 |

### 7.2 同步问题

| 现象 | 可能原因 | 解决方案 |
|---|---|---|
| 推送返回error | 同源验证失败 | 检查DID和ROOT_OMEGA字段 |
| 拉取很慢 | 逐个请求详情 | 改用批量key导入方式(见5.4) |
| 本地真值数不增长 | key已存在 | 正常，已存在的key跳过导入 |
| 云端真值数不增长 | 推送的key已存在 | 正常，重复key不重复计数 |
| 隧道断了同步失败 | 网络中断/SSH超时 | 重新建立隧道，检查ClientAliveInterval |

### 7.3 紧急恢复

```bash
# 1. 恢复sshd配置(如果配置错误导致无法登录)
# 通过云厂商VNC/控制台登录
cp /opt/ZONGYUAN-ROOT/backups/ssh-security-*/sshd_config /etc/ssh/
rm /etc/ssh/sshd_config.d/10-zongyuan-security.conf
systemctl restart sshd

# 2. 清除iptables规则(如果IP白名单误封)
iptables -F ZR_SSH_WL
iptables -D INPUT -p tcp --dport 22 -j ZR_SSH_WL 2>/dev/null

# 3. 应急root密钥(始终保留1个)
# 确保/root/.ssh/authorized_keys中至少有1个可信密钥
```

---

## 8. 最佳实践清单

### 8.1 安全清单

- [ ] 所有节点使用独立密钥，禁止共享
- [ ] 密钥注释包含节点ID+用途+日期
- [ ] root仅保留1个应急密钥
- [ ] 同步节点使用zr-sync用户，禁止root
- [ ] ForceCommand受限Shell已部署
- [ ] IP白名单已配置(生产环境DROP模式)
- [ ] fail2ban已安装并启用
- [ ] 密钥90天轮换机制已建立
- [ ] sshd配置修改前已备份
- [ ] reload后用新终端测试连接

### 8.2 同步清单

- [ ] SSH隧道已建立并验证连通
- [ ] 本地同源内核已初始化
- [ ] 基础真值(元法则/体系状态)已注入
- [ ] PUSH本地→云端成功
- [ ] PULL云端→本地成功
- [ ] 本地与云端真值数基本对齐
- [ ] 同步日志已记录
- [ ] 隧道使用完毕已关闭(或配置保活)

### 8.3 运维清单

- [ ] 每日检查9120网关健康状态
- [ ] 每周检查密钥过期情况
- [ ] 每月审查SSH登录日志
- [ ] 每季度执行安全配置审计
- [ ] 备份sshd配置和authorized_keys
- [ ] 记录所有节点接入/撤销操作

---

## 附录

### A. 相关文件路径

| 文件 | 路径 |
|---|---|
| 同源内核主程序 | `~/zongyuan-local/homology_kernel.py` |
| 本地真值库 | `~/zongyuan-local/data/truth.db` |
| 本地Merkle链 | `~/zongyuan-local/data/merkle_chain.json` |
| 节点配置 | `~/zongyuan-local/config/node_config.json` |
| sshd安全配置 | `/etc/ssh/sshd_config.d/10-zongyuan-security.conf` |
| 受限Shell脚本 | `/opt/ZONGYUAN-ROOT/scripts/*_node_shell.sh` |
| IP白名单 | `/opt/ZONGYUAN-ROOT/config/ssh_ip_whitelist.txt` |
| 密钥轮换脚本 | `/opt/ZONGYUAN-ROOT/scripts/key_rotation.sh` |
| 配置备份 | `/opt/ZONGYUAN-ROOT/backups/ssh-security-*/` |

### B. 9120网关API速查

| 端点 | 方法 | 功能 |
|---|---|---|
| `/health` | GET | 健康检查 |
| `/api/status` | GET | 网关状态+统计 |
| `/api/truths` | GET | 真值key列表 |
| `/api/truth/{key}` | GET | 获取单个真值 |
| `/api/truth/sync` | POST | 批量同步真值(需同源验证) |
| `/api/truth/upsert` | POST | 插入或更新真值 |
| `/api/nodes` | GET | 节点列表 |
| `/api/node/register` | POST | 节点注册(需同源验证) |
| `/api/node/heartbeat` | POST | 节点心跳 |

### C. 同源验证Payload格式

```json
{
  "DID": "DID-BR-000002",
  "ROOT_OMEGA": "Ω-TAN-7-001",
  "node_id": "LOCAL-NODE-XXXXXXXX",
  "truths": {
    "TRUTH_KEY_1": "truth value 1",
    "TRUTH_KEY_2": "truth value 2"
  }
}
```

---

**文档结束**

*本文档为ZONGYUAN-ROOT元极恒一自治体系标准作业流程，纳入全域Merkle哈希账本校验，禁止未经增量补丁的直接篡改。*

*确权: DID-BR-000002 | 溯源: Ω₀⊂⊙∞⊂Ω | 版本: V1.0*
