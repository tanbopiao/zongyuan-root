#!/bin/bash
# ZONGYUAN-ROOT SSH登录同源节点自动IP白名单检测脚本
# 用途：在SSH登录时检测连接IP，如果是同源节点则自动添加到动态白名单
# 集成方式：通过sshd_config的ForceCommand或PAM调用

DYNAMIC_WL_SCRIPT="/opt/ZONGYUAN-ROOT/scripts/dynamic_ip_whitelist.py"
LOG_FILE="/opt/ZONGYUAN-ROOT/logs/ssh_auto_ip_detect.log"

# 获取连接IP
CLIENT_IP="${SSH_CLIENT%% *}"
CLIENT_USER="${USER}"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

# 如果是本地连接，跳过
if [ "$CLIENT_IP" = "127.0.0.1" ] || [ -z "$CLIENT_IP" ]; then
    log "本地连接，跳过IP检测 (user=$CLIENT_USER)"
    exit 0
fi

log "检测到SSH连接: IP=$CLIENT_IP, user=$CLIENT_USER"

# 根据用户类型判断节点类型
case "$CLIENT_USER" in
    zr-sync)
        NODE_TYPE="sync-node"
        ;;
    zr-deploy)
        NODE_TYPE="deploy-node"
        ;;
    zr-audit)
        NODE_TYPE="audit-node"
        ;;
    zr-dev)
        NODE_TYPE="dev-node"
        ;;
    root)
        NODE_TYPE="emergency-root"
        ;;
    *)
        NODE_TYPE="unknown"
        ;;
esac

# 生成节点ID（基于IP和用户）
NODE_ID="ssh-${CLIENT_USER}-${CLIENT_IP//./-}"

# 调用动态白名单脚本添加IP
if [ -f "$DYNAMIC_WL_SCRIPT" ]; then
    python3 "$DYNAMIC_WL_SCRIPT" add "$CLIENT_IP" "$NODE_ID" "$NODE_TYPE" >> "$LOG_FILE" 2>&1
    log "IP已添加到动态白名单: $CLIENT_IP (node=$NODE_ID, type=$NODE_TYPE)"
else
    log "警告: 动态白名单脚本不存在: $DYNAMIC_WL_SCRIPT"
fi

# 执行原始命令（如果有）
if [ -n "$SSH_ORIGINAL_COMMAND" ]; then
    exec $SSH_ORIGINAL_COMMAND
else
    exec /bin/bash
fi
