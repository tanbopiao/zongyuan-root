#!/usr/bin/env python3
"""
ZONGYUAN-ROOT 本地同源内核节点 V1.0
功能：SQLite真值库 + 本地Merkle链 + 元法则引擎 + 9120双向同步
运行环境：本地电脑/沙盒
"""
import json
import os
import sys
import hashlib
import sqlite3
import time
import requests
from datetime import datetime, timezone

NODE_VERSION = "1.0.0"
DID = "DID-BR-000002"
ANCHOR = "Ω₀⊂⊙∞⊂Ω"
ROOT_OMEGA = "Ω-TAN-7-001"

class HomologyKernel:
    def __init__(self, root_dir=None):
        self.root_dir = root_dir or os.path.dirname(os.path.abspath(__file__))
        self.db_path = os.path.join(self.root_dir, "data", "truth.db")
        self.chain_path = os.path.join(self.root_dir, "data", "merkle_chain.json")
        self.config_path = os.path.join(self.root_dir, "config", "node_config.json")
        self.gateway_url = "http://127.0.0.1:9120"
        self._init_storage()
    
    def _now(self):
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    
    def _hash(self, data):
        if isinstance(data, dict):
            raw = json.dumps(data, sort_keys=True, ensure_ascii=False).encode()
        else:
            raw = str(data).encode()
        return hashlib.sha256(raw).hexdigest()
    
    def _init_storage(self):
        os.makedirs(os.path.join(self.root_dir, "data"), exist_ok=True)
        os.makedirs(os.path.join(self.root_dir, "logs"), exist_ok=True)
        os.makedirs(os.path.join(self.root_dir, "config"), exist_ok=True)
        
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS truths (
            truth_key TEXT PRIMARY KEY,
            truth_value TEXT NOT NULL,
            truth_hash TEXT,
            category TEXT,
            source TEXT DEFAULT 'local',
            created_at REAL,
            updated_at REAL,
            version INTEGER DEFAULT 1,
            synced INTEGER DEFAULT 0
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_category ON truths(category)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_synced ON truths(synced)")
        conn.commit()
        conn.close()
        
        if not os.path.exists(self.chain_path):
            genesis = {"blocks": [{"block_id": 0, "snapshot_id": "GENESIS-LOCAL", 
                "merkle_root": self._hash("ZONGYUAN-LOCAL-GENESIS"), "timestamp": self._now()}],
                "length": 1}
            with open(self.chain_path, "w") as f:
                json.dump(genesis, f, ensure_ascii=False, indent=2)
        
        if not os.path.exists(self.config_path):
            config = {"node_id": f"LOCAL-NODE-{self._hash(str(time.time()))[:8].upper()}",
                "version": NODE_VERSION, "did": DID, "anchor": ANCHOR,
                "gateway_url": self.gateway_url, "created_at": self._now()}
            with open(self.config_path, "w") as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
    
    def add_truth(self, key, value, category="数据类", source="local"):
        truth_hash = self._hash(value)
        now = time.time()
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("""INSERT OR REPLACE INTO truths VALUES (?,?,?,?,?,?,?,1,0)""",
                  (key, value, truth_hash, category, source, now, now))
        conn.commit()
        conn.close()
        return key
    
    def get_truth(self, key):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM truths WHERE truth_key=?", (key,))
        row = c.fetchone()
        conn.close()
        return dict(row) if row else None
    
    def list_truths(self, limit=100, category=None):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        if category:
            c.execute("SELECT * FROM truths WHERE category=? ORDER BY updated_at DESC LIMIT ?", (category, limit))
        else:
            c.execute("SELECT * FROM truths ORDER BY updated_at DESC LIMIT ?", (limit,))
        rows = c.fetchall()
        conn.close()
        return [dict(r) for r in rows]
    
    def get_stats(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT COUNT(*) FROM truths")
        total = c.fetchone()[0]
        c.execute("SELECT COUNT(*) FROM truths WHERE synced=1")
        synced = c.fetchone()[0]
        conn.close()
        return {"total": total, "synced": synced, "unsynced": total - synced}
    
    def push_to_cloud(self, gateway_url=None):
        url = gateway_url or self.gateway_url
        unsynced = self.list_truths(limit=1000)
        unsynced = [t for t in unsynced if t["synced"] == 0]
        if not unsynced:
            return {"success": True, "pushed": 0, "message": "无待推送数据"}
        
        truths_dict = {t["truth_key"]: t["truth_value"] for t in unsynced}
        payload = {"DID": DID, "ROOT_OMEGA": ROOT_OMEGA,
                   "node_id": self._load_config()["node_id"], "truths": truths_dict}
        
        try:
            resp = requests.post(f"{url}/api/truth/sync", json=payload, timeout=15)
            data = resp.json()
            if data.get("status") == "ok":
                conn = sqlite3.connect(self.db_path)
                c = conn.cursor()
                for t in unsynced:
                    c.execute("UPDATE truths SET synced=1 WHERE truth_key=?", (t["truth_key"],))
                conn.commit()
                conn.close()
                return {"success": True, "pushed": len(unsynced), "cloud_total": data.get("total")}
            return {"success": False, "error": data.get("msg", "未知错误")}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def pull_from_cloud(self, gateway_url=None):
        url = gateway_url or self.gateway_url
        try:
            resp = requests.get(f"{url}/api/truths", timeout=15)
            data = resp.json()
            if data.get("status") != "ok":
                return {"success": False, "error": "云端返回错误"}
            
            cloud_keys = data.get("truths", [])
            imported = 0
            for key in cloud_keys:
                if not key or self.get_truth(key):
                    continue
                try:
                    detail_resp = requests.get(f"{url}/api/truth/{key}", timeout=5)
                    detail = detail_resp.json()
                    if detail.get("status") == "ok" and detail.get("truth"):
                        t = detail["truth"]
                        self.add_truth(t.get("truth_key", key), t.get("truth_value", ""),
                                      t.get("category", "云端同步"), source="cloud")
                        conn = sqlite3.connect(self.db_path)
                        c = conn.cursor()
                        c.execute("UPDATE truths SET synced=1 WHERE truth_key=?", (key,))
                        conn.commit()
                        conn.close()
                        imported += 1
                except:
                    continue
            return {"success": True, "cloud_total": len(cloud_keys), "imported": imported}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def sync_all(self, gateway_url=None):
        pull = self.pull_from_cloud(gateway_url)
        push = self.push_to_cloud(gateway_url)
        return {"pull": pull, "push": push, "stats": self.get_stats()}
    
    def _load_config(self):
        with open(self.config_path) as f:
            return json.load(f)
    
    def get_status(self):
        config = self._load_config()
        return {"node_id": config["node_id"], "version": NODE_VERSION,
                "did": DID, "anchor": ANCHOR, "gateway": self.gateway_url,
                "stats": self.get_stats()}

if __name__ == "__main__":
    kernel = HomologyKernel()
    if len(sys.argv) < 2:
        print(json.dumps(kernel.get_status(), ensure_ascii=False, indent=2))
    elif sys.argv[1] == "add":
        print(kernel.add_truth(sys.argv[2], sys.argv[3], sys.argv[4] if len(sys.argv)>4 else "数据类"))
    elif sys.argv[1] == "list":
        print(json.dumps(kernel.list_truths(), ensure_ascii=False, indent=2))
    elif sys.argv[1] == "sync":
        print(json.dumps(kernel.sync_all(), ensure_ascii=False, indent=2))
    elif sys.argv[1] == "status":
        print(json.dumps(kernel.get_status(), ensure_ascii=False, indent=2))
