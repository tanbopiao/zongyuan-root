#!/usr/bin/env python3
"""
ZONGYUAN-ROOT 短剧工业化API服务 V2.0
统一API网关，整合7大模块：
- 角色卡系统 (8628)
- 多模型路由调度器 (8629)
- 关键帧生成器 (8630)
- 世界观管理引擎 (8631)
- 剧本生成器 (8632)
- 分镜表生成器 (8633)
- 成片率监控 (8634)

运行: python3 drama_api.py
端口: 8628 (统一网关)
"""
import json
import os
import sys
import time
import hashlib
import sqlite3
import uuid
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# ========== 常量 ==========
DID = "DID-BR-000002"
ANCHOR = "Ω₀⊂⊙∞⊂Ω"
API_VERSION = "2.0.0"
DB_PATH = os.environ.get("DRAMA_DB_PATH", "/opt/ZONGYUAN-ROOT/data/drama_pipeline.db")

# ========== 数据库初始化 ==========
def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # 角色卡表
    c.execute("""CREATE TABLE IF NOT EXISTS character_cards (
        card_id TEXT PRIMARY KEY,
        character_name TEXT NOT NULL,
        character_type TEXT,
        appearance TEXT,
        personality TEXT,
        background TEXT,
        costume TEXT,
        reference_images TEXT,
        style_tags TEXT,
        consistency_hash TEXT,
        created_at REAL,
        updated_at REAL,
        version INTEGER DEFAULT 1
    )""")
    
    # 世界观表
    c.execute("""CREATE TABLE IF NOT EXISTS worldviews (
        world_id TEXT PRIMARY KEY,
        world_name TEXT NOT NULL,
        genre TEXT,
        era TEXT,
        geography TEXT,
        factions TEXT,
        power_system TEXT,
        rules TEXT,
        timeline TEXT,
        created_at REAL,
        updated_at REAL
    )""")
    
    # 剧本表
    c.execute("""CREATE TABLE IF NOT EXISTS scripts (
        script_id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        episode INTEGER,
        world_id TEXT,
        synopsis TEXT,
        scenes TEXT,
        characters TEXT,
        dialogue TEXT,
        status TEXT DEFAULT 'draft',
        created_at REAL,
        updated_at REAL
    )""")
    
    # 分镜表
    c.execute("""CREATE TABLE IF NOT EXISTS storyboards (
        shot_id TEXT PRIMARY KEY,
        script_id TEXT,
        episode INTEGER,
        scene_no INTEGER,
        shot_no INTEGER,
        shot_type TEXT,
        camera_movement TEXT,
        description TEXT,
        dialogue TEXT,
        duration INTEGER,
        characters TEXT,
        keyframe_prompt TEXT,
        status TEXT DEFAULT 'pending',
        created_at REAL
    )""")
    
    # 关键帧表
    c.execute("""CREATE TABLE IF NOT EXISTS keyframes (
        keyframe_id TEXT PRIMARY KEY,
        shot_id TEXT,
        script_id TEXT,
        episode INTEGER,
        prompt TEXT,
        negative_prompt TEXT,
        model TEXT,
        image_url TEXT,
        seed INTEGER,
        width INTEGER,
        height INTEGER,
        style TEXT,
        quality_score REAL,
        status TEXT DEFAULT 'pending',
        created_at REAL
    )""")
    
    # 模型路由表
    c.execute("""CREATE TABLE IF NOT EXISTS model_routes (
        route_id TEXT PRIMARY KEY,
        task_type TEXT,
        model_name TEXT,
        priority INTEGER,
        cost_per_call REAL,
        avg_latency REAL,
        success_rate REAL,
        enabled INTEGER DEFAULT 1,
        updated_at REAL
    )""")
    
    # 成片率监控表
    c.execute("""CREATE TABLE IF NOT EXISTS quality_metrics (
        metric_id TEXT PRIMARY KEY,
        episode INTEGER,
        total_shots INTEGER,
        generated_shots INTEGER,
        accepted_shots INTEGER,
        rejected_shots INTEGER,
        avg_quality_score REAL,
        generation_time REAL,
        cost REAL,
        success_rate REAL,
        created_at REAL
    )""")
    
    # 任务队列表
    c.execute("""CREATE TABLE IF NOT EXISTS tasks (
        task_id TEXT PRIMARY KEY,
        task_type TEXT,
        status TEXT DEFAULT 'pending',
        params TEXT,
        result TEXT,
        error TEXT,
        created_at REAL,
        completed_at REAL
    )""")
    
    conn.commit()
    conn.close()

# ========== 工具函数 ==========
def now_ts() -> float:
    return time.time()

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def gen_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12].upper()}"

def sha256(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()

def db_execute(query: str, params: tuple = ()):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute(query, params)
    conn.commit()
    result = c.fetchall()
    conn.close()
    return [dict(r) for r in result]

# ========== Pydantic模型 ==========
class CharacterCardCreate(BaseModel):
    character_name: str
    character_type: Optional[str] = "main"
    appearance: Optional[str] = ""
    personality: Optional[str] = ""
    background: Optional[str] = ""
    costume: Optional[str] = ""
    style_tags: Optional[str] = ""

class WorldviewCreate(BaseModel):
    world_name: str
    genre: Optional[str] = "xianxia"
    era: Optional[str] = ""
    geography: Optional[str] = ""
    factions: Optional[str] = ""
    power_system: Optional[str] = ""
    rules: Optional[str] = ""

class ScriptCreate(BaseModel):
    title: str
    episode: Optional[int] = 1
    world_id: Optional[str] = ""
    synopsis: Optional[str] = ""
    scenes: Optional[str] = ""

class StoryboardCreate(BaseModel):
    script_id: str
    episode: Optional[int] = 1
    scene_no: Optional[int] = 1
    shot_no: Optional[int] = 1
    shot_type: Optional[str] = "medium"
    description: Optional[str] = ""
    dialogue: Optional[str] = ""
    duration: Optional[int] = 5

class KeyframeCreate(BaseModel):
    shot_id: Optional[str] = ""
    script_id: Optional[str] = ""
    episode: Optional[int] = 1
    prompt: str
    negative_prompt: Optional[str] = ""
    model: Optional[str] = "seedream"
    width: Optional[int] = 1080
    height: Optional[int] = 1920
    style: Optional[str] = "guofeng"

class ModelRouteCreate(BaseModel):
    task_type: str
    model_name: str
    priority: Optional[int] = 5
    cost_per_call: Optional[float] = 0.0
    enabled: Optional[int] = 1

class ModelSelectRequest(BaseModel):
    task_type: str

class QualityReport(BaseModel):
    episode: int
    total_shots: int
    generated_shots: int
    accepted_shots: int
    rejected_shots: Optional[int] = 0
    avg_quality_score: Optional[float] = 0.0
    generation_time: Optional[float] = 0.0
    cost: Optional[float] = 0.0

# ========== FastAPI应用 ==========
app = FastAPI(
    title="ZONGYUAN-ROOT 短剧工业化API",
    description="火斗云智AIOS 短剧工业化生产流水线统一API网关",
    version=API_VERSION,
    docs_url="/docs",
    redoc_url="/redoc"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ========== 启动事件 ==========
@app.on_event("startup")
async def startup_event():
    init_db()
    print(f"[{now_iso()}] 短剧工业化API服务启动 v{API_VERSION}")
    print(f"[{now_iso()}] 数据库: {DB_PATH}")
    print(f"[{now_iso()}] DID: {DID} | 锚点: {ANCHOR}")

# ========== 健康检查 ==========
@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "service": "drama-industrial-api",
        "version": API_VERSION,
        "did": DID,
        "anchor": ANCHOR,
        "timestamp": now_iso()
    }

@app.get("/api/status")
async def api_status():
    stats = {
        "characters": len(db_execute("SELECT card_id FROM character_cards")),
        "worldviews": len(db_execute("SELECT world_id FROM worldviews")),
        "scripts": len(db_execute("SELECT script_id FROM scripts")),
        "storyboards": len(db_execute("SELECT shot_id FROM storyboards")),
        "keyframes": len(db_execute("SELECT keyframe_id FROM keyframes")),
        "tasks": len(db_execute("SELECT task_id FROM tasks")),
    }
    return {"status": "ok", "stats": stats, "timestamp": now_iso()}

# ========== 1. 角色卡系统 ==========
@app.post("/api/character/create")
async def create_character(card: CharacterCardCreate):
    card_id = gen_id("CHAR")
    consistency_hash = sha256(f"{card.character_name}{card.appearance}{card.costume}")
    db_execute("""INSERT INTO character_cards VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1)""",
               (card_id, card.character_name, card.character_type, card.appearance,
                card.personality, card.background, card.costume, "", card.style_tags,
                consistency_hash, now_ts(), now_ts()))
    return {"status": "ok", "card_id": card_id, "consistency_hash": consistency_hash}

@app.get("/api/character/list")
async def list_characters(limit: int = 50):
    cards = db_execute("SELECT * FROM character_cards ORDER BY updated_at DESC LIMIT ?", (limit,))
    return {"status": "ok", "count": len(cards), "characters": cards}

@app.get("/api/character/{card_id}")
async def get_character(card_id: str):
    cards = db_execute("SELECT * FROM character_cards WHERE card_id=?", (card_id,))
    if not cards:
        raise HTTPException(status_code=404, detail="角色卡不存在")
    return {"status": "ok", "character": cards[0]}

# ========== 2. 世界观管理引擎 ==========
@app.post("/api/worldview/create")
async def create_worldview(wv: WorldviewCreate):
    world_id = gen_id("WORLD")
    db_execute("""INSERT INTO worldviews VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
               (world_id, wv.world_name, wv.genre, wv.era, wv.geography,
                wv.factions, wv.power_system, wv.rules, "", now_ts(), now_ts()))
    return {"status": "ok", "world_id": world_id}

@app.get("/api/worldview/list")
async def list_worldviews(limit: int = 20):
    worlds = db_execute("SELECT * FROM worldviews ORDER BY updated_at DESC LIMIT ?", (limit,))
    return {"status": "ok", "count": len(worlds), "worldviews": worlds}

# ========== 3. 剧本生成器 ==========
@app.post("/api/script/create")
async def create_script(script: ScriptCreate):
    script_id = gen_id("SCRIPT")
    db_execute("""INSERT INTO scripts VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
               (script_id, script.title, script.episode, script.world_id,
                script.synopsis, script.scenes, "", "", "draft", now_ts(), now_ts()))
    return {"status": "ok", "script_id": script_id}

@app.get("/api/script/list")
async def list_scripts(limit: int = 20):
    scripts = db_execute("SELECT * FROM scripts ORDER BY updated_at DESC LIMIT ?", (limit,))
    return {"status": "ok", "count": len(scripts), "scripts": scripts}

@app.get("/api/script/{script_id}")
async def get_script(script_id: str):
    scripts = db_execute("SELECT * FROM scripts WHERE script_id=?", (script_id,))
    if not scripts:
        raise HTTPException(status_code=404, detail="剧本不存在")
    return {"status": "ok", "script": scripts[0]}

# ========== 4. 分镜表生成器 ==========
@app.post("/api/storyboard/create")
async def create_storyboard(sb: StoryboardCreate):
    shot_id = gen_id("SHOT")
    # 自动生成关键帧提示词
    keyframe_prompt = f"国风仙侠，{sb.description}，镜头类型:{sb.shot_type}，运镜:{sb.camera_movement if hasattr(sb, 'camera_movement') else 'static'}"
    db_execute("""INSERT INTO storyboards VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
               (shot_id, sb.script_id, sb.episode, sb.scene_no, sb.shot_no,
                sb.shot_type, "", sb.description, sb.dialogue, sb.duration,
                "", keyframe_prompt, "pending", now_ts()))
    return {"status": "ok", "shot_id": shot_id, "keyframe_prompt": keyframe_prompt}

@app.get("/api/storyboard/list")
async def list_storyboards(script_id: str = "", limit: int = 100):
    if script_id:
        shots = db_execute("SELECT * FROM storyboards WHERE script_id=? ORDER BY scene_no, shot_no LIMIT ?",
                           (script_id, limit))
    else:
        shots = db_execute("SELECT * FROM storyboards ORDER BY created_at DESC LIMIT ?", (limit,))
    return {"status": "ok", "count": len(shots), "storyboards": shots}

# ========== 5. 关键帧生成器 ==========
@app.post("/api/keyframe/create")
async def create_keyframe(kf: KeyframeCreate):
    keyframe_id = gen_id("KF")
    seed = int(time.time() * 1000) % 2147483647
    db_execute("""INSERT INTO keyframes VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
               (keyframe_id, kf.shot_id, kf.script_id, kf.episode, kf.prompt,
                kf.negative_prompt, kf.model, "", seed, kf.width, kf.height,
                kf.style, 0.0, "pending", now_ts()))
    return {"status": "ok", "keyframe_id": keyframe_id, "seed": seed, "status": "pending"}

@app.get("/api/keyframe/list")
async def list_keyframes(script_id: str = "", limit: int = 50):
    if script_id:
        kfs = db_execute("SELECT * FROM keyframes WHERE script_id=? ORDER BY created_at DESC LIMIT ?",
                        (script_id, limit))
    else:
        kfs = db_execute("SELECT * FROM keyframes ORDER BY created_at DESC LIMIT ?", (limit,))
    return {"status": "ok", "count": len(kfs), "keyframes": kfs}

@app.post("/api/keyframe/{keyframe_id}/complete")
async def complete_keyframe(keyframe_id: str, image_url: str = "", quality_score: float = 0.8):
    db_execute("UPDATE keyframes SET image_url=?, quality_score=?, status='completed' WHERE keyframe_id=?",
               (image_url, quality_score, keyframe_id))
    return {"status": "ok", "keyframe_id": keyframe_id, "quality_score": quality_score}

# ========== 6. 多模型路由调度器 ==========
@app.post("/api/model-route/register")
async def register_model_route(route: ModelRouteCreate):
    route_id = gen_id("ROUTE")
    db_execute("""INSERT INTO model_routes VALUES (?,?,?,?,?,?,?,?,?)""",
               (route_id, route.task_type, route.model_name, route.priority,
                route.cost_per_call, 0.0, 1.0, route.enabled, now_ts()))
    return {"status": "ok", "route_id": route_id}

@app.get("/api/model-route/list")
async def list_model_routes(task_type: str = ""):
    if task_type:
        routes = db_execute("SELECT * FROM model_routes WHERE task_type=? AND enabled=1 ORDER BY priority DESC",
                            (task_type,))
    else:
        routes = db_execute("SELECT * FROM model_routes ORDER BY task_type, priority DESC")
    return {"status": "ok", "count": len(routes), "routes": routes}

@app.post("/api/model-route/select")
async def select_model(req: ModelSelectRequest):
    routes = db_execute("SELECT * FROM model_routes WHERE task_type=? AND enabled=1 ORDER BY priority DESC LIMIT 1",
                        (req.task_type,))
    if not routes:
        return {"status": "fallback", "model": "default", "reason": "无匹配路由，使用默认模型"}
    return {"status": "ok", "selected_model": routes[0]["model_name"], "route": routes[0]}

# ========== 7. 成片率监控 ==========
@app.post("/api/quality/report")
async def report_quality(req: QualityReport):
    metric_id = gen_id("QUAL")
    success_rate = req.accepted_shots / req.total_shots if req.total_shots > 0 else 0
    db_execute("""INSERT INTO quality_metrics VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
               (metric_id, req.episode, req.total_shots, req.generated_shots, req.accepted_shots,
                req.rejected_shots, req.avg_quality_score, req.generation_time, req.cost, success_rate, now_ts()))
    return {"status": "ok", "metric_id": metric_id, "success_rate": f"{success_rate*100:.1f}%"}

@app.get("/api/quality/stats")
async def quality_stats(episode: int = 0):
    if episode > 0:
        metrics = db_execute("SELECT * FROM quality_metrics WHERE episode=? ORDER BY created_at DESC", (episode,))
    else:
        metrics = db_execute("SELECT * FROM quality_metrics ORDER BY created_at DESC LIMIT 20")
    
    if metrics:
        avg_success = sum(m["success_rate"] for m in metrics) / len(metrics)
        total_accepted = sum(m["accepted_shots"] for m in metrics)
        total_shots = sum(m["total_shots"] for m in metrics)
        return {
            "status": "ok",
            "episodes_reported": len(metrics),
            "overall_success_rate": f"{avg_success*100:.1f}%",
            "total_accepted_shots": total_accepted,
            "total_planned_shots": total_shots,
            "latest": metrics[0]
        }
    return {"status": "ok", "message": "暂无质量数据"}

# ========== 任务队列 ==========
@app.post("/api/task/create")
async def create_task(task_type: str, params: dict = {}):
    task_id = gen_id("TASK")
    db_execute("INSERT INTO tasks VALUES (?,?,?,?,?,?,?,?)",
               (task_id, task_type, "pending", json.dumps(params), "", "", now_ts(), 0))
    return {"status": "ok", "task_id": task_id}

@app.get("/api/task/{task_id}")
async def get_task(task_id: str):
    tasks = db_execute("SELECT * FROM tasks WHERE task_id=?", (task_id,))
    if not tasks:
        raise HTTPException(status_code=404, detail="任务不存在")
    return {"status": "ok", "task": tasks[0]}

# ========== 流水线总览 ==========
@app.get("/api/pipeline/overview")
async def pipeline_overview():
    stats = {
        "characters": len(db_execute("SELECT card_id FROM character_cards")),
        "worldviews": len(db_execute("SELECT world_id FROM worldviews")),
        "scripts": len(db_execute("SELECT script_id FROM scripts")),
        "storyboards": len(db_execute("SELECT shot_id FROM storyboards")),
        "keyframes_pending": len(db_execute("SELECT keyframe_id FROM keyframes WHERE status='pending'")),
        "keyframes_completed": len(db_execute("SELECT keyframe_id FROM keyframes WHERE status='completed'")),
        "model_routes": len(db_execute("SELECT route_id FROM model_routes WHERE enabled=1")),
        "tasks_pending": len(db_execute("SELECT task_id FROM tasks WHERE status='pending'")),
    }
    return {
        "status": "ok",
        "pipeline": "短剧工业化V2.0",
        "stats": stats,
        "modules": ["角色卡", "世界观", "剧本", "分镜", "关键帧", "模型路由", "成片率监控"],
        "timestamp": now_iso()
    }

# ========== 主入口 ==========
if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("DRAMA_API_PORT", "8628"))
    print(f"=" * 60)
    print(f"ZONGYUAN-ROOT 短剧工业化API服务 v{API_VERSION}")
    print(f"端口: {port}")
    print(f"DID: {DID}")
    print(f"锚点: {ANCHOR}")
    print(f"=" * 60)
    uvicorn.run(app, host="0.0.0.0", port=port, log_level="info")
