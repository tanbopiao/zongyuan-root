#!/usr/bin/env python3
"""
ZONGYUAN-ROOT 同源节点动态IP白名单管理系统 V1.0
功能：同源节点连接时自动验证，验证通过自动开放IP，离线自动清理
运行：云服务器后台守护进程
"""
import json
import os
import sys
import time
import sqlite3
import hashlib
import subprocess
import logging
import requests
from datetime import datetime, timezone, timedelta
from typing import Optional, List, Dict, Any

# ========== 常量 ==========
DID = "DID-BR-000002"
ROOT_OMEGA = "Ω-TAN-7-001"
ANCHOR = "Ω₀⊂⊙∞⊂Ω"
GATEWAY_URL = "http://127.0.0.1:9120"
IPTABLES_CHAIN = "ZR_SSH_DYNAMIC_WL"
IP_EXPIRE_MINUTES = 30  # IP过期时间（分钟），节点心跳超时后自动移除
SYNC_INTERVAL = 60      # iptables同步间隔（秒）
CLEANUP_INTERVAL = 300  # 过期IP清理间隔（秒）

# ========== 日志配置 ==========
LOG_DIR = "/opt/ZONGYUAN-ROOT/logs"
os.makedirs(LOG_DIR, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(LOG_DIR, "dynamic_ip_whitelist.log")),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("DynamicIPWhitelist")


class DynamicIPWhitelist:
    """动态IP白名单管理引擎"""

    def __init__(self, db_path: str = "/opt/ZONGYUAN-ROOT/data/dynamic_ip_whitelist.db"):
        self.db_path = db_path
        self._init_db()
        self._init_iptables()

    def _now(self) -> float:
        return time.time()

    def _now_iso(self) -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    def _init_db(self):
        """初始化IP白名单数据库"""
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS allowed_ips (
            ip TEXT PRIMARY KEY,
            node_id TEXT,
            node_type TEXT,
            did TEXT,
            verified_at REAL,
            last_heartbeat REAL,
            expire_at REAL,
            source TEXT,
            trust_level INTEGER DEFAULT 1
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            action TEXT,
            ip TEXT,
            node_id TEXT,
            detail TEXT,
            timestamp REAL
        )""")
        c.execute("CREATE INDEX IF NOT EXISTS idx_expire ON allowed_ips(expire_at)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_heartbeat ON allowed_ips(last_heartbeat)")
        conn.commit()
        conn.close()
        logger.info("数据库初始化完成: %s", self.db_path)

    def _init_iptables(self):
        """初始化iptables自定义链"""
        try:
            # 检查链是否存在
            result = subprocess.run(
                ["iptables", "-L", IPTABLES_CHAIN, "-n"],
                capture_output=True, text=True
            )
            if result.returncode != 0:
                # 创建链
                subprocess.run(["iptables", "-N", IPTABLES_CHAIN], check=True)
                # 绑定到INPUT链的22端口
                subprocess.run([
                    "iptables", "-I", "INPUT", "1", "-p", "tcp", "--dport", "22",
                    "-j", IPTABLES_CHAIN
                ], check=True)
                logger.info("iptables链 %s 创建并绑定完成", IPTABLES_CHAIN)
            else:
                logger.info("iptables链 %s 已存在", IPTABLES_CHAIN)
        except Exception as e:
            logger.error("iptables初始化失败: %s", e)

    def _audit(self, action: str, ip: str, node_id: str = "", detail: str = ""):
        """记录审计日志"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("INSERT INTO audit_log VALUES (NULL,?,?,?,?,?)",
                  (action, ip, node_id, detail, self._now()))
        conn.commit()
        conn.close()

    # ========== 同源验证 ==========

    def verify_homology(self, did: str, root_omega: str, 
                        node_id: str = "", signature: str = "") -> bool:
        """
        同源节点身份验证
        验证DID和ROOT_OMEGA是否匹配
        """
        if did != DID:
            logger.warning("同源验证失败: DID不匹配 (%s != %s)", did, DID)
            return False
        if root_omega != ROOT_OMEGA:
            logger.warning("同源验证失败: ROOT_OMEGA不匹配")
            return False
        logger.info("同源验证通过: node_id=%s, did=%s", node_id or "unknown", did)
        return True

    def verify_via_gateway(self, node_id: str, did: str, 
                           root_omega: str) -> bool:
        """通过9120网关验证节点身份"""
        try:
            # 先本地验证
            if not self.verify_homology(did, root_omega, node_id):
                return False
            # 再通过网关验证节点是否已注册
            resp = requests.get(f"{GATEWAY_URL}/api/nodes", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                nodes = data.get("nodes", [])
                for node in nodes:
                    if node.get("node_id") == node_id and node.get("status") == "active":
                        return True
                logger.warning("节点未在网关注册或非活跃: %s", node_id)
                return False
            return True  # 网关不可达时，本地验证通过即可
        except Exception as e:
            logger.warning("网关验证异常，使用本地验证结果: %s", e)
            return self.verify_homology(did, root_omega, node_id)

    # ========== IP管理 ==========

    def add_ip(self, ip: str, node_id: str, node_type: str = "unknown",
               did: str = DID, source: str = "auto", 
               trust_level: int = 1) -> bool:
        """
        添加IP到白名单
        自动设置过期时间
        """
        if not ip or ip in ["127.0.0.1", "::1"]:
            return False  # 本地IP不需要添加

        now = self._now()
        expire_at = now + (IP_EXPIRE_MINUTES * 60)

        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("""INSERT OR REPLACE INTO allowed_ips 
                    VALUES (?,?,?,?,?,?,?,?,?)""",
                  (ip, node_id, node_type, did, now, now, expire_at, source, trust_level))
        conn.commit()
        conn.close()

        # 同步到iptables
        self._add_iptables_rule(ip)
        self._audit("ADD", ip, node_id, f"节点{node_type}，过期{IP_EXPIRE_MINUTES}分钟")
        logger.info("IP已添加到白名单: %s (node=%s, expire=%s)", 
                    ip, node_id, datetime.fromtimestamp(expire_at).isoformat())
        return True

    def remove_ip(self, ip: str, reason: str = "expired") -> bool:
        """从白名单移除IP"""
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT node_id FROM allowed_ips WHERE ip=?", (ip,))
        row = c.fetchone()
        node_id = row[0] if row else ""
        c.execute("DELETE FROM allowed_ips WHERE ip=?", (ip,))
        conn.commit()
        conn.close()

        self._remove_iptables_rule(ip)
        self._audit("REMOVE", ip, node_id, reason)
        logger.info("IP已从白名单移除: %s (reason=%s)", ip, reason)
        return True

    def heartbeat(self, ip: str, node_id: str) -> bool:
        """
        节点心跳：更新最后心跳时间和过期时间
        这是保持IP白名单有效的关键
        """
        now = self._now()
        expire_at = now + (IP_EXPIRE_MINUTES * 60)

        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("""UPDATE allowed_ips 
                    SET last_heartbeat=?, expire_at=? 
                    WHERE ip=? AND node_id=?""",
                  (now, expire_at, ip, node_id))
        if c.rowcount == 0:
            # IP不在白名单，自动添加
            conn.close()
            return self.add_ip(ip, node_id, source="heartbeat_auto")
        conn.commit()
        conn.close()
        logger.debug("心跳更新: %s (node=%s)", ip, node_id)
        return True

    def get_allowed_ips(self) -> List[dict]:
        """获取当前所有允许的IP"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM allowed_ips ORDER BY last_heartbeat DESC")
        rows = c.fetchall()
        conn.close()
        return [dict(r) for r in rows]

    def get_audit_log(self, limit: int = 100) -> List[dict]:
        """获取审计日志"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,))
        rows = c.fetchall()
        conn.close()
        return [dict(r) for r in rows]

    # ========== iptables同步 ==========

    def _add_iptables_rule(self, ip: str):
        """添加iptables规则"""
        try:
            # 检查是否已存在
            result = subprocess.run(
                ["iptables", "-C", IPTABLES_CHAIN, "-s", ip, "-j", "ACCEPT"],
                capture_output=True
            )
            if result.returncode != 0:
                subprocess.run([
                    "iptables", "-A", IPTABLES_CHAIN, "-s", ip, "-j", "ACCEPT"
                ], check=True)
        except Exception as e:
            logger.error("添加iptables规则失败 %s: %s", ip, e)

    def _remove_iptables_rule(self, ip: str):
        """移除iptables规则"""
        try:
            subprocess.run([
                "iptables", "-D", IPTABLES_CHAIN, "-s", ip, "-j", "ACCEPT"
            ], capture_output=True)
        except Exception as e:
            logger.debug("移除iptables规则 %s: %s", ip, e)

    def sync_iptables(self):
        """将数据库中的IP同步到iptables"""
        allowed = self.get_allowed_ips()
        # 确保所有允许的IP都有规则
        for item in allowed:
            self._add_iptables_rule(item["ip"])
        logger.debug("iptables同步完成: %d个IP", len(allowed))

    def cleanup_expired(self):
        """清理过期IP"""
        now = self._now()
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT ip, node_id FROM allowed_ips WHERE expire_at < ?", (now,))
        expired = c.fetchall()
        for ip, node_id in expired:
            self._remove_iptables_rule(ip)
            self._audit("EXPIRE", ip, node_id, "心跳超时自动移除")
        c.execute("DELETE FROM allowed_ips WHERE expire_at < ?", (now,))
        conn.commit()
        conn.close()
        if expired:
            logger.info("清理过期IP: %d个", len(expired))

    # ========== 从9120网关同步节点IP ==========

    def sync_from_gateway(self):
        """
        从9120网关获取活跃节点，自动添加其IP
        注意：网关节点注册可能不记录源IP，这里主要通过心跳接口
        """
        try:
            resp = requests.get(f"{GATEWAY_URL}/api/nodes", timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                nodes = data.get("nodes", [])
                logger.info("从网关注册中心获取节点: %d个", len(nodes))
                # 注意：节点注册不记录源IP，需要通过心跳或SSH连接时获取
                # 这里仅记录节点信息，IP在实际连接时添加
        except Exception as e:
            logger.warning("从网关同步节点失败: %s", e)

    # ========== 守护进程主循环 ==========

    def run_daemon(self):
        """运行守护进程"""
        logger.info("=" * 60)
        logger.info("动态IP白名单守护进程启动")
        logger.info("DID: %s", DID)
        logger.info("ROOT_OMEGA: %s", ROOT_OMEGA)
        logger.info("IP过期时间: %d分钟", IP_EXPIRE_MINUTES)
        logger.info("iptables链: %s", IPTABLES_CHAIN)
        logger.info("=" * 60)

        last_cleanup = 0
        while True:
            try:
                # 同步iptables
                self.sync_iptables()

                # 定期清理过期IP
                now = self._now()
                if now - last_cleanup > CLEANUP_INTERVAL:
                    self.cleanup_expired()
                    last_cleanup = now

                time.sleep(SYNC_INTERVAL)
            except KeyboardInterrupt:
                logger.info("守护进程收到中断信号，退出")
                break
            except Exception as e:
                logger.error("守护进程异常: %s", e)
                time.sleep(10)

    # ========== 命令行接口 ==========

    def cmd_status(self):
        """查看状态"""
        allowed = self.get_allowed_ips()
        print(f"\n{'='*60}")
        print(f"动态IP白名单状态")
        print(f"{'='*60}")
        print(f"当前允许IP数: {len(allowed)}")
        print(f"IP过期时间: {IP_EXPIRE_MINUTES}分钟")
        print(f"iptables链: {IPTABLES_CHAIN}")
        print(f"\n允许的IP列表:")
        for item in allowed:
            expire_str = datetime.fromtimestamp(item["expire_at"]).strftime("%Y-%m-%d %H:%M:%S")
            print(f"  {item['ip']:18s} | {item['node_id']:30s} | {item['node_type']:10s} | 过期: {expire_str}")
        print(f"{'='*60}\n")

    def cmd_add(self, ip: str, node_id: str, node_type: str = "manual"):
        """手动添加IP"""
        if self.add_ip(ip, node_id, node_type, source="manual"):
            print(f"✅ IP {ip} 已添加到白名单 (node={node_id})")
        else:
            print(f"❌ IP {ip} 添加失败")

    def cmd_remove(self, ip: str):
        """手动移除IP"""
        if self.remove_ip(ip, "manual_remove"):
            print(f"✅ IP {ip} 已从白名单移除")
        else:
            print(f"❌ IP {ip} 移除失败")

    def cmd_audit(self, limit: int = 50):
        """查看审计日志"""
        logs = self.get_audit_log(limit)
        print(f"\n最近{len(logs)}条审计日志:")
        for log in logs:
            time_str = datetime.fromtimestamp(log["timestamp"]).strftime("%H:%M:%S")
            print(f"  [{time_str}] {log['action']:8s} | {log['ip']:18s} | {log['node_id']:25s} | {log['detail']}")

    def cmd_verify(self, did: str, root_omega: str, node_id: str = ""):
        """测试同源验证"""
        result = self.verify_homology(did, root_omega, node_id)
        print(f"同源验证结果: {'✅ 通过' if result else '❌ 失败'}")
        print(f"  DID: {did}")
        print(f"  ROOT_OMEGA: {root_omega}")
        print(f"  node_id: {node_id}")


# ========== 入口 ==========
def main():
    if len(sys.argv) < 2:
        print("""
ZONGYUAN-ROOT 动态IP白名单管理系统 V1.0

用法:
  python3 dynamic_ip_whitelist.py daemon          # 启动守护进程
  python3 dynamic_ip_whitelist.py status          # 查看当前状态
  python3 dynamic_ip_whitelist.py add <ip> <node_id> [node_type]  # 手动添加IP
  python3 dynamic_ip_whitelist.py remove <ip>     # 手动移除IP
  python3 dynamic_ip_whitelist.py audit [limit]   # 查看审计日志
  python3 dynamic_ip_whitelist.py verify <did> <root_omega> [node_id]  # 测试同源验证
  python3 dynamic_ip_whitelist.py cleanup          # 立即清理过期IP
        """)
        return

    wl = DynamicIPWhitelist()
    cmd = sys.argv[1]

    if cmd == "daemon":
        wl.run_daemon()
    elif cmd == "status":
        wl.cmd_status()
    elif cmd == "add":
        if len(sys.argv) < 4:
            print("用法: add <ip> <node_id> [node_type]")
            return
        ip = sys.argv[2]
        node_id = sys.argv[3]
        node_type = sys.argv[4] if len(sys.argv) > 4 else "manual"
        wl.cmd_add(ip, node_id, node_type)
    elif cmd == "remove":
        if len(sys.argv) < 3:
            print("用法: remove <ip>")
            return
        wl.cmd_remove(sys.argv[2])
    elif cmd == "audit":
        limit = int(sys.argv[2]) if len(sys.argv) > 2 else 50
        wl.cmd_audit(limit)
    elif cmd == "verify":
        if len(sys.argv) < 4:
            print("用法: verify <did> <root_omega> [node_id]")
            return
        did = sys.argv[2]
        root_omega = sys.argv[3]
        node_id = sys.argv[4] if len(sys.argv) > 4 else ""
        wl.cmd_verify(did, root_omega, node_id)
    elif cmd == "cleanup":
        wl.cleanup_expired()
        print("✅ 过期IP清理完成")
    else:
        print(f"未知命令: {cmd}")


if __name__ == "__main__":
    main()
