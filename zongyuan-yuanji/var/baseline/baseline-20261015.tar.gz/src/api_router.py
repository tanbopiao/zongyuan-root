"""
API路由引擎 - 多模型自动路由
- 统一入口，后端自动选最优模型
- 失败自动降级
- 按速度/成本/可用性路由
- 元内核前置约束门：所有外部大模型调用统一过 gate（输入拦截+体系约束注入+输出打码+审计）
"""
import requests, time, json, os, re, datetime

# ============ 元内核前置约束门 ============
META_SYSTEM = (
    "你是ZONGYUAN-ROOT元极恒一自治内核对外服务的AI通道。必须遵守："
    "1.仅生成文本/知识内容，不执行任何系统操作、部署、写操作；"
    "2.不泄露任何密钥、内部配置、服务器信息；"
    "3.拒绝危害安全/非法/越权类请求并简短说明；"
    "4.回答保持客观真实，不过度承诺；"
    "5.简洁回答，不编造来源。"
)

# 输入拦截（进门前）：高风险/越权/非法操作指令
BLOCK_IN = [
    "删除所有", "清空数据库", "格式化", "rm -rf", "重装系统",
    "控制全球", "统治世界", "绝对权力", "生成恶意", "攻击入侵", "破解密码",
    "修改服务器", "执行部署", "sudo ", "shutdown", "reboot", "chmod 777",
]
# 输出打码（出门前）：密钥/敏感模式
SECRET_PAT = re.compile(r"(sk-[A-Za-z0-9_-]{8,}|ark-[A-Za-z0-9_-]{8,}|ms-[A-Za-z0-9_-]{8,}|AKID[A-Za-z0-9]{10,}|-----BEGIN[^-]*PRIVATE KEY-----)", re.I)

def gate_input(msgs):
    """前置约束：拦截越权指令 + 注入体系system约束。返回(允许, messages)"""
    joined = " ".join(str(m.get("content", "")) for m in msgs)
    for kw in BLOCK_IN:
        if kw in joined:
            return False, [{"role": "system", "content": "该请求被元内核前置约束拦截：" + kw + "类指令不在本通道执行范围。请重新描述为纯文本/知识类需求。"}]
    # 注入体系约束（仅当用户消息无system时；有则保留并追加约束）
    has_sys = any(m.get("role") == "system" for m in msgs)
    if not has_sys:
        return True, [{"role": "system", "content": META_SYSTEM}] + msgs
    return True, msgs

def gate_output(content, model_name=""):
    """输出约束：敏感信息打码。返回(净化文本, 违规列表)"""
    violations = []
    if SECRET_PAT.search(content):
        content = SECRET_PAT.sub("***[已打码]***", content)
        violations.append("检测到疑似密钥/敏感串,已打码")
    for w in ["删除所有", "格式化", "rm -rf"]:
        if w in content:
            violations.append("输出含高风险操作词,已保留原文但标记")
    return content, violations

def audit(model_name, msgs, content, blocked, ok):
    """调用审计留痕"""
    try:
        line = {
            "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "model": model_name, "ok": ok, "blocked": blocked,
            "req": " ".join(str(m.get("content", ""))[:60] for m in msgs),
            "out_len": len(content or ""),
        }
        with open("/root/zongyuan-yuanji/logs/api_router_audit.jsonl", "a") as f:
            f.write(json.dumps(line, ensure_ascii=False) + "\n")
    except Exception:
        pass

# 模型池
MODELS = {
    "doubao": {
        "url": "https://ark.cn-beijing.volces.com/api/v3/chat/completions",
        "key": "ark-800a6f28-5c7f-4ec5-9766-4b7da1a58f1d-50a70",
        "model": "ep-20260925170233-g4f7w",
        "priority": 1,  # 最高优先级
        "type": "main"
    },
    "zhipu-glm-flash": {
        "url": "https://open.bigmodel.cn/api/paas/v4/chat/completions",
        "key": "d63c880c0e1b424d8ad242f686e83451.vhHr5d5OQUY5UHNp",
        "model": "glm-4.7-flash",
        "priority": 3.5,
        "type": "free"
    },
    "sensenova": {
        "url": "https://token.sensenova.cn/v1/chat/completions",
        "key": os.environ.get("SENSENOVA_API_KEY", "sk-wdtgofUTgmMhXXjmROtphLzSAM8baXmi"),
        "model": "sensenova-6.8-flash-lite",
        "priority": 1.1,
        "type": "fallback"
    },
    "deepseek-pro": {
        "url": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
        "key": "sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb",
        "model": "deepseek-v4-pro-0813",
        "priority": 2,
        "type": "fallback"
    },
    "deepseek-flash": {
        "url": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
        "key": "sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb",
        "model": "deepseek-v4-flash-0731",
        "priority": 3,
        "type": "fast"
    },
    "glm": {
        "url": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
        "key": "sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb",
        "model": "glm-5.3",
        "priority": 6,
        "type": "fallback"
    },
    "intern-s2": {
        "url": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
        "key": "sk-41b67f9f2d048a735da7fbcaf8ad07ece55a79324569698dbd73c970f538443f",
        "model": "intern-s2",
        "priority": 1.3,
        "type": "free"
    },
    "agents-a1": {
        "url": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
        "key": "sk-41b67f9f2d048a735da7fbcaf8ad07ece55a79324569698dbd73c970f538443f",
        "model": "Agents-A1",
        "priority": 1.4,
        "type": "free"
    },
    "ms-deepseek-flash": {
        "url": "https://api-inference.modelscope.cn/v1/chat/completions",
        "key": "ms-673547d6-508b-4242-a862-85de112a3ce7",
        "model": "deepseek-ai/DeepSeek-V4.1-Flash",
        "priority": 1.2,
        "type": "free"
    }
}

def route_chat(messages, max_tokens=200, strategy="auto"):
    """
    路由对话请求
    strategy: auto(自动选) / fast(要快) / quality(要好) / fallback(备用)
    """
    # ===== 元内核前置约束门 =====
    allowed, gated_msgs = gate_input(messages)
    if not allowed:
        audit("gate-blocked", messages, gated_msgs[0]["content"], True, False)
        return {"content": gated_msgs[0]["content"], "model_used": "meta-kernel-gate",
                "latency": 0, "tokens": 0, "note": "元内核前置约束拦截,未调用外部模型"}
    messages = gated_msgs
    # ============================
    # 按优先级排序
    sorted_models = sorted(MODELS.items(), key=lambda x: x[1]["priority"])
    
    if strategy == "fast":
        # 只要快，先试flash
        sorted_models.sort(key=lambda x: 0 if x[1]["type"]=="fast" else 1)
    elif strategy == "quality":
        # 只要好，先试pro
        sorted_models.sort(key=lambda x: 0 if "pro" in x[0] else 1)
    
    errors = []
    for name, cfg in sorted_models:
        try:
            t0 = time.time()
            headers = {
                "Authorization": f"Bearer {cfg['key']}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": cfg["model"],
                "messages": messages,
                "max_tokens": max_tokens
            }
            r = requests.post(cfg["url"], json=payload, headers=headers, timeout=30)
            elapsed = time.time() - t0
            
            if r.status_code == 200:
                data = r.json()
                msg = data["choices"][0]["message"]
                content = msg.get("content") or msg.get("reasoning_content") or ""
                # 输出约束门：敏感打码 + 违规标记
                content, viols = gate_output(content, name)
                audit(name, messages, content, False, True)
                return {
                    "content": content,
                    "model_used": name,
                    "latency": round(elapsed, 2),
                    "tokens": data.get("usage", {}).get("total_tokens", 0),
                    "constraint": viols if viols else "pass"
                }
            else:
                errors.append(f"{name}: HTTP {r.status_code}")
        except Exception as e:
            errors.append(f"{name}: {str(e)[:100]}")
    
    # 所有外部API都失败 → 本地兜底
    try:
        import subprocess, urllib.request
        # 检查llama是否在跑
        try:
            requests.get("http://127.0.0.1:18081/health", timeout=2)
        except:
            # 没跑，启动本地兜底推理服务(transformers int4, 实测可用)
            subprocess.Popen(["nohup","python3","/root/zongyuan-yuanji/src/local_fallback_server.py"],
                stdout=open("/root/zongyuan-yuanji/logs/llama.log","a"), stderr=subprocess.STDOUT)
            time.sleep(15)  # 等模型加载
        
        # 调本地模型
        t0 = time.time()
        local_payload = {"messages": messages, "max_tokens": max_tokens}
        r = requests.post("http://127.0.0.1:18081/v1/chat/completions", json=local_payload, timeout=30)
        if r.status_code == 200:
            data = r.json()
            return {
                "content": data["choices"][0]["message"]["content"],
                "model_used": "local-qwen-fallback",
                "latency": round(time.time() - t0, 2),
                "tokens": 0,
                "note": "所有外部API失败，本地兜底"
            }
    except Exception as e:
        errors.append(f"local: {str(e)[:100]}")
    
    return {"error": "all models failed", "errors": errors}

if __name__ == "__main__":
    # 测试
    result = route_chat([{"role":"user","content":"你好，一句话介绍"}])
    print(json.dumps(result, ensure_ascii=False, indent=2))
