"""
ZONGYUAN-ROOT 轻量监控面板
端口: 8004
功能: CPU/内存/磁盘/网络实时监控 + 服务状态 + 告警
"""
import os, time, json, subprocess
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse

app = FastAPI(title="ZONGYUAN Monitor", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

SERVICES = [
    {"name": "Nginx", "port": 80, "url": "http://127.0.0.1/"},
    {"name": "Nginx-SSL", "port": 443, "url": "https://huodouai.com/"},
    {"name": "Omega-Brain", "port": 8000, "url": "http://127.0.0.1:8000/health"},
    {"name": "LOIP-API", "port": 8001, "url": "http://127.0.0.1:8001/api/v1/status"},
    {"name": "ANCE-API", "port": 8002, "url": "http://127.0.0.1:8002/health"},
    {"name": "Vector-DB", "port": 8003, "url": "http://127.0.0.1:8003/health"},
    {"name": "Redis", "port": 6379, "cmd": "redis-cli ping"},
]

def get_cpu_usage():
    try:
        result = subprocess.run(["top", "-bn1"], capture_output=True, text=True, timeout=5)
        for line in result.stdout.split("\n"):
            if "Cpu(s)" in line or "%Cpu" in line:
                parts = line.split(",")
                for p in parts:
                    if "id" in p:
                        idle = float(p.strip().split()[0])
                        return round(100 - idle, 1)
    except:
        pass
    return 0.0

def get_memory():
    try:
        result = subprocess.run(["free", "-m"], capture_output=True, text=True, timeout=5)
        lines = result.stdout.strip().split("\n")
        for line in lines:
            if line.startswith("Mem:"):
                parts = line.split()
                total = int(parts[1])
                used = int(parts[2])
                avail = int(parts[6]) if len(parts) > 6 else int(parts[3])
                return {"total_mb": total, "used_mb": used, "available_mb": avail, "usage_pct": round(used/total*100, 1)}
    except:
        pass
    return {"total_mb": 0, "used_mb": 0, "available_mb": 0, "usage_pct": 0}

def get_disk():
    try:
        result = subprocess.run(["df", "-h", "/"], capture_output=True, text=True, timeout=5)
        lines = result.stdout.strip().split("\n")
        if len(lines) > 1:
            parts = lines[1].split()
            return {"total": parts[1], "used": parts[2], "available": parts[3], "usage_pct": parts[4]}
    except:
        pass
    return {"total": "0", "used": "0", "available": "0", "usage_pct": "0%"}

def check_services():
    results = []
    for svc in SERVICES:
        status = "unknown"
        latency = 0
        try:
            if "cmd" in svc:
                r = subprocess.run(svc["cmd"].split(), capture_output=True, text=True, timeout=3)
                status = "running" if r.returncode == 0 else "stopped"
            else:
                t0 = time.time()
                r = subprocess.run(["curl", "-sf", "--max-time", "3", svc["url"]], capture_output=True, timeout=5)
                latency = int((time.time() - t0) * 1000)
                status = "running" if r.returncode == 0 else "stopped"
        except:
            status = "error"
        results.append({"name": svc["name"], "port": svc["port"], "status": status, "latency_ms": latency})
    return results

@app.get("/health")
def health():
    return {"status": "ok", "service": "monitor", "timestamp": int(time.time())}

@app.get("/api/v1/system")
def system_stats():
    return {
        "cpu_usage_pct": get_cpu_usage(),
        "memory": get_memory(),
        "disk": get_disk(),
        "uptime": subprocess.run(["uptime", "-p"], capture_output=True, text=True).stdout.strip(),
        "load_avg": subprocess.run(["cat", "/proc/loadavg"], capture_output=True, text=True).stdout.strip().split()[:3],
        "timestamp": int(time.time())
    }

@app.get("/api/v1/services")
def services_status():
    return {"services": check_services(), "timestamp": int(time.time())}

@app.get("/api/v1/alerts")
def alerts():
    alerts_list = []
    mem = get_memory()
    disk = get_disk()
    cpu = get_cpu_usage()
    
    if mem["usage_pct"] > 85:
        alerts_list.append({"level": "P1", "type": "memory", "message": f"内存使用率{mem['usage_pct']}%超过85%"})
    if int(disk["usage_pct"].replace("%","")) > 85:
        alerts_list.append({"level": "P1", "type": "disk", "message": f"磁盘使用率{disk['usage_pct']}超过85%"})
    if cpu > 90:
        alerts_list.append({"level": "P0", "type": "cpu", "message": f"CPU使用率{cpu}%超过90%"})
    
    svcs = check_services()
    for s in svcs:
        if s["status"] != "running":
            alerts_list.append({"level": "P0", "type": "service", "message": f"服务{s['name']}未运行"})
    
    return {"alerts": alerts_list, "count": len(alerts_list), "timestamp": int(time.time())}

@app.get("/", response_class=HTMLResponse)
def dashboard():
    return """<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ZONGYUAN-ROOT 监控面板</title>
<style>
body{font-family:-apple-system,sans-serif;background:#0a0e1a;color:#e0e0e0;margin:0;padding:20px}
h1{color:#64ffda;font-size:20px;margin-bottom:20px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:15px;margin-bottom:20px}
.card{background:#111827;border:1px solid #1f2937;border-radius:10px;padding:15px}
.card .label{font-size:12px;color:#6b7280;margin-bottom:5px}
.card .value{font-size:24px;font-weight:600;color:#fff}
.card .sub{font-size:11px;color:#6b7280;margin-top:3px}
.ok{color:#52c41a}.warn{color:#faad14}.err{color:#ea6668}
table{width:100%;border-collapse:collapse;font-size:13px}
th,td{padding:8px 12px;text-align:left;border-bottom:1px solid #1f2937}
th{color:#6b7280;font-weight:500}
.status-dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px}
.dot-ok{background:#52c41a}.dot-err{background:#ea6668}
</style></head><body>
<h1>Ω ZONGYUAN-ROOT 监控面板</h1>
<div class="grid" id="metrics"></div>
<div class="card"><div class="label" style="margin-bottom:10px">服务状态</div><table id="svc-table"><thead><tr><th>服务</th><th>端口</th><th>状态</th><th>延迟</th></tr></thead><tbody></tbody></table></div>
<script>
function fmt(v){return v}
async function load(){
  try{
    const sys=await fetch('api/v1/system').then(r=>r.json());
    const svc=await fetch('api/v1/services').then(r=>r.json());
    document.getElementById('metrics').innerHTML=`
      <div class="card"><div class="label">CPU使用率</div><div class="value ${sys.cpu_usage_pct>80?'err':sys.cpu_usage_pct>60?'warn':'ok'}">${sys.cpu_usage_pct}%</div></div>
      <div class="card"><div class="label">内存</div><div class="value ${sys.memory.usage_pct>80?'err':'ok'}">${sys.memory.usage_pct}%</div><div class="sub">${sys.memory.used_mb}/${sys.memory.total_mb}MB</div></div>
      <div class="card"><div class="label">磁盘</div><div class="value ${parseInt(sys.disk.usage_pct)>80?'err':'ok'}">${sys.disk.usage_pct}</div><div class="sub">${sys.disk.used}/${sys.disk.total}</div></div>
      <div class="card"><div class="label">运行时间</div><div class="value" style="font-size:16px">${sys.uptime.replace('up ','')}</div><div class="sub">负载: ${sys.load_avg.join(' ')}</div></div>`;
    const tb=document.querySelector('#svc-table tbody');
    tb.innerHTML=svc.services.map(s=>`<tr><td>${s.name}</td><td>${s.port}</td><td><span class="status-dot ${s.status==='running'?'dot-ok':'dot-err'}"></span>${s.status==='running'?'运行中':'未运行'}</td><td>${s.latency_ms}ms</td></tr>`).join('');
  }catch(e){console.error(e)}
}
load();setInterval(load,5000);
</script></body></html>"""

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8004, workers=1)
