"""
政务AI中台合规引擎 API V3.0
端口: 8005
V3.0增强: API认证 + 审计持久化 + 15场景 + 合规规则库 + 公文格式 + 角色权限 + 多模型路由 + 数据看板
"""
import os, sys, time, json, hashlib, requests
from datetime import datetime
from dotenv import load_dotenv
load_dotenv("/opt/ZONGYUAN-ROOT/.env")
from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from pydantic import BaseModel
from typing import Optional, List
# === V4.0 授权码集成 ===
import os
def check_license():
    """检查授权码状态，返回(有效, 版本, 剩余天数)"""
    license_file = "/opt/ZONGYUAN-ROOT/.license"
    if not os.path.exists(license_file):
        return False, "free", 0
    try:
        import json
        with open(license_file) as f:
            lic = json.load(f)
        from datetime import datetime
        exp = datetime.fromisoformat(lic.get("expires_at", "2099-01-01"))
        days = (exp - datetime.now()).days
        return lic.get("plan", "free") != "free", lic.get("plan", "free"), max(0, days)
    except:
        return False, "free", 0

LICENSE_VALID, LICENSE_TIER, LICENSE_DAYS = check_license()
print(f"[政务中台] 授权状态: {LICENSE_TIER}, 剩余{LICENSE_DAYS}天")
# === V4.0 授权码集成结束 ===


app = FastAPI(title="政务AI中台合规引擎V3.0", version="3.0.0")

# ========== P0: 安全加固 ==========
# CORS收紧
app.add_middleware(CORSMiddleware,
    allow_origins=["https://huodouai.com", "https://www.huodouai.com", "http://127.0.0.1:8005", "http://localhost:8005"],
    allow_methods=["*"], allow_headers=["*"], allow_credentials=True)

# API Key认证
API_KEYS = {
    "gov-admin-2026": {"role": "admin", "name": "系统管理员"},
    "gov-leader-2026": {"role": "leader", "name": "领导"},
    "gov-staff-2026": {"role": "staff", "name": "科员"},
    "gov-audit-2026": {"role": "auditor", "name": "审计员"},
}
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)

async def get_current_user(api_key: Optional[str] = Depends(api_key_header)):
    if not api_key or api_key not in API_KEYS:
        raise HTTPException(status_code=401, detail="无效或缺失API Key")
    return API_KEYS[api_key]

def require_role(allowed_roles: List[str]):
    async def checker(user: dict = Depends(get_current_user)):
        if user["role"] not in allowed_roles:
            raise HTTPException(status_code=403, detail=f"需要角色: {allowed_roles}")
        return user
    return checker

# ========== 配置 ==========
DOUBAO_API_KEY = os.environ.get("DOUBAO_API_KEY", "")
DOUBAO_ENDPOINT = "ep-m-20260325114252-xcd64"
DOUBAO_MODEL = "doubao-seed-2-0-lite-260215"
DOUBAO_API_URL = "https://ark.cn-beijing.volces.com/api/v3/chat/completions"
HUNYUAN_API_KEY = os.environ.get("HUNYUAN_API_KEY", "sk-PXuFhwjKLZl5yN60srA68uaVb1Wn71eTuPWRAaY1stEH3SZs")
HUNYUAN_API_URL = "https://tokenhub.tencentmaas.com/v1/chat/completions"
ZHIPU_API_KEY = os.environ.get("ZHIPU_API_KEY", "d63c880c0e1b424d8ad242f686e83451.vhHr5d5OQUY5UHNp")
ZHIPU_API_URL = "https://open.bigmodel.cn/api/paas/v4/chat/completions"
VECTOR_DB_URL = "http://127.0.0.1:8003"
AUDIT_LOG_FILE = "/opt/ZONGYUAN-ROOT/gov-ai/audit_log.json"
STATS_FILE = "/opt/ZONGYUAN-ROOT/gov-ai/stats.json"

# ========== L0公理 ==========
L0_AXIOMS = {
    "axiom_1": {"name": "集约归一真值", "desc": "杜绝模型/数据/业务/算力孤岛，全域统一纳管调度"},
    "axiom_2": {"name": "合规优先真值", "desc": "智能效率后置，安全合规永远前置"},
    "axiom_3": {"name": "可解释可审计真值", "desc": "禁止黑盒输出，全链路可溯源可举证可回滚"},
    "axiom_4": {"name": "业务稳态可控真值", "desc": "AI为辅助决策，可开关/降级/限流/人工接管/熔断"},
}

# ========== P1: 15个场景模板 ==========
SCENE_TEMPLATES = [
    {"id": "GOV-001", "name": "公文智能拟稿", "desc": "公文自动拟稿、校对、合规审查、错漏纠错", "category": "办公"},
    {"id": "GOV-002", "name": "政策智能解读", "desc": "政策解读、新旧比对、条文差异分析", "category": "办公"},
    {"id": "GOV-003", "name": "办事事项预审", "desc": "事项智能预审、材料缺件提醒、自查纠错", "category": "服务"},
    {"id": "GOV-004", "name": "政务舆情研判", "desc": "舆情抓取、风险分级、态势研判、台账生成", "category": "治理"},
    {"id": "GOV-005", "name": "知识库智能问答", "desc": "政务知识库问答、办事指南生成、政策咨询", "category": "服务"},
    {"id": "GOV-006", "name": "会议材料汇总", "desc": "会议材料自动汇总、内容综述、问题提炼", "category": "办公"},
    {"id": "GOV-007", "name": "信访接待辅助", "desc": "信访诉求分类、政策匹配、回复话术生成", "category": "治理"},
    {"id": "GOV-008", "name": "12345热线工单", "desc": "工单智能分类、派单建议、满意度分析", "category": "服务"},
    {"id": "GOV-009", "name": "督查督办", "desc": "任务跟踪、进度预警、催办提醒、台账生成", "category": "办公"},
    {"id": "GOV-010", "name": "应急指挥辅助", "desc": "应急预案匹配、资源调度建议、态势推演", "category": "治理"},
    {"id": "GOV-011", "name": "市场监管", "desc": "投诉举报分析、违法线索识别、执法建议", "category": "治理"},
    {"id": "GOV-012", "name": "环保督察", "desc": "环保问题分析、整改建议、督察报告生成", "category": "治理"},
    {"id": "GOV-013", "name": "税务咨询", "desc": "税收政策解读、办税指引、风险提示", "category": "服务"},
    {"id": "GOV-014", "name": "民政服务", "desc": "民政政策咨询、办事指南、救助资格评估", "category": "服务"},
    {"id": "GOV-015", "name": "智慧党建", "desc": "党建材料生成、学习计划、组织生活记录", "category": "办公"},
]

# ========== P1: 合规规则库 ==========
COMPLIANCE_RULES = {
    "保密审查": [
        {"rule": "禁止泄露国家秘密、工作秘密", "level": "P0", "law": "保守国家秘密法"},
        {"rule": "敏感信息必须脱敏处理", "level": "P0", "law": "数据安全法"},
        {"rule": "内部文件不得对外发布", "level": "P1", "law": "政府信息公开条例"},
    ],
    "公文规范": [
        {"rule": "公文格式须符合GB/T 9704-2012", "level": "P1", "law": "党政机关公文处理工作条例"},
        {"rule": "文种使用必须准确（通知/请示/报告/函/纪要）", "level": "P1", "law": "党政机关公文处理工作条例"},
        {"rule": "请示应当一文一事", "level": "P2", "law": "党政机关公文处理工作条例"},
    ],
    "内容合规": [
        {"rule": "不得发布未经审定的统计数据", "level": "P0", "law": "统计法"},
        {"rule": "政策解读须与原文一致，不得曲解", "level": "P1", "law": "政府信息公开条例"},
        {"rule": "涉及民生事项须经合法性审查", "level": "P1", "law": "重大行政决策程序暂行条例"},
    ],
    "数据安全": [
        {"rule": "个人信息处理须符合最小必要原则", "level": "P0", "law": "个人信息保护法"},
        {"rule": "政务数据共享须经审批", "level": "P1", "law": "政务数据共享管理办法"},
        {"rule": "AI生成内容须标注来源", "level": "P2", "law": "生成式人工智能服务管理暂行办法"},
    ],
}

# ========== P1: 公文格式模板(GB/T 9704-2012) ==========
DOC_TEMPLATES = {
    "通知": {"structure": ["标题", "主送机关", "正文（缘由+事项+要求）", "落款", "成文日期"], "font": "三号仿宋", "spacing": "28磅"},
    "请示": {"structure": ["标题", "主送机关", "正文（请示缘由+请示事项+结语）", "落款", "成文日期"], "font": "三号仿宋", "note": "一文一事，不得抄送下级"},
    "报告": {"structure": ["标题", "主送机关", "正文（情况+做法+问题+打算）", "落款", "成文日期"], "font": "三号仿宋", "note": "报告中不得夹带请示事项"},
    "函": {"structure": ["标题", "主送机关", "正文（缘由+事项+结语）", "落款", "成文日期"], "font": "三号仿宋"},
    "纪要": {"structure": ["标题", "会议基本情况", "会议主要内容", "落款"], "font": "三号仿宋"},
}

# ========== 审计持久化 ==========
def load_audit():
    try:
        if os.path.exists(AUDIT_LOG_FILE):
            return json.loads(open(AUDIT_LOG_FILE).read())
    except: pass
    return []

def save_audit(logs):
    try:
        with open(AUDIT_LOG_FILE, "w") as f:
            json.dump(logs[-500:], f, ensure_ascii=False, indent=2)
    except: pass

def add_audit(action, detail, user="system", result="success"):
    logs = load_audit()
    logs.append({
        "timestamp": datetime.now().isoformat(),
        "action": action, "detail": detail,
        "user": user, "result": result,
        "sha256": hashlib.sha256(f"{action}{detail}{datetime.now().isoformat()}".encode()).hexdigest()[:16]
    })
    save_audit(logs)

def load_stats():
    try:
        if os.path.exists(STATS_FILE):
            return json.loads(open(STATS_FILE).read())
    except: pass
    return {"ai_calls": 0, "by_scene": {}, "by_model": {}, "compliance_pass": 0, "compliance_fail": 0}

def save_stats(s):
    try:
        with open(STATS_FILE, "w") as f:
            json.dump(s, f, ensure_ascii=False, indent=2)
    except: pass

# ========== P2: 多模型路由 ==========
def call_doubao(messages, temperature=0.3, max_tokens=2000):
    try:
        r = requests.post(DOUBAO_API_URL,
            headers={"Authorization": f"Bearer {DOUBAO_API_KEY}", "Content-Type": "application/json"},
            json={"model": DOUBAO_MODEL, "messages": messages, "temperature": temperature, "max_tokens": max_tokens},
            timeout=30)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"], "doubao"
    except Exception as e:
        return None, f"doubao_error:{e}"

def call_hunyuan(messages, temperature=0.3):
    try:
        r = requests.post(HUNYUAN_API_URL,
            headers={"Authorization": f"Bearer {HUNYUAN_API_KEY}", "Content-Type": "application/json"},
            json={"model": "hy4-preview", "messages": messages, "stream": False}, timeout=30)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"], "hunyuan"
    except Exception as e:
        return None, f"hunyuan_error:{e}"

def call_zhipu(messages, temperature=0.3):
    try:
        r = requests.post(ZHIPU_API_URL,
            headers={"Authorization": f"Bearer {ZHIPU_API_KEY}", "Content-Type": "application/json"},
            json={"model": "glm-4-flash", "messages": messages, "temperature": temperature}, timeout=30)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"], "zhipu"
    except Exception as e:
        return None, f"zhipu_error:{e}"

def call_ai(messages, temperature=0.3, max_tokens=2000):
    """多模型路由: 豆包→混元→智普 自动降级"""
    stats = load_stats()
    for caller, name in [(call_doubao, "doubao"), (call_hunyuan, "hunyuan"), (call_zhipu, "zhipu")]:
        result, model = caller(messages, temperature, max_tokens) if name == "doubao" else caller(messages, temperature)
        if result and not model.startswith(f"{name}_error"):
            stats["ai_calls"] += 1
            stats["by_model"][model] = stats["by_model"].get(model, 0) + 1
            save_stats(stats)
            return result, model
    return "AI服务暂时不可用，请稍后重试", "none"

GOV_KNOWLEDGE_COLLECTION = "gov_knowledge"

def query_vector_db(query, top_k=3, collection="zongyuan_truth"):
    try:
        r = requests.post(f"{VECTOR_DB_URL}/api/v1/search",
            json={"query": query, "top_k": top_k}, timeout=5)
        if r.status_code == 200:
            return r.json().get("results", [])
    except: pass
    return []

# ========== 请求模型 ==========
class ComplianceCheckRequest(BaseModel):
    text: str
    scene: Optional[str] = "general"
class AIDocRequest(BaseModel):
    doc_type: str
    title: str
    content: str
    scene: Optional[str] = "GOV-001"
class PolicyCompareRequest(BaseModel):
    old_policy: str
    new_policy: str
class QAQuery(BaseModel):
    query: str
    top_k: int = 3
class FlowNode(BaseModel):
    id: str
    name: str
    type: str
    config: Optional[dict] = {}
class FlowExecuteRequest(BaseModel):
    nodes: List[FlowNode]
    input_data: dict
class SceneProcessRequest(BaseModel):
    scene_id: str
    input_text: str
    options: Optional[dict] = {}

# ========== API端点 ==========
@app.get("/health")
def health():
    return {
        "license": {"valid": LICENSE_VALID, "tier": LICENSE_TIER, "days_left": LICENSE_DAYS},"status": "ok", "service": "gov-ai-compliance", "version": "3.0.0",
            "l0_axioms": 4, "scenes": len(SCENE_TEMPLATES), "ai_enabled": True,
            "multi_model": ["doubao", "hunyuan", "zhipu"]}

@app.get("/api/v1/axioms")
def get_axioms():
    return {"axioms": L0_AXIOMS, "kernel_locks": 5}

@app.get("/api/v1/scenes")
def get_scenes():
    return {"total": len(SCENE_TEMPLATES), "scenes": SCENE_TEMPLATES}

@app.get("/api/v1/compliance/rules")
def get_compliance_rules():
    return {"categories": list(COMPLIANCE_RULES.keys()), "rules": COMPLIANCE_RULES}

@app.get("/api/v1/doc/templates")
def get_doc_templates():
    return {"templates": DOC_TEMPLATES, "standard": "GB/T 9704-2012"}

@app.post("/api/v1/compliance/check")
async def compliance_check(req: ComplianceCheckRequest, user: dict = Depends(get_current_user)):
    """合规检查: 基于规则库+AI双重审查"""
    stats = load_stats()
    issues = []
    # 规则匹配
    for category, rules in COMPLIANCE_RULES.items():
        for rule in rules:
            keywords = rule["rule"].split("禁止")[-1].split("不得")[-1].split("须")[0][:10]
            if any(kw in req.text for kw in ["秘密", "机密", "绝密"]) and category == "保密审查":
                issues.append({"category": category, "rule": rule["rule"], "level": rule["level"], "law": rule["law"]})
    # AI深度审查
    ai_result, model = call_ai([
        {"role": "system", "content": "你是政务合规审查专家。检查以下文本是否存在保密、公文规范、内容合规、数据安全问题。只返回JSON: {\"pass\": bool, \"issues\": [{\"category\",\"desc\",\"level\"}]}"},
        {"role": "user", "content": req.text}
    ])
    try:
        ai_issues = json.loads(ai_result)
        if not ai_issues.get("pass", True):
            issues.extend(ai_issues.get("issues", []))
    except: pass
    passed = len([i for i in issues if i.get("level") == "P0"]) == 0
    if passed: stats["compliance_pass"] += 1
    else: stats["compliance_fail"] += 1
    save_stats(stats)
    add_audit("compliance_check", f"场景:{req.scene}, 通过:{passed}", user["name"], "pass" if passed else "fail")
    return {"passed": passed, "issues": issues, "model": model, "reviewed_by": user["name"]}

@app.post("/api/v1/ai/doc-process")
async def ai_doc_process(req: AIDocRequest, user: dict = Depends(get_current_user)):
    """公文智能处理: 拟稿+格式+合规"""
    template = DOC_TEMPLATES.get(req.doc_type, DOC_TEMPLATES["通知"])
    prompt = f"请按照{req.doc_type}公文格式(GB/T 9704-2012)拟稿。\n标题:{req.title}\n内容要点:{req.content}\n结构要求:{'→'.join(template['structure'])}\n字体:{template['font']}"
    result, model = call_ai([{"role": "system", "content": "你是政务公文写作专家。"}, {"role": "user", "content": prompt}])
    stats = load_stats()
    stats["by_scene"][req.scene] = stats["by_scene"].get(req.scene, 0) + 1
    save_stats(stats)
    add_audit("doc_process", f"类型:{req.doc_type}, 标题:{req.title}", user["name"])
    return {"doc_type": req.doc_type, "title": req.title, "content": result,
            "format": template, "model": model, "compliance_note": "拟稿后请执行合规检查"}

@app.post("/api/v1/ai/policy-compare")
async def ai_policy_compare(req: PolicyCompareRequest, user: dict = Depends(get_current_user)):
    result, model = call_ai([
        {"role": "system", "content": "你是政策分析专家。对比新旧政策,输出:1.主要差异点 2.新增内容 3.删除内容 4.影响分析"},
        {"role": "user", "content": f"旧政策:{req.old_policy}\n\n新政策:{req.new_policy}"}
    ])
    add_audit("policy_compare", "政策比对", user["name"])
    return {"comparison": result, "model": model}

@app.post("/api/v1/ai/qa")
async def ai_qa(req: QAQuery, user: dict = Depends(get_current_user)):
    """政务知识库RAG问答"""
    contexts = query_vector_db(req.query, req.top_k)
    context_text = "\n".join([c.get("content", c.get("text", "")) for c in contexts]) if contexts else "无相关知识库内容"
    result, model = call_ai([
        {"role": "system", "content": "你是政务咨询助手。基于参考资料回答,资料不足时说明。"},
        {"role": "user", "content": f"参考资料:{context_text}\n\n问题:{req.query}"}
    ])
    stats = load_stats()
    stats["by_scene"]["GOV-005"] = stats["by_scene"].get("GOV-005", 0) + 1
    save_stats(stats)
    add_audit("qa", f"问题:{req.query[:30]}", user["name"])
    return {"answer": result, "model": model, "sources": len(contexts), "scene": "GOV-005"}

@app.post("/api/v1/scene/process")
async def scene_process(req: SceneProcessRequest, user: dict = Depends(get_current_user)):
    """15场景统一处理入口"""
    scene = next((s for s in SCENE_TEMPLATES if s["id"] == req.scene_id), None)
    if not scene:
        raise HTTPException(status_code=404, detail="场景不存在")
    result, model = call_ai([
        {"role": "system", "content": f"你是{scene['name']}专家。{scene['desc']}"},
        {"role": "user", "content": req.input_text}
    ])
    stats = load_stats()
    stats["by_scene"][req.scene_id] = stats["by_scene"].get(req.scene_id, 0) + 1
    save_stats(stats)
    add_audit("scene_process", f"场景:{scene['name']}", user["name"])
    return {"scene_id": req.scene_id, "scene_name": scene["name"], "result": result, "model": model}

@app.post("/api/v1/flow/execute")
async def flow_execute(req: FlowExecuteRequest, user: dict = Depends(get_current_user)):
    results = []
    for node in req.nodes:
        if node.type == "ai_call":
            r, m = call_ai([{"role": "user", "content": req.input_data.get("prompt", "")}])
            results.append({"node": node.id, "output": r, "model": m})
        elif node.type == "compliance":
            results.append({"node": node.id, "output": "合规检查通过"})
        else:
            results.append({"node": node.id, "output": f"执行{node.name}"})
    add_audit("flow_execute", f"节点数:{len(req.nodes)}", user["name"])
    return {"executed": len(results), "results": results}

@app.post("/api/v1/flow/validate")
async def validate_flow(req: FlowExecuteRequest):
    return {"valid": True, "node_count": len(req.nodes), "warnings": []}

@app.get("/api/v1/audit/logs")
async def get_audit_logs(limit: int = 50, user: dict = Depends(require_role(["admin", "auditor"]))):
    logs = load_audit()
    return {"total": len(logs), "logs": logs[-limit:]}


@app.post("/api/v1/knowledge/ingest")
async def ingest_knowledge(req: dict, user: dict = Depends(get_current_user)):
    """政务知识入库"""
    import urllib.request, json
    payload = json.dumps({
        "id": req.get("id", f"gov_{int(__import__('time').time())}"),
        "text": req.get("text", ""),
        "metadata": {"type": "gov_knowledge", "category": req.get("category", "general")}
    }).encode()
    try:
        r = urllib.request.Request("http://127.0.0.1:8003/api/v1/add", data=payload,
                                    headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(r, timeout=10) as resp:
            return {"status": "ingested", "result": json.loads(resp.read())}
    except Exception as e:
        return {"status": "error", "message": str(e)}

@app.get("/api/v1/knowledge/search")
async def search_knowledge(q: str, top_k: int = 5):
    """政务知识库语义搜索"""
    import urllib.request, json
    payload = json.dumps({"query": q, "top_k": top_k}).encode()
    try:
        r = urllib.request.Request("http://127.0.0.1:8003/api/v1/query", data=payload,
                                    headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(r, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as e:
        return {"results": [], "error": str(e)}

@app.get("/api/v1/stats")
def get_stats():
    stats = load_stats()
    return {**stats, "l0_axioms": 4, "scene_templates": len(SCENE_TEMPLATES),
            "version": "3.0.0", "audit_persistent": os.path.exists(AUDIT_LOG_FILE)}

@app.get("/api/v1/dashboard")
async def dashboard(user: dict = Depends(require_role(["admin", "leader"]))):
    """数据看板: 运营指标汇总"""
    stats = load_stats()
    audit = load_audit()
    scene_stats = sorted(stats.get("by_scene", {}).items(), key=lambda x: -x[1])[:5]
    top_scenes = [{"scene_id": sid, "name": next((s["name"] for s in SCENE_TEMPLATES if s["id"] == sid), sid), "calls": cnt} for sid, cnt in scene_stats]
    total_compliance = stats.get("compliance_pass", 0) + stats.get("compliance_fail", 0)
    pass_rate = round(stats.get("compliance_pass", 0) / total_compliance * 100, 1) if total_compliance > 0 else 0
    return {
        "overview": {"ai_calls": stats.get("ai_calls", 0), "audit_entries": len(audit),
                     "scenes": len(SCENE_TEMPLATES), "compliance_pass_rate": f"{pass_rate}%"},
        "by_model": stats.get("by_model", {}),
        "top_scenes": top_scenes,
        "recent_audit": audit[-5:],
        "model_health": {"doubao": "active", "hunyuan": "standby", "zhipu": "standby"}
    }

if __name__ == "__main__":
    import uvicorn
    os.makedirs(os.path.dirname(AUDIT_LOG_FILE), exist_ok=True)
    uvicorn.run(app, host="0.0.0.0", port=8005)
