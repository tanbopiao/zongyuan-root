#!/bin/bash
# ZONGYUAN-ROOT 全域同步脚本 V1.0
# 从内核 → 主内核 增量同步
# 用法: bash sync.sh [--master URL] [--dir 本地目录] [--dry-run]

set -e

MASTER_URL="${MASTER_URL:-https://huodouai.com/anchor}"
LOCAL_DIR="${LOCAL_DIR:-/opt/ZONGYUAN-ROOT}"
DRY_RUN=false

# 解析参数
while [[ $# -gt 0 ]]; do
    case $1 in
        --master) MASTER_URL="$2"; shift 2 ;;
        --dir) LOCAL_DIR="$2"; shift 2 ;;
        --dry-run) DRY_RUN=true; shift ;;
        *) echo "未知参数: $1"; exit 1 ;;
    esac
done

echo "============================================"
echo "  ZONGYUAN-ROOT 全域同步 V1.0"
echo "============================================"
echo "  主内核: $MASTER_URL"
echo "  本地目录: $LOCAL_DIR"
echo "  模式: $([ "$DRY_RUN" = true ] && echo "预览（不写入）" || echo "执行同步")"
echo ""

# 1. 获取主内核manifest
echo "[1/5] 获取主内核资产清单..."
MANIFEST=$(curl -s --connect-timeout 10 "$MASTER_URL/api/v1/sync/manifest")
if [ -z "$MANIFEST" ] || echo "$MANIFEST" | grep -q "error"; then
    echo "错误：无法连接主内核"
    exit 1
fi

MASTER_PROTOCOL=$(echo "$MANIFEST" | python3 -c "import sys,json;print(json.load(sys.stdin).get('latest_protocol','unknown'))")
MASTER_MERKLE=$(echo "$MANIFEST" | python3 -c "import sys,json;print(json.load(sys.stdin).get('merkle_root','unknown')[:16])")
MASTER_COUNT=$(echo "$MANIFEST" | python3 -c "import sys,json;print(json.load(sys.stdin).get('total_files',0))")
echo "  主内核协议: $MASTER_PROTOCOL"
echo "  主内核资产: $MASTER_COUNT 个文件"
echo "  主内核Merkle: $MASTER_MERKLE..."
echo ""

# 2. 扫描本地文件
echo "[2/5] 扫描本地资产..."
LOCAL_MANIFEST=$(python3 << PYEOF
import os, json, hashlib
local_dir = "$LOCAL_DIR"
sync_dirs = ["autonomous_kernel_protocol", "truth_architecture"]
files = []
for d in sync_dirs:
    dirpath = os.path.join(local_dir, d)
    if os.path.exists(dirpath):
        for fname in sorted(os.listdir(dirpath)):
            fpath = os.path.join(dirpath, fname)
            if os.path.isfile(fpath) and fname.endswith(('.json', '.md')):
                h = hashlib.sha256(open(fpath, 'rb').read()).hexdigest()
                files.append({"path": f"{d}/{fname}", "sha256": h})
print(json.dumps({"files": files}))
PYEOF
)
LOCAL_COUNT=$(echo "$LOCAL_MANIFEST" | python3 -c "import sys,json;print(len(json.load(sys.stdin)['files']))")
echo "  本地资产: $LOCAL_COUNT 个文件"
echo ""

# 3. 对比差异
echo "[3/5] 计算差异..."
DIFF=$(curl -s -X POST "$MASTER_URL/api/v1/sync/verify" \
    -H "Content-Type: application/json" \
    -d "$LOCAL_MANIFEST")

CONSISTENT=$(echo "$DIFF" | python3 -c "import sys,json;print(json.load(sys.stdin).get('consistent',False))")
ADDED=$(echo "$DIFF" | python3 -c "import sys,json;print(len(json.load(sys.stdin).get('diff',{}).get('added',[])))")
MODIFIED=$(echo "$DIFF" | python3 -c "import sys,json;print(len(json.load(sys.stdin).get('diff',{}).get('modified',[])))")
REMOVED=$(echo "$DIFF" | python3 -c "import sys,json;print(len(json.load(sys.stdin).get('diff',{}).get('removed',[])))")

echo "  新增: $ADDED | 修改: $MODIFIED | 本地独有: $REMOVED"

if [ "$CONSISTENT" = "True" ]; then
    echo ""
    echo "============================================"
    echo "  本地与主内核完全一致，无需同步"
    echo "============================================"
    exit 0
fi

# 列出需要同步的文件
NEED_SYNC=$(echo "$DIFF" | python3 -c "
import sys, json
d = json.load(sys.stdin)
files = d.get('diff',{}).get('added',[]) + d.get('diff',{}).get('modified',[])
print(json.dumps(files))
")
SYNC_COUNT=$(echo "$NEED_SYNC" | python3 -c "import sys,json;print(len(json.load(sys.stdin)))")
echo "  需同步: $SYNC_COUNT 个文件"
echo ""

if [ "$DRY_RUN" = true ]; then
    echo "  [预览模式] 将同步以下文件:"
    echo "$NEED_SYNC" | python3 -c "import sys,json;[print(f'    + {f}') for f in json.load(sys.stdin)]"
    echo ""
    echo "  预览完成，未执行写入。去掉 --dry-run 执行同步。"
    exit 0
fi

# 4. 批量拉取差异文件
echo "[4/5] 拉取差异文件..."
PULL_RESULT=$(curl -s -X POST "$MASTER_URL/api/v1/sync/pull" \
    -H "Content-Type: application/json" \
    -d "{\"files\": $NEED_SYNC}")

PULLED=$(echo "$PULL_RESULT" | python3 -c "import sys,json;print(json.load(sys.stdin).get('pulled',0))")
echo "  成功拉取: $PULLED / $SYNC_COUNT 个文件"

# 写入本地（临时文件传递大JSON）
PULL_TMP=$(mktemp /tmp/zongyuan-pull-XXXXXX.json)
echo "$PULL_RESULT" > "$PULL_TMP"
python3 -c '
import os, json, base64, sys
with open(sys.argv[1]) as f:
    data = json.load(f)
local_dir = sys.argv[2]
written = 0
for item in data.get("files", []):
    if "content_b64" in item:
        fpath = os.path.join(local_dir, item["path"])
        os.makedirs(os.path.dirname(fpath), exist_ok=True)
        content = base64.b64decode(item["content_b64"])
        with open(fpath, "wb") as out:
            out.write(content)
        written += 1
        print("    ✓ " + item["path"] + " (" + str(item["size"]) + " bytes)")
print(f"  写入完成: {written} 个文件")
' "$PULL_TMP" "$LOCAL_DIR"
rm -f "$PULL_TMP"
echo ""

# 5. 验证一致性
echo "[5/5] 验证同步结果..."
LOCAL_MANIFEST2=$(python3 << PYEOF
import os, json, hashlib
local_dir = "$LOCAL_DIR"
sync_dirs = ["autonomous_kernel_protocol", "truth_architecture"]
files = []
for d in sync_dirs:
    dirpath = os.path.join(local_dir, d)
    if os.path.exists(dirpath):
        for fname in sorted(os.listdir(dirpath)):
            fpath = os.path.join(dirpath, fname)
            if os.path.isfile(fpath) and fname.endswith(('.json', '.md')):
                h = hashlib.sha256(open(fpath, 'rb').read()).hexdigest()
                files.append({"path": f"{d}/{fname}", "sha256": h})
print(json.dumps({"files": files}))
PYEOF
)

VERIFY=$(curl -s -X POST "$MASTER_URL/api/v1/sync/verify" \
    -H "Content-Type: application/json" \
    -d "$LOCAL_MANIFEST2")
FINAL_CONSISTENT=$(echo "$VERIFY" | python3 -c "import sys,json;print(json.load(sys.stdin).get('consistent',False))")

echo ""
echo "============================================"
if [ "$FINAL_CONSISTENT" = "True" ]; then
    echo "  ✅ 同步完成，本地与主内核完全一致"
else
    echo "  ⚠️ 同步后仍有差异:"
    echo "$VERIFY" | python3 -c "import sys,json;d=json.load(sys.stdin)['diff'];print(f'    新增: {len(d[\"added\"])} 修改: {len(d[\"modified\"])} 本地独有: {len(d[\"removed\"])}')"
fi
echo "============================================"
echo "  主内核协议: $MASTER_PROTOCOL"
echo "  同步文件数: $PULLED"
echo "  Ω₀⊂⊙∞⊂Ω · ZONGYUAN-ROOT"
