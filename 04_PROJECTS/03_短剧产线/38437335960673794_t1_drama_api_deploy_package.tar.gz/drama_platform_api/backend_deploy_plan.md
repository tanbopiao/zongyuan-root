# 短剧平台后端API部署方案
# T1(P0) 短剧平台API对接与真实可用化
# DID-BR-000002 | Ω₀⊂⊙∞⊂Ω

## 部署目标
在云服务器(123.207.202.158)部署短剧平台后端API服务，使drama.huodouai.com的/api/*端点从502变为正常可用。

## 当前状态
- 前端: drama.huodouai.com → HTTP 200 ✅ (昆仑洞天·全域资产可视化)
- 后端API: 所有/api/*端点 → 502 ❌ (后端服务未运行)
- 本地仿真: 已完成(Flask+SQLite端口8199)，功能验证通过

## 部署架构
```
Nginx (443/80)
  ├── / → 前端静态页面 (/var/www/drama)
  └── /api/v1/ → 反向代理 → 127.0.0.1:8199 (Flask后端API)
```

## 部署步骤
1. 将drama_platform_sim.py上传至服务器 /opt/drama-platform/
2. 安装依赖: pip install flask
3. 创建systemd服务: drama-platform.service
4. 配置Nginx反向代理: /api/v1/ → 127.0.0.1:8199
5. 配置SQLite数据库路径: /var/lib/drama-platform/platform.db
6. 启动服务并验证: curl http://127.0.0.1:8199/api/v1/health
7. 验证外网: curl https://drama.huodouai.com/api/v1/health

## API端点清单(12个)
- GET /health - 健康检查
- GET /status - 平台状态
- POST /auth/token - 获取令牌
- GET /drama/list - 短剧列表
- GET /drama/{id} - 短剧详情
- GET /episode/{id} - 单集详情
- POST /drama/create - 创建短剧
- POST /episode/upload - 上传单集
- POST /episode/storyboard - 上传分镜表
- POST /episode/keyframes - 批量上传关键帧
- PUT /drama/{id}/publish - 发布上线
- GET /stats/playback - 播放统计

## 数据迁移
- 本地仿真数据库(~/.zongyuan_root/drama_platform.db)包含EP01+EP02分镜表数据
- 部署后可通过SDK重新上传，或直接迁移db文件

## 验收标准
- /api/v1/health 返回 {"status":"ok"}
- /api/v1/status 返回短剧/分集统计
- /api/v1/drama/list 返回已上传短剧列表
- 前端页面API状态显示"已连接"
- SDK切换base_url后可正常上传分镜表

## 确权
DID-BR-000002 | Ω₀⊂⊙∞⊂Ω | 火斗云智AIOS
