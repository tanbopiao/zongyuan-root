#!/usr/bin/env python3
"""
昆仑洞天本地自治代理 v2.0 启动入口
用法：
  python3 start_agent.py              # 前台运行
  python3 start_agent.py --daemon     # 后台运行
  python3 start_agent.py --stop       # 停止后台代理
  python3 start_agent.py --status     # 查看代理状态
"""
import sys
import os
import time
import signal
import subprocess

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from agent.config import Config
from agent import __version__

PID_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".agent.pid")
LOG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "agent.log")


def is_running():
    if not os.path.exists(PID_FILE):
        return False
    try:
        with open(PID_FILE) as f:
            pid = int(f.read().strip())
        os.kill(pid, 0)
        return pid
    except (ValueError, OSError):
        return False


def start_daemon():
    pid = is_running()
    if pid:
        print(f"[代理] 已在运行中 (PID: {pid})")
        return
    log = open(LOG_FILE, 'a')
    proc = subprocess.Popen(
        [sys.executable, os.path.abspath(__file__), "--foreground"],
        stdout=log, stderr=log,
        start_new_session=True,
        cwd=os.path.dirname(os.path.abspath(__file__))
    )
    time.sleep(2)
    if proc.poll() is None:
        with open(PID_FILE, 'w') as f:
            f.write(str(proc.pid))
        print(f"[代理] 后台启动成功 (PID: {proc.pid})")
        print(f"[代理] 日志: {LOG_FILE}")
        print(f"[代理] WebSocket: ws://127.0.0.1:{Config.WS_PORT}/ws")
        print(f"[代理] 预览服务: http://127.0.0.1:{Config.HTTP_PORT}/preview")
    else:
        print(f"[代理] 启动失败，请查看日志: {LOG_FILE}")


def stop_daemon():
    pid = is_running()
    if not pid:
        print("[代理] 未在运行")
        return
    try:
        os.kill(pid, signal.SIGTERM)
        time.sleep(1)
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
        print(f"[代理] 已停止 (PID: {pid})")
    except OSError as e:
        print(f"[代理] 停止失败: {e}")


def show_status():
    pid = is_running()
    s = Config.summary()
    print("=" * 50)
    print("  昆仑洞天本地自治代理状态")
    print("=" * 50)
    print(f"  运行状态: {'运行中' if pid else '未运行'}")
    if pid:
        print(f"  PID: {pid}")
    print(f"  版本: v{__version__}")
    print(f"  模式: {s['mode']}")
    print(f"  WebSocket: ws://127.0.0.1:{Config.WS_PORT}/ws")
    print(f"  预览服务: http://127.0.0.1:{Config.HTTP_PORT}/preview")
    print(f"  质量门禁: {'启用' if s['quality_gate'] else '禁用'}")
    print(f"  最大重试: {s['max_retries']}次")
    print("=" * 50)


def main():
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == "--daemon":
            start_daemon()
            return
        elif cmd == "--stop":
            stop_daemon()
            return
        elif cmd == "--status":
            show_status()
            return
        elif cmd == "--foreground":
            pass
        else:
            print(f"未知参数: {cmd}")
            print("用法: python3 start_agent.py [--daemon|--stop|--status]")
            return

    # 前台运行
    with open(PID_FILE, 'w') as f:
        f.write(str(os.getpid()))

    try:
        from agent.ws_server import run_server
        run_server()
    except KeyboardInterrupt:
        print("\n[代理] 已停止")
    except OSError as e:
        if "Address already in use" in str(e):
            print(f"[错误] 端口被占用，请检查是否已有代理在运行")
            print(f"  可执行: python3 start_agent.py --status")
        else:
            print(f"[错误] {e}")
    finally:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)


if __name__ == "__main__":
    main()
