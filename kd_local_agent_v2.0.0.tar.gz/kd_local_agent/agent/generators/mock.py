"""FFmpeg模拟生成器 - 用于无API密钥时的本地仿真"""
import asyncio
import subprocess
from pathlib import Path
from .base import BaseGenerator, GeneratorError
from ..logging_setup import get_logger

log = get_logger("generator.mock")

# 昆仑洞天角色配色
CHARACTER_COLORS = {
    "taiyin": "#1a1a3e",      # 太阴月神 - 深蓝
    "jiutian": "#3e1a1a",      # 九天玄女 - 暗红
    "xiwangmu": "#1a3e2a",     # 西王母 - 深绿
    "hongqun": "#3e1a2e",      # 红裙九尾狐 - 紫红
}


class MockGenerator(BaseGenerator):
    """FFmpeg模拟视频生成器"""

    name = "ffmpeg-mock"
    description = "使用ffmpeg生成纯色动态占位视频"

    async def generate(self, task, shot, output_path: Path) -> str:
        duration = shot.get("duration", task.duration)
        char_key = shot.get("character", "taiyin")
        color = CHARACTER_COLORS.get(char_key, "#1a1a2e")

        log.info(f"[Mock] 生成镜头 {shot['shot_id']} ({char_key}) 时长={duration}s 颜色={color}")

        try:
            # 生成带音频的测试视频
            cmd = [
                "ffmpeg", "-y",
                "-f", "lavfi", "-i", f"color=c={color}:s=1080x1920:d={duration}",
                "-f", "lavfi", "-i", f"sine=frequency=440:duration={duration}",
                "-c:v", "libx264", "-preset", "ultrafast", "-pix_fmt", "yuv420p",
                "-c:a", "aac", "-shortest",
                str(output_path)
            ]
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=60)

            if proc.returncode != 0:
                raise GeneratorError(f"ffmpeg返回码 {proc.returncode}: {stderr.decode()[-200:]}")

            if not self.validate_output(output_path):
                raise GeneratorError("输出文件无效")

            log.info(f"[Mock] 镜头 {shot['shot_id']} 生成成功: {output_path.stat().st_size}B")
            return self.name

        except asyncio.TimeoutError:
            raise GeneratorError("ffmpeg执行超时")
        except FileNotFoundError:
            raise GeneratorError("ffmpeg未安装，请安装ffmpeg")

    async def generate_keyframe(self, task, shot, output_path: Path) -> str:
        char_key = shot.get("character", "taiyin")
        color = CHARACTER_COLORS.get(char_key, "#1a1a2e")

        cmd = [
            "ffmpeg", "-y",
            "-f", "lavfi", "-i", f"color=c={color}:s=1080x1920:d=1",
            "-frames:v", "1",
            str(output_path)
        ]
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        await asyncio.wait_for(proc.communicate(), timeout=15)
        return self.name
