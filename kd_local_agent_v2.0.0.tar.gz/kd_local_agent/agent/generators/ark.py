"""火山方舟视频生成器 - 对接Seedance 2.5 API"""
import asyncio
import json
import time
from pathlib import Path
import urllib.request
import urllib.error
from .base import BaseGenerator, GeneratorError
from ..config import Config
from ..logging_setup import get_logger

log = get_logger("generator.ark")


class ArkGenerator(BaseGenerator):
    """火山方舟Seedance视频生成器"""

    name = "seedance-ark"
    description = "火山方舟Seedance 2.5真实AI视频生成"

    def __init__(self, config=None):
        super().__init__(config)
        self.api_key = Config.ARK_API_KEY
        self.api_base = Config.ARK_API_BASE
        self.ep = Config.SEEDANCE_EP
        self.poll_interval = 3  # 轮询间隔秒
        self.max_poll_time = 300  # 最大轮询时间

    async def generate(self, task, shot, output_path: Path) -> str:
        if not self.api_key or not self.ep:
            raise GeneratorError("火山方舟API未配置")

        # 构建提示词
        prompt = self._build_prompt(task, shot)
        log.info(f"[Ark] 提交视频生成任务: {shot['shot_id']}")

        # 1. 创建生成任务
        task_id = await self._create_task(prompt)
        log.info(f"[Ark] 任务已创建: {task_id}")

        # 2. 轮询任务状态
        video_url = await self._poll_task(task_id)
        log.info(f"[Ark] 视频生成完成: {video_url[:60]}...")

        # 3. 下载视频
        await self._download_video(video_url, output_path)

        if not self.validate_output(output_path):
            raise GeneratorError("下载的视频文件无效")

        return self.name

    def _build_prompt(self, task, shot):
        """构建视频生成提示词"""
        char_name = shot.get("character_name", "")
        theme = task.theme
        style = task.style_params.get("visual_style", "国风仙侠")
        forbidden = task.style_params.get("forbidden", [])

        prompt = f"{char_name}，{theme}。{style}风格。"
        if forbidden:
            prompt += f" 禁止出现：{', '.join(forbidden)}。"
        prompt += " 9:16竖屏，电影级画质，流畅运镜。"
        return prompt

    async def _create_task(self, prompt):
        """创建视频生成任务"""
        url = f"{self.api_base}/contents/generations/tasks"
        payload = json.dumps({
            "model": self.ep,
            "content": [{"type": "text", "text": prompt}],
            "ratio": "9:16",
            "duration": 5,
            "watermark": False,
        }).encode()

        req = urllib.request.Request(
            url,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST"
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read())
                return data.get("id") or data.get("task_id")
        except urllib.error.HTTPError as e:
            body = e.read().decode() if e.fp else ""
            raise GeneratorError(f"API错误 {e.code}: {body[:200]}")
        except Exception as e:
            raise GeneratorError(f"创建任务失败: {e}")

    async def _poll_task(self, task_id):
        """轮询任务状态"""
        url = f"{self.api_base}/contents/generations/tasks/{task_id}"
        start_time = time.time()

        while time.time() - start_time < self.max_poll_time:
            req = urllib.request.Request(
                url,
                headers={"Authorization": f"Bearer {self.api_key}"}
            )
            try:
                with urllib.request.urlopen(req, timeout=15) as resp:
                    data = json.loads(resp.read())

                status = data.get("status", "")
                if status == "succeeded":
                    content = data.get("content", [])
                    if content and isinstance(content, list):
                        for item in content:
                            if item.get("type") == "video_url":
                                return item["video_url"]["url"]
                    raise GeneratorError("任务成功但未找到视频URL")
                elif status == "failed":
                    error = data.get("error", {})
                    raise GeneratorError(f"生成失败: {error.get('message', '未知错误')}")
                else:
                    log.debug(f"[Ark] 任务状态: {status}，等待中...")
                    await asyncio.sleep(self.poll_interval)
            except GeneratorError:
                raise
            except Exception as e:
                log.warning(f"[Ark] 轮询异常: {e}")
                await asyncio.sleep(self.poll_interval)

        raise GeneratorError("视频生成超时")

    async def _download_video(self, url, output_path: Path):
        """下载视频文件"""
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=120) as resp:
            with open(output_path, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
