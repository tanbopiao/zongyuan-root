"""生成器工厂 - 根据配置选择合适的视频生成器"""
from .base import BaseGenerator, GeneratorError
from .mock import MockGenerator
from .ark import ArkGenerator
from ..config import Config


def get_generator(mode=None) -> BaseGenerator:
    """
    获取视频生成器实例
    Args:
        mode: 'mock' | 'real' | None(自动选择)
    Returns:
        BaseGenerator实例
    """
    if mode is None:
        mode = Config.RUN_MODE

    if mode == "real":
        return ArkGenerator()
    return MockGenerator()


__all__ = ["BaseGenerator", "GeneratorError", "MockGenerator", "ArkGenerator", "get_generator"]
