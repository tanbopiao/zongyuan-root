"""视频生成器抽象基类"""
from abc import ABC, abstractmethod
from pathlib import Path


class BaseGenerator(ABC):
    """视频生成器基类 - 所有生成器必须实现generate方法"""

    name = "base"
    description = "基础生成器"

    def __init__(self, config=None):
        self.config = config or {}

    @abstractmethod
    async def generate(self, task, shot, output_path: Path) -> str:
        """
        生成单个镜头视频
        Args:
            task: 任务对象
            shot: 镜头对象
            output_path: 输出文件路径
        Returns:
            生成器名称字符串
        Raises:
            GeneratorError: 生成失败时抛出
        """
        pass

    async def generate_keyframe(self, task, shot, output_path: Path) -> str:
        """生成关键帧图片（可选实现）"""
        return self.name

    def validate_output(self, output_path: Path) -> bool:
        """验证输出文件是否有效"""
        if not output_path.exists():
            return False
        if output_path.stat().st_size < 1000:
            return False
        return True


class GeneratorError(Exception):
    """生成器异常"""
    pass
