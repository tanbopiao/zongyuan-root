"""结构化日志配置"""
import logging
import sys
from pathlib import Path
from .config import BASE_DIR

LOG_FILE = BASE_DIR / "agent.log"


def setup_logging(level=logging.INFO):
    logger = logging.getLogger("kd_agent")
    logger.setLevel(level)

    if logger.handlers:
        return logger

    # 控制台输出
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(level)
    console_fmt = logging.Formatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%H:%M:%S"
    )
    console.setFormatter(console_fmt)
    logger.addHandler(console)

    # 文件输出
    try:
        file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_fmt = logging.Formatter(
            "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        file_handler.setFormatter(file_fmt)
        logger.addHandler(file_handler)
    except Exception:
        pass

    return logger


def get_logger(name):
    return logging.getLogger(f"kd_agent.{name}")
