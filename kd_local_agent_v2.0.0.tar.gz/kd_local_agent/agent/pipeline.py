"""流水线调度器 - 协调7个阶段执行"""
import asyncio
from datetime import datetime
from .stages import STAGE_REGISTRY
from .generators import get_generator
from .quality_gate import QualityGate
from .event_bus import event_bus, EVENTS
from .config import Config
from .logging_setup import get_logger

log = get_logger("pipeline")


class PipelineScheduler:
    """流水线调度器"""

    def __init__(self, task_queue):
        self.tq = task_queue
        self.eb = event_bus
        self.generator = get_generator()
        self.quality_gate = QualityGate(enabled=Config.QUALITY_GATE_ENABLED)
        self.stages = []
        self._init_stages()

    def _init_stages(self):
        """初始化所有阶段实例"""
        for stage_cls in STAGE_REGISTRY:
            stage = stage_cls(self.tq, self.eb, self.generator)
            self.stages.append(stage)
        log.info(f"流水线初始化完成: {len(self.stages)}个阶段, 生成器={self.generator.name}")

    async def run_task(self, task_id):
        """运行单个任务的完整流水线"""
        task = self.tq.get_task(task_id)
        if not task:
            log.error(f"任务不存在: {task_id}")
            return

        task.status = "running"
        task.started_at = datetime.now().isoformat()
        self.tq.update_task(task_id, status="running", started_at=task.started_at)

        await self.eb.publish(EVENTS["TASK_STARTED"], {"task_id": task_id, "title": task.title})
        log.info(f"任务开始: {task_id} - {task.title}")

        cumulative_weight = 0

        try:
            for stage in self.stages:
                # 阶段开始
                await self.eb.publish(EVENTS["STAGE_STARTED"], {
                    "task_id": task_id,
                    "stage": stage.stage_id,
                    "stage_name": stage.stage_name,
                })

                # 执行阶段
                result = await stage.execute(task)

                # 阶段完成
                cumulative_weight += stage.weight
                await self.eb.publish(EVENTS["STAGE_COMPLETED"], {
                    "task_id": task_id,
                    "stage": stage.stage_id,
                    "stage_name": stage.stage_name,
                    "result": result,
                })

                log.info(f"阶段完成 [{stage.stage_name}]: {result}")

            # 质量门禁
            qg_result = await self.quality_gate.run_checks(task)
            await self.eb.publish(EVENTS["QUALITY_CHECK"], {
                "task_id": task_id,
                "result": qg_result,
            })

            if not qg_result["passed"]:
                log.warning(f"质量门禁未通过: {qg_result}")
                await self.eb.publish(EVENTS["QUALITY_FAILED"], {
                    "task_id": task_id,
                    "checks": qg_result["checks"],
                })
            else:
                await self.eb.publish(EVENTS["QUALITY_PASSED"], {"task_id": task_id})

            # 任务完成
            task.status = "completed"
            task.completed_at = datetime.now().isoformat()
            task.overall_progress = 100
            self.tq.update_task(
                task_id, status="completed",
                completed_at=task.completed_at,
                overall_progress=100,
            )

            await self.eb.publish(EVENTS["TASK_COMPLETED"], {
                "task_id": task_id,
                "title": task.title,
                "file_size_mb": task.file_size_mb,
                "shots_done": task.shots_done,
                "shots_total": task.shots_total,
                "merkle_root": task.merkle_root,
                "lock_credential_id": task.lock_credential_id,
                "watermark_added": task.watermark_added,
                "quality_gate": qg_result,
            })

            log.info(f"任务完成: {task_id} - {task.title} ({task.file_size_mb}MB)")

        except Exception as e:
            task.status = "failed"
            self.tq.update_task(task_id, status="failed")
            await self.eb.publish(EVENTS["TASK_FAILED"], {
                "task_id": task_id,
                "error": str(e),
            })
            log.error(f"任务失败 [{task_id}]: {e}", exc_info=True)

    async def rerun_shot(self, task_id, shot_id):
        """重跑单个镜头"""
        task = self.tq.get_task(task_id)
        if not task:
            return

        # 找到视频阶段
        video_stage = next((s for s in self.stages if s.stage_id == "video"), None)
        if not video_stage:
            return

        # 重置镜头状态
        self.tq.update_shot(task_id, shot_id, status="pending", retry_count=0)
        await self.eb.publish(EVENTS["SHOT_RERUN"], {
            "task_id": task_id, "shot_id": shot_id,
        })

        # 找到镜头对象
        shot = None
        for s in task.shots:
            if s["shot_id"] == shot_id:
                shot = s
                break
        if not shot:
            return

        # 重新执行该镜头
        from pathlib import Path
        video_path = Path(task.output_dir) / f"{shot_id}.mp4"

        self.tq.update_shot(task_id, shot_id, status="running")
        await self.eb.publish(EVENTS["SHOT_STARTED"], {
            "task_id": task_id, "shot_id": shot_id,
            "character": shot["character_name"],
        })

        try:
            generator_name = await self.generator.generate(task, shot, video_path)
            self.tq.update_shot(
                task_id, shot_id, status="done",
                generator=generator_name, video_path=str(video_path)
            )
            await self.eb.publish(EVENTS["SHOT_COMPLETED"], {
                "task_id": task_id, "shot_id": shot_id,
                "generator": generator_name,
            })
            log.info(f"镜头重跑成功: {shot_id}")
        except Exception as e:
            self.tq.update_shot(task_id, shot_id, status="failed", error=str(e))
            await self.eb.publish(EVENTS["SHOT_FAILED"], {
                "task_id": task_id, "shot_id": shot_id, "error": str(e),
            })
            log.error(f"镜头重跑失败 [{shot_id}]: {e}")
