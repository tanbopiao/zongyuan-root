"""质量门禁引擎 - QM1-QM5五项质量检查"""
from pathlib import Path
from .logging_setup import get_logger

log = get_logger("quality_gate")


class QualityGate:
    """质量门禁引擎"""

    def __init__(self, enabled=True):
        self.enabled = enabled
        self.checks = {
            "qm1": self._check_character_consistency,
            "qm2": self._check_style_consistency,
            "qm3": self._check_video_quality,
            "qm4": self._check_audio_sync,
            "qm5": self._check_watermark,
        }

    async def run_checks(self, task) -> dict:
        """运行所有质量检查"""
        if not self.enabled:
            return {"passed": True, "checks": {}, "skipped": True}

        results = {}
        all_passed = True

        for qm_id, check_fn in self.checks.items():
            # 检查任务是否启用了该质量项
            if not task.quality_gate.get(qm_id, True):
                results[qm_id] = {"passed": True, "skipped": True, "message": "用户跳过"}
                continue

            try:
                passed, message = await check_fn(task)
                results[qm_id] = {"passed": passed, "message": message}
                if not passed:
                    all_passed = False
                    log.warning(f"质量门禁未通过 [{qm_id}]: {message}")
            except Exception as e:
                results[qm_id] = {"passed": False, "error": str(e)}
                all_passed = False

        return {"passed": all_passed, "checks": results}

    async def _check_character_consistency(self, task):
        """QM1: 角色一致性检查"""
        # 检查所有镜头是否都有角色信息
        for shot in task.shots:
            if not shot.get("character_name"):
                return False, f"镜头{shot['shot_id']}缺少角色信息"
        return True, "所有镜头角色信息完整"

    async def _check_style_consistency(self, task):
        """QM2: 风格一致性检查"""
        # 检查所有镜头生成器是否一致（或允许混合）
        generators = set()
        for shot in task.shots:
            if shot.get("generator"):
                generators.add(shot["generator"])
        if len(generators) > 1:
            return True, f"多生成器混合: {', '.join(generators)}（允许）"
        return True, "生成器一致"

    async def _check_video_quality(self, task):
        """QM3: 视频质量检查"""
        # 检查输出视频是否存在且大小合理
        output_path = Path(task.output_dir) / "output.mp4"
        if not output_path.exists():
            return False, "输出视频不存在"
        size_mb = output_path.stat().st_size / (1024 * 1024)
        if size_mb < 0.01:
            return False, f"输出视频过小: {size_mb:.3f}MB"
        return True, f"输出视频大小: {size_mb:.2f}MB"

    async def _check_audio_sync(self, task):
        """QM4: 音频同步检查"""
        # 检查每个镜头视频是否有音轨（mock模式都有）
        for shot in task.shots:
            if shot["status"] == "done" and shot.get("video_path"):
                if not Path(shot["video_path"]).exists():
                    return False, f"镜头{shot['shot_id']}视频文件丢失"
        return True, "所有镜头视频文件完整"

    async def _check_watermark(self, task):
        """QM5: 溯源水印检查"""
        if not task.watermark_added:
            return False, "溯源水印未嵌入"
        return True, "溯源水印已嵌入"
