"""7个流水线阶段实现"""
import asyncio
import json
import subprocess
from pathlib import Path
from .base import BaseStage
from ..logging_setup import get_logger

log = get_logger("stages")


class ScriptStage(BaseStage):
    """剧本生成阶段"""
    stage_id = "script"
    stage_name = "剧本"
    weight = 10

    async def execute(self, task):
        steps = ["分析主题梗概", "生成剧情大纲", "拆分解目标点", "生成角色台词", "剧本质量审核"]
        for i, step in enumerate(steps):
            await self.emit_progress(task.task_id, step, int((i + 1) / len(steps) * 100))
            await self.emit_log(task.task_id, step)
            await asyncio.sleep(0.2)

        script = {
            "title": task.title,
            "theme": task.theme,
            "characters": task.characters,
            "scenes": [{"id": i + 1, "desc": f"第{i+1}幕：{task.theme}"} for i in range(3)],
        }
        self.save_json(task, "script.json", script)
        return {"script_path": str(Path(task.output_dir) / "script.json")}


class StoryboardStage(BaseStage):
    """分镜拆分阶段"""
    stage_id = "storyboard"
    stage_name = "分镜"
    weight = 10

    async def execute(self, task):
        steps = ["剧本转分镜结构", "分配镜头时长", "设计镜头运动", "标注转场方式", "生成分镜表"]
        for i, step in enumerate(steps):
            await self.emit_progress(task.task_id, step, int((i + 1) / len(steps) * 100))
            await self.emit_log(task.task_id, step)
            await asyncio.sleep(0.2)

        storyboard = [
            {"shot_id": s["shot_id"], "character": s["character_name"], "duration": s["duration"]}
            for s in task.shots
        ]
        self.save_json(task, "storyboard.json", storyboard)
        return {"storyboard_path": str(Path(task.output_dir) / "storyboard.json")}


class KeyframeStage(BaseStage):
    """关键帧生成阶段"""
    stage_id = "keyframes"
    stage_name = "关键帧"
    weight = 15

    async def execute(self, task):
        steps = ["角色风格锁定", "生成首帧关键帧", "生成尾帧关键帧", "关键帧质量审核", "风格一致性校验"]
        for i, step in enumerate(steps):
            await self.emit_progress(task.task_id, step, int((i + 1) / len(steps) * 100))
            await self.emit_log(task.task_id, step)
            await asyncio.sleep(0.2)

        # 为每个镜头生成关键帧
        for shot in task.shots:
            keyframe_path = Path(task.output_dir) / f"{shot['shot_id']}_keyframe.jpg"
            if self.generator:
                try:
                    await self.generator.generate_keyframe(task, shot, keyframe_path)
                except Exception as e:
                    log.warning(f"关键帧生成失败 {shot['shot_id']}: {e}")

        return {"keyframes_generated": len(task.shots)}


class VideoStage(BaseStage):
    """视频生成阶段 - 核心阶段"""
    stage_id = "video"
    stage_name = "视频"
    weight = 35

    async def execute(self, task):
        from ..event_bus import EVENTS
        total = len(task.shots)

        for i, shot in enumerate(task.shots):
            # 跳过已完成的镜头（重跑场景）
            if shot["status"] == "done":
                continue

            # 镜头开始
            self.tq.update_shot(task.task_id, shot["shot_id"], status="running")
            await self.eb.publish(EVENTS["SHOT_STARTED"], {
                "task_id": task.task_id,
                "shot_id": shot["shot_id"],
                "character": shot["character_name"],
            })

            # 进度
            overall = int(i / total * 100)
            await self.emit_progress(task.task_id, f"渲染镜头 {shot['shot_id']} ({shot['character_name']})", overall)

            # 生成视频
            video_path = Path(task.output_dir) / f"{shot['shot_id']}.mp4"
            try:
                generator_name = await self.generator.generate(task, shot, video_path)
                self.tq.update_shot(
                    task.task_id, shot["shot_id"],
                    status="done", generator=generator_name, video_path=str(video_path)
                )
                await self.eb.publish(EVENTS["SHOT_COMPLETED"], {
                    "task_id": task.task_id,
                    "shot_id": shot["shot_id"],
                    "generator": generator_name,
                })
                await self.emit_log(task.task_id, f"镜头{shot['shot_id']}完成 ({generator_name})")
            except Exception as e:
                shot["retry_count"] = shot.get("retry_count", 0) + 1
                self.tq.update_shot(task.task_id, shot["shot_id"], status="failed", error=str(e))
                await self.eb.publish(EVENTS["SHOT_FAILED"], {
                    "task_id": task.task_id,
                    "shot_id": shot["shot_id"],
                    "error": str(e),
                    "retry_count": shot["retry_count"],
                })
                await self.emit_log(task.task_id, f"镜头{shot['shot_id']}失败: {e}", "warn")

            await asyncio.sleep(0.3)

        return {"shots_completed": task.shots_done, "shots_total": total}


class AudioStage(BaseStage):
    """音频生成阶段"""
    stage_id = "audio"
    stage_name = "音频"
    weight = 10

    async def execute(self, task):
        steps = ["生成背景音乐", "合成环境音效", "音频混合", "音量标准化", "音频质量审核"]
        for i, step in enumerate(steps):
            await self.emit_progress(task.task_id, step, int((i + 1) / len(steps) * 100))
            await self.emit_log(task.task_id, step)
            await asyncio.sleep(0.2)
        return {"audio_mixed": True}


class ComposeStage(BaseStage):
    """视频合成阶段"""
    stage_id = "compose"
    stage_name = "合成"
    weight = 15

    async def execute(self, task):
        steps = ["拼接镜头片段", "添加转场效果", "烧录溯源水印", "合成音轨", "最终渲染"]
        for i, step in enumerate(steps):
            await self.emit_progress(task.task_id, step, int((i + 1) / len(steps) * 100))
            await self.emit_log(task.task_id, step)
            await asyncio.sleep(0.2)

        # 拼接所有已完成的镜头
        video_files = [
            s["video_path"] for s in task.shots
            if s.get("video_path") and Path(s["video_path"]).exists()
        ]
        output_path = Path(task.output_dir) / "output.mp4"

        if video_files:
            concat_file = Path(task.output_dir) / "concat.txt"
            with open(concat_file, "w") as f:
                for vf in video_files:
                    f.write(f"file '{vf}'\n")
            try:
                proc = await asyncio.create_subprocess_exec(
                    "ffmpeg", "-y", "-f", "concat", "-safe", "0",
                    "-i", str(concat_file), "-c", "copy", str(output_path),
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
                )
                await asyncio.wait_for(proc.communicate(), timeout=60)
            except Exception as e:
                log.error(f"视频合成失败: {e}")
                # 降级：用第一个镜头作为输出
                if video_files:
                    import shutil
                    shutil.copy(video_files[0], str(output_path))
        else:
            # 没有视频文件，生成占位
            try:
                proc = await asyncio.create_subprocess_exec(
                    "ffmpeg", "-y", "-f", "lavfi",
                    "-i", f"color=c=#0a0a12:s=1080x1920:d={task.duration * task.shots_total}",
                    "-c:v", "libx264", "-preset", "ultrafast", str(output_path),
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
                )
                await asyncio.wait_for(proc.communicate(), timeout=30)
            except Exception:
                pass

        task.watermark_added = True
        task.final_video_path = str(output_path)
        if output_path.exists():
            task.file_size_mb = round(output_path.stat().st_size / (1024 * 1024), 2)

        return {"output_path": str(output_path), "file_size_mb": task.file_size_mb}


class ArchiveStage(BaseStage):
    """归档锁档阶段"""
    stage_id = "archive"
    stage_name = "归档"
    weight = 5

    async def execute(self, task):
        import time
        steps = ["计算Merkle哈希", "生成锁档凭证", "写入元数据", "归档校验", "完成"]
        for i, step in enumerate(steps):
            await self.emit_progress(task.task_id, step, int((i + 1) / len(steps) * 100))
            await self.emit_log(task.task_id, step)
            await asyncio.sleep(0.2)

        # 计算Merkle根
        task.compute_merkle_root()
        task.lock_credential_id = f"LOCK-{task.task_id}-{int(time.time())}"

        # 保存元数据
        metadata = {
            "task_id": task.task_id,
            "title": task.title,
            "created_at": task.created_at,
            "completed_at": task.completed_at,
            "shots_total": task.shots_total,
            "shots_done": task.shots_done,
            "merkle_root": task.merkle_root,
            "lock_credential_id": task.lock_credential_id,
            "watermark_added": task.watermark_added,
        }
        self.save_json(task, "metadata.json", metadata)
        return {"merkle_root": task.merkle_root, "lock_credential_id": task.lock_credential_id}


# 阶段注册表 - 按执行顺序
STAGE_REGISTRY = [
    ScriptStage,
    StoryboardStage,
    KeyframeStage,
    VideoStage,
    AudioStage,
    ComposeStage,
    ArchiveStage,
]
