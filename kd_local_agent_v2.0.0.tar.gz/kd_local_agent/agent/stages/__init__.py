"""阶段插件注册表"""
from .base import BaseStage
from .impl import (
    ScriptStage, StoryboardStage, KeyframeStage,
    VideoStage, AudioStage, ComposeStage, ArchiveStage,
    STAGE_REGISTRY,
)

__all__ = [
    "BaseStage",
    "ScriptStage", "StoryboardStage", "KeyframeStage",
    "VideoStage", "AudioStage", "ComposeStage", "ArchiveStage",
    "STAGE_REGISTRY",
]
