"""阶段基类 - 所有流水线阶段的抽象基类"""
from abc import ABC, abstractmethod
from pathlib import Path


class BaseStage(ABC):
    """流水线阶段基类"""

    stage_id = "base"
    stage_name = "基础阶段"
    weight = 10  # 进度权重

    def __init__(self, task_queue, event_bus, generator=None):
        self.tq = task_queue
        self.eb = event_bus
        self.generator = generator

    @abstractmethod
    async def execute(self, task) -> dict:
        """
        执行阶段逻辑
        Args:
            task: Task对象
        Returns:
            阶段结果字典
        """
        pass

    async def emit_progress(self, task_id, step, progress):
        """发送进度事件"""
        from ..event_bus import EVENTS
        await self.eb.publish(EVENTS["STAGE_PROGRESS"], {
            "task_id": task_id,
            "stage": self.stage_id,
            "stage_name": self.stage_name,
            "step": step,
            "progress": progress,
        })

    async def emit_log(self, task_id, message, level="info"):
        """发送日志事件"""
        from ..event_bus import EVENTS
        await self.eb.publish(EVENTS["LOG"], {
            "task_id": task_id,
            "stage": self.stage_id,
            "message": message,
            "level": level,
        })

    def save_json(self, task, filename, data):
        """保存JSON文件到任务输出目录"""
        import json
        path = Path(task.output_dir) / filename
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return path
