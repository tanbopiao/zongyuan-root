"""WebSocket服务器 - 事件总线到前端消息的桥接"""
import asyncio
import json
import time
from datetime import datetime
import websockets
from .config import Config
from .task_queue import TaskQueue
from .pipeline import PipelineScheduler
from .http_server import PreviewHTTPServer
from .event_bus import event_bus, EVENTS
from .logging_setup import get_logger, setup_logging

log = get_logger("ws_server")


class WSServer:
    """WebSocket服务器"""

    def __init__(self):
        self.tq = TaskQueue()
        self.pipeline = PipelineScheduler(self.tq)
        self.http = PreviewHTTPServer()
        self.clients = set()
        self.ws_server = None
        self._setup_event_subscriptions()

    def _setup_event_subscriptions(self):
        """订阅事件总线，转发到前端"""
        # 任务事件
        event_bus.subscribe(EVENTS["TASK_STARTED"], self._on_task_started)
        event_bus.subscribe(EVENTS["TASK_COMPLETED"], self._on_task_completed)
        event_bus.subscribe(EVENTS["TASK_FAILED"], self._on_task_failed)

        # 阶段事件
        event_bus.subscribe(EVENTS["STAGE_STARTED"], self._on_stage_started)
        event_bus.subscribe(EVENTS["STAGE_PROGRESS"], self._on_stage_progress)
        event_bus.subscribe(EVENTS["STAGE_COMPLETED"], self._on_stage_completed)

        # 镜头事件
        event_bus.subscribe(EVENTS["SHOT_STARTED"], self._on_shot_started)
        event_bus.subscribe(EVENTS["SHOT_COMPLETED"], self._on_shot_completed)
        event_bus.subscribe(EVENTS["SHOT_FAILED"], self._on_shot_failed)
        event_bus.subscribe(EVENTS["SHOT_RERUN"], self._on_shot_rerun)

        # 日志事件
        event_bus.subscribe(EVENTS["LOG"], self._on_log)

        # 质量门禁
        event_bus.subscribe(EVENTS["QUALITY_CHECK"], self._on_quality_check)

    async def _broadcast(self, msg_type, payload):
        """向所有客户端广播"""
        if not self.clients:
            return
        msg = json.dumps({
            "type": msg_type,
            "payload": payload,
            "ts": datetime.now().isoformat(),
        }, ensure_ascii=False)
        disconnected = set()
        for client in list(self.clients):
            try:
                await client.send(msg)
            except Exception:
                disconnected.add(client)
        self.clients -= disconnected

    # === 事件处理器 ===
    async def _on_task_started(self, data):
        await self._broadcast("log", {"stage": "system", "message": f"任务开始: {data.get('title','')}"})

    async def _on_task_completed(self, data):
        task_id = data["task_id"]
        task = self.tq.get_task(task_id)
        await self._broadcast("render_complete", {
            "task_id": task_id,
            "final_video_path": task.final_video_path if task else None,
            "preview_url": f"http://127.0.0.1:{Config.HTTP_PORT}/preview/{task_id}/output.mp4",
            "file_size_mb": data.get("file_size_mb", 0),
            "duration_seconds": (task.duration * task.shots_total) if task else 0,
            "shots_done": data.get("shots_done", 0),
            "shots_total": data.get("shots_total", 0),
            "video_codec": "h264",
            "audio_codec": "aac",
            "merkle_root": data.get("merkle_root"),
            "lock_credential_id": data.get("lock_credential_id"),
            "watermark_added": data.get("watermark_added", False),
            "quality_gate": data.get("quality_gate"),
        })

    async def _on_task_failed(self, data):
        await self._broadcast("error", {
            "error_code": "TASK_FAILED",
            "message": data.get("error", "未知错误"),
        })

    async def _on_stage_started(self, data):
        pass  # 进度事件会处理

    async def _on_stage_progress(self, data):
        # 计算总体进度
        task = self.tq.get_task(data["task_id"])
        if task:
            # 找到当前阶段的累积权重
            cumulative = 0
            from .stages import STAGE_REGISTRY
            for stage_cls in STAGE_REGISTRY:
                if stage_cls.stage_id == data["stage"]:
                    break
                cumulative += stage_cls.weight
            current_stage_weight = next(
                (s.weight for s in STAGE_REGISTRY if s.stage_id == data["stage"]), 10
            )
            overall = int(cumulative + current_stage_weight * data["progress"] / 100)
            task.overall_progress = overall
            task.current_stage = data["stage"]

        await self._broadcast("progress", {
            "stage": data["stage"],
            "stage_name": data["stage_name"],
            "current_step": data["step"],
            "overall_progress": overall if task else 0,
            "stage_progress": data["progress"],
        })

    async def _on_stage_completed(self, data):
        pass

    async def _on_shot_started(self, data):
        self.tq.update_shot(data["task_id"], data["shot_id"], status="running")
        await self._broadcast("project_event", {
            "event": "shot_start",
            "shot_id": data["shot_id"],
            "character": data.get("character", ""),
        })

    async def _on_shot_completed(self, data):
        await self._broadcast("project_event", {
            "event": "shot_done",
            "shot_id": data["shot_id"],
            "generator": data.get("generator", ""),
        })

    async def _on_shot_failed(self, data):
        await self._broadcast("project_event", {
            "event": "shot_failed",
            "shot_id": data["shot_id"],
            "error": data.get("error", ""),
        })

    async def _on_shot_rerun(self, data):
        await self._broadcast("project_event", {
            "event": "shot_rerun",
            "shot_id": data["shot_id"],
        })

    async def _on_log(self, data):
        await self._broadcast("log", {
            "stage": data.get("stage", "system"),
            "message": data.get("message", ""),
            "level": data.get("level", "info"),
        })

    async def _on_quality_check(self, data):
        result = data.get("result", {})
        level = "info" if result.get("passed") else "warn"
        await self._broadcast("log", {
            "stage": "quality",
            "message": f"质量门禁: {'通过' if result.get('passed') else '未通过'}",
            "level": level,
        })

    # === WebSocket消息处理 ===
    async def handle_message(self, client, raw_msg):
        try:
            data = json.loads(raw_msg)
        except json.JSONDecodeError:
            return

        msg_type = data.get("type")
        payload = data.get("payload", {})

        if msg_type == "ping":
            await client.send(json.dumps({"type": "pong", "payload": {"timestamp": time.time()}}))
            return

        if msg_type == "agent_status":
            status = Config.summary()
            status["generator"] = self.pipeline.generator.name
            await client.send(json.dumps({
                "type": "agent_status",
                "payload": status,
            }))
            return

        if msg_type == "instruction_packet":
            task = self.tq.create_task(payload)
            await client.send(json.dumps({
                "type": "task_accepted",
                "payload": {
                    "task_id": task.task_id,
                    "title": task.title,
                    "shots_total": task.shots_total,
                },
            }))
            # 后台运行流水线
            asyncio.create_task(self.pipeline.run_task(task.task_id))
            return

        if msg_type == "shot_rerun":
            task_id = payload.get("project_id")
            shot_id = payload.get("shot_id")
            asyncio.create_task(self.pipeline.rerun_shot(task_id, shot_id))
            return

        if msg_type == "project_status":
            task_id = payload.get("project_id")
            task = self.tq.get_task(task_id)
            if task:
                await client.send(json.dumps({
                    "type": "project_status",
                    "payload": {
                        "task_id": task.task_id,
                        "status": task.status,
                        "overall_progress": task.overall_progress,
                        "shots": task.shots,
                    },
                }))
            return

    async def handler(self, websocket):
        self.clients.add(websocket)
        log.info(f"客户端连接，当前 {len(self.clients)} 个客户端")

        # 发送代理状态
        status = Config.summary()
        status["generator"] = self.pipeline.generator.name
        await websocket.send(json.dumps({
            "type": "agent_status",
            "payload": status,
        }))

        try:
            async for message in websocket:
                await self.handle_message(websocket, message)
        except websockets.exceptions.ConnectionClosed:
            pass
        finally:
            self.clients.discard(websocket)
            log.info(f"客户端断开，当前 {len(self.clients)} 个客户端")

    async def start(self):
        """启动所有服务"""
        # 加载历史任务
        self.tq.load_tasks()

        # 启动HTTP预览服务
        await self.http.start()

        # 启动WebSocket服务器
        self.ws_server = await websockets.serve(
            self.handler, Config.WS_HOST, Config.WS_PORT,
            ping_interval=20, ping_timeout=20,
        )

        summary = Config.summary()
        print("=" * 50)
        print("  昆仑洞天本地自治代理 v2.0")
        print("=" * 50)
        print(f"  WebSocket: {summary['ws_url']}")
        print(f"  HTTP预览 : {summary['http_preview']}")
        print(f"  模式     : {summary['mode']}")
        print(f"  生成器   : {self.pipeline.generator.name}")
        print(f"  质量门禁 : {'启用' if summary['quality_gate'] else '禁用'}")
        print("=" * 50)
        print("  等待前端连接...")
        print("=" * 50)

        await self.ws_server.wait_closed()

    def stop(self):
        if self.ws_server:
            self.ws_server.close()
        self.http.stop()


def run_server():
    setup_logging()
    server = WSServer()
    asyncio.run(server.start())


if __name__ == "__main__":
    run_server()
