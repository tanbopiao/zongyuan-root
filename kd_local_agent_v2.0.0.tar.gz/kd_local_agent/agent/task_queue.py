"""任务队列与持久化管理"""
import json
import uuid
import hashlib
import time
from datetime import datetime
from pathlib import Path
from .config import Config, TASKS_DIR, OUTPUT_DIR
from .logging_setup import get_logger

log = get_logger("task_queue")


class Task:
    """任务对象"""

    def __init__(self, task_id, instruction):
        self.task_id = task_id
        self.title = instruction.get("title", "未命名任务")
        self.theme = instruction.get("theme", "")
        self.characters = instruction.get("characters", [])
        self.duration = instruction.get("duration", 10)
        self.model = instruction.get("model", "auto")
        self.resolution = instruction.get("resolution", "1080p")
        self.ratio = instruction.get("ratio", "9:16")
        self.style_params = instruction.get("style_params", {})
        self.quality_gate = instruction.get("quality_gate", {})

        self.status = "pending"  # pending/running/completed/failed
        self.current_stage = None
        self.overall_progress = 0
        self.created_at = datetime.now().isoformat()
        self.started_at = None
        self.completed_at = None
        self.output_dir = str(OUTPUT_DIR / task_id)
        self.final_video_path = None
        self.merkle_root = None
        self.lock_credential_id = None
        self.watermark_added = False
        self.file_size_mb = 0
        self.shots_done = 0
        self.shots_total = Config.SHOTS_PER_TASK
        self.retries = {}
        self.logs = []

        # 生成镜头
        self.shots = self._create_shots()

        # 创建输出目录
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)

    def _create_shots(self):
        shots = []
        char_list = self.characters if self.characters else list(Config.CHARACTERS.keys())[:2]
        for i in range(Config.SHOTS_PER_TASK):
            char_key = char_list[i % len(char_list)]
            char_info = Config.CHARACTERS.get(char_key, {"name": char_key, "style": ""})
            shots.append({
                "shot_id": f"S{i+1:02d}",
                "character": char_key,
                "character_name": char_info["name"],
                "status": "pending",
                "generator": None,
                "error": None,
                "video_path": None,
                "duration": self.duration,
                "retry_count": 0,
            })
        return shots

    def to_dict(self):
        return {
            "task_id": self.task_id,
            "title": self.title,
            "theme": self.theme,
            "characters": self.characters,
            "duration": self.duration,
            "status": self.status,
            "current_stage": self.current_stage,
            "overall_progress": self.overall_progress,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "shots": self.shots,
            "shots_done": self.shots_done,
            "shots_total": self.shots_total,
            "final_video_path": self.final_video_path,
            "merkle_root": self.merkle_root,
            "lock_credential_id": self.lock_credential_id,
            "watermark_added": self.watermark_added,
            "file_size_mb": self.file_size_mb,
        }

    def compute_merkle_root(self):
        hashes = []
        for shot in self.shots:
            h = hashlib.sha256(
                f"{shot['shot_id']}:{shot['status']}:{shot.get('video_path', '')}".encode()
            ).hexdigest()
            hashes.append(h)
        combined = "".join(hashes)
        self.merkle_root = hashlib.sha256(combined.encode()).hexdigest().upper()
        return self.merkle_root


class TaskQueue:
    """异步任务队列 + 持久化"""

    def __init__(self):
        self.tasks = {}  # task_id -> Task
        self.queue = []  # 等待执行的task_id列表
        self._persist_dir = TASKS_DIR

    def create_task(self, instruction):
        task_id = instruction.get("project_id") or f"PROJ-{uuid.uuid4().hex[:8].upper()}"
        task = Task(task_id, instruction)
        self.tasks[task_id] = task
        self.queue.append(task_id)
        self._persist(task)
        log.info(f"任务创建: {task_id} - {task.title}")
        return task

    def get_task(self, task_id):
        return self.tasks.get(task_id)

    def get_next_task(self):
        """获取下一个待执行任务"""
        while self.queue:
            task_id = self.queue.pop(0)
            task = self.tasks.get(task_id)
            if task and task.status == "pending":
                return task
        return None

    def update_task(self, task_id, **kwargs):
        task = self.tasks.get(task_id)
        if not task:
            return
        for k, v in kwargs.items():
            if hasattr(task, k):
                setattr(task, k, v)
        self._persist(task)

    def update_shot(self, task_id, shot_id, **kwargs):
        task = self.tasks.get(task_id)
        if not task:
            return
        for shot in task.shots:
            if shot["shot_id"] == shot_id:
                shot.update(kwargs)
                break
        task.shots_done = sum(1 for s in task.shots if s["status"] == "done")
        self._persist(task)

    def add_log(self, task_id, stage, message, level="info"):
        task = self.tasks.get(task_id)
        if not task:
            return
        task.logs.append({
            "time": datetime.now().strftime("%H:%M:%S"),
            "stage": stage,
            "message": message,
            "level": level,
        })
        # 只保留最近500条
        if len(task.logs) > 500:
            task.logs = task.logs[-500:]

    def _persist(self, task):
        """持久化任务状态到文件"""
        try:
            state_file = self._persist_dir / f"{task.task_id}.json"
            with open(state_file, "w", encoding="utf-8") as f:
                json.dump(task.to_dict(), f, ensure_ascii=False, indent=2)
        except Exception as e:
            log.error(f"持久化失败 [{task.task_id}]: {e}")

    def load_tasks(self):
        """从磁盘加载历史任务"""
        loaded = 0
        for state_file in self._persist_dir.glob("*.json"):
            try:
                with open(state_file, encoding="utf-8") as f:
                    data = json.load(f)
                task_id = data["task_id"]
                if task_id not in self.tasks:
                    # 重建任务对象（简化）
                    task = Task(task_id, {
                        "title": data.get("title", ""),
                        "theme": data.get("theme", ""),
                        "characters": data.get("characters", []),
                        "duration": data.get("duration", 10),
                    })
                    task.status = data.get("status", "pending")
                    task.overall_progress = data.get("overall_progress", 0)
                    task.shots = data.get("shots", task.shots)
                    task.shots_done = data.get("shots_done", 0)
                    task.created_at = data.get("created_at")
                    task.completed_at = data.get("completed_at")
                    task.final_video_path = data.get("final_video_path")
                    task.merkle_root = data.get("merkle_root")
                    task.lock_credential_id = data.get("lock_credential_id")
                    self.tasks[task_id] = task
                    loaded += 1
            except Exception as e:
                log.error(f"加载任务失败 [{state_file.name}]: {e}")
        if loaded:
            log.info(f"从磁盘加载 {loaded} 个历史任务")
