"""事件总线 - 阶段间解耦通信"""
import asyncio
from collections import defaultdict
from .logging_setup import get_logger

log = get_logger("event_bus")


class EventBus:
    """异步事件总线"""

    def __init__(self):
        self._subscribers = defaultdict(list)

    def subscribe(self, event_type, handler):
        """订阅事件"""
        self._subscribers[event_type].append(handler)
        log.debug(f"订阅事件: {event_type} (当前{len(self._subscribers[event_type])}个订阅者)")

    def unsubscribe(self, event_type, handler):
        """取消订阅"""
        if handler in self._subscribers[event_type]:
            self._subscribers[event_type].remove(handler)

    async def publish(self, event_type, data=None):
        """发布事件"""
        handlers = list(self._subscribers.get(event_type, []))
        log.debug(f"发布事件: {event_type} ( {len(handlers)}个订阅者)")
        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(data)
                else:
                    handler(data)
            except Exception as e:
                log.error(f"事件处理器异常 [{event_type}]: {e}")

    def clear(self):
        """清除所有订阅"""
        self._subscribers.clear()


# 全局事件总线实例
event_bus = EventBus()

# 事件类型常量
EVENTS = {
    "TASK_CREATED": "task.created",
    "TASK_STARTED": "task.started",
    "TASK_COMPLETED": "task.completed",
    "TASK_FAILED": "task.failed",
    "STAGE_STARTED": "stage.started",
    "STAGE_PROGRESS": "stage.progress",
    "STAGE_COMPLETED": "stage.completed",
    "SHOT_STARTED": "shot.started",
    "SHOT_PROGRESS": "shot.progress",
    "SHOT_COMPLETED": "shot.completed",
    "SHOT_FAILED": "shot.failed",
    "SHOT_RERUN": "shot.rerun",
    "QUALITY_CHECK": "quality.check",
    "QUALITY_PASSED": "quality.passed",
    "QUALITY_FAILED": "quality.failed",
    "LOG": "log",
}
