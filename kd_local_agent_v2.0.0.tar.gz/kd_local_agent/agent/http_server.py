"""HTTP预览服务器 - 支持Range请求、CORS、静态文件服务"""
import asyncio
import os
import mimetypes
from pathlib import Path
from urllib.parse import unquote
from .config import Config, OUTPUT_DIR
from .logging_setup import get_logger

log = get_logger("http_server")


class PreviewHTTPServer:
    """HTTP预览服务器 - 支持Range视频流"""

    def __init__(self, output_dir=None):
        self.output_dir = Path(output_dir or OUTPUT_DIR)
        self.server = None

    async def start(self):
        self.server = await asyncio.start_server(
            self.handle_request, Config.HTTP_HOST, Config.HTTP_PORT
        )
        log.info(f"HTTP预览服务启动: http://{Config.HTTP_HOST}:{Config.HTTP_PORT}/preview")

    def stop(self):
        if self.server:
            self.server.close()

    async def handle_request(self, reader, writer):
        try:
            request_line = await reader.readline()
            if not request_line:
                writer.close()
                return

            parts = request_line.decode().split()
            if len(parts) < 2:
                writer.close()
                return

            method, path = parts[0], unquote(parts[1])

            # 读取请求头
            headers = {}
            while True:
                line = await reader.readline()
                if line in (b'\r\n', b'\n', b''):
                    break
                if b':' in line:
                    k, v = line.decode().split(':', 1)
                    headers[k.strip().lower()] = v.strip()

            if method == 'OPTIONS':
                await self._send_cors_preflight(writer)
                return

            if method != 'GET':
                await self._send_error(writer, 405, b'Method Not Allowed')
                return

            # 路由
            if path == '/health':
                await self._send_json(writer, {"status": "ok", "agent": "kd-local-agent v2.0"})
            elif path == '/' or path == '/index.html':
                await self._send_index(writer)
            elif path.startswith('/preview/'):
                await self._serve_file(writer, path, headers)
            elif path.startswith('/api/tasks'):
                await self._serve_task_api(writer, path)
            else:
                await self._send_error(writer, 404, b'Not Found')

        except Exception as e:
            log.error(f"HTTP请求处理异常: {e}")
            try:
                await self._send_error(writer, 500, str(e).encode())
            except:
                pass
        finally:
            try:
                writer.close()
            except:
                pass

    async def _serve_file(self, writer, path, headers):
        """提供文件访问，支持Range请求"""
        rel_path = path[len('/preview/'):]
        file_path = (self.output_dir / rel_path).resolve()

        # 安全检查：路径穿越防护
        if not str(file_path).startswith(str(self.output_dir.resolve())):
            await self._send_error(writer, 403, b'Forbidden')
            return

        if not file_path.exists() or not file_path.is_file():
            await self._send_error(writer, 404, b'File Not Found')
            return

        file_size = file_path.stat().st_size
        content_type = self._guess_content_type(file_path)

        # Range请求处理
        range_header = headers.get('range', '')
        if range_header and range_header.startswith('bytes='):
            try:
                byte_range = range_header[6:].split('-')
                start = int(byte_range[0]) if byte_range[0] else 0
                end = int(byte_range[1]) if len(byte_range) > 1 and byte_range[1] else file_size - 1
                end = min(end, file_size - 1)
                length = end - start + 1

                headers_resp = (
                    f"HTTP/1.1 206 Partial Content\r\n"
                    f"Content-Type: {content_type}\r\n"
                    f"Content-Length: {length}\r\n"
                    f"Content-Range: bytes {start}-{end}/{file_size}\r\n"
                    f"Accept-Ranges: bytes\r\n"
                    f"Access-Control-Allow-Origin: *\r\n"
                    f"Access-Control-Allow-Methods: GET, OPTIONS\r\n"
                    f"Access-Control-Allow-Headers: Range\r\n"
                    f"\r\n"
                )
                writer.write(headers_resp.encode())
                await writer.drain()

                with open(file_path, 'rb') as f:
                    f.seek(start)
                    remaining = length
                    while remaining > 0:
                        chunk = f.read(min(65536, remaining))
                        if not chunk:
                            break
                        writer.write(chunk)
                        await writer.drain()
                        remaining -= len(chunk)
                return
            except (ValueError, IndexError):
                pass  # 无效Range，回退到完整响应

        # 完整响应
        headers_resp = (
            f"HTTP/1.1 200 OK\r\n"
            f"Content-Type: {content_type}\r\n"
            f"Content-Length: {file_size}\r\n"
            f"Accept-Ranges: bytes\r\n"
            f"Access-Control-Allow-Origin: *\r\n"
            f"\r\n"
        )
        writer.write(headers_resp.encode())
        await writer.drain()

        with open(file_path, 'rb') as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                writer.write(chunk)
                await writer.drain()

    async def _serve_task_api(self, writer, path):
        """任务状态API"""
        import json
        from .task_queue import TaskQueue
        # 简化：返回任务列表
        tasks = []
        for task_file in self.output_dir.parent.glob("data/tasks/*.json"):
            try:
                with open(task_file, encoding="utf-8") as f:
                    data = json.load(f)
                tasks.append({
                    "task_id": data.get("task_id"),
                    "title": data.get("title"),
                    "status": data.get("status"),
                    "progress": data.get("overall_progress"),
                })
            except:
                pass
        await self._send_json(writer, {"tasks": tasks, "total": len(tasks)})

    def _guess_content_type(self, file_path):
        ext = file_path.suffix.lower()
        types = {
            '.mp4': 'video/mp4',
            '.webm': 'video/webm',
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.json': 'application/json',
            '.txt': 'text/plain',
            '.html': 'text/html',
            '.srt': 'text/plain',
        }
        return types.get(ext, 'application/octet-stream')

    async def _send_json(self, writer, data):
        import json
        body = json.dumps(data, ensure_ascii=False).encode()
        headers = (
            f"HTTP/1.1 200 OK\r\n"
            f"Content-Type: application/json\r\n"
            f"Content-Length: {len(body)}\r\n"
            f"Access-Control-Allow-Origin: *\r\n"
            f"\r\n"
        )
        writer.write(headers.encode())
        writer.write(body)
        await writer.drain()

    async def _send_error(self, writer, status, body):
        headers = (
            f"HTTP/1.1 {status} Error\r\n"
            f"Content-Type: text/plain\r\n"
            f"Content-Length: {len(body)}\r\n"
            f"Access-Control-Allow-Origin: *\r\n"
            f"\r\n"
        )
        writer.write(headers.encode())
        writer.write(body)
        await writer.drain()

    async def _send_cors_preflight(self, writer):
        headers = (
            "HTTP/1.1 204 No Content\r\n"
            "Access-Control-Allow-Origin: *\r\n"
            "Access-Control-Allow-Methods: GET, OPTIONS\r\n"
            "Access-Control-Allow-Headers: Range, Content-Type\r\n"
            "Access-Control-Max-Age: 86400\r\n"
            "\r\n"
        )
        writer.write(headers.encode())
        await writer.drain()

    async def _send_index(self, writer):
        body = """<!DOCTYPE html><html><head><meta charset="utf-8">
<title>KD Agent Preview v2.0</title></head>
<body style="background:#0a0a12;color:#d4a843;font-family:sans-serif;padding:20px">
<h2>昆仑洞天本地代理 v2.0 - 预览服务</h2>
<p>视频预览: /preview/&lt;task_id&gt;/output.mp4</p>
<p>健康检查: /health</p>
<p>任务列表: /api/tasks</p>
<p style="color:#666;margin-top:30px">支持Range请求 | CORS跨域 | 路径穿越防护</p>
</body></html>""".encode("utf-8")
        headers = (
            f"HTTP/1.1 200 OK\r\n"
            f"Content-Type: text/html\r\n"
            f"Content-Length: {len(body)}\r\n"
            f"Access-Control-Allow-Origin: *\r\n"
            f"\r\n"
        )
        writer.write(headers.encode())
        writer.write(body)
        await writer.drain()
