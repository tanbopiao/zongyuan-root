"""配置管理 - 支持.env文件和环境变量"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
OUTPUT_DIR = BASE_DIR / "output"
DATA_DIR = BASE_DIR / "data"
TASKS_DIR = DATA_DIR / "tasks"
OUTPUT_DIR.mkdir(exist_ok=True)
DATA_DIR.mkdir(exist_ok=True)
TASKS_DIR.mkdir(exist_ok=True)


def _load_dotenv():
    env_file = BASE_DIR / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.strip().strip('"').strip("'")
        if k not in os.environ:
            os.environ[k] = v


_load_dotenv()


class Config:
    # WebSocket
    WS_HOST = os.getenv("WS_HOST", "127.0.0.1")
    WS_PORT = int(os.getenv("WS_PORT", "8765"))

    # HTTP预览
    HTTP_HOST = os.getenv("HTTP_HOST", "127.0.0.1")
    HTTP_PORT = int(os.getenv("HTTP_PORT", "8766"))

    # 火山方舟
    ARK_API_KEY = os.getenv("ARK_API_KEY", "")
    ARK_API_BASE = os.getenv("ARK_API_BASE", "https://ark.cn-beijing.volces.com/api/v3")
    SEEDANCE_EP = os.getenv("SEEDANCE_EP", "")
    SEEDREAM_EP = os.getenv("SEEDREAM_EP", "")

    # 运行模式
    RUN_MODE = os.getenv("RUN_MODE", "mock")
    if ARK_API_KEY and SEEDANCE_EP:
        RUN_MODE = "real"

    # 流水线
    DEFAULT_DURATION = int(os.getenv("DEFAULT_DURATION", "10"))
    DEFAULT_RESOLUTION = os.getenv("DEFAULT_RESOLUTION", "1080p")
    DEFAULT_RATIO = os.getenv("DEFAULT_RATIO", "9:16")
    SHOTS_PER_TASK = int(os.getenv("SHOTS_PER_TASK", "4"))
    MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))
    MAX_CONCURRENT_TASKS = int(os.getenv("MAX_CONCURRENT_TASKS", "1"))

    # 质量门禁
    QUALITY_GATE_ENABLED = os.getenv("QUALITY_GATE", "true").lower() == "true"

    # 角色库
    CHARACTERS = {
        "taiyin": {"name": "太阴月神", "style": "黑金灵纹、肃穆神性、纯净女相"},
        "jiutian": {"name": "九天玄女", "style": "衣袂飘逸金光内敛，战争形态红裙凤冠"},
        "xiwangmu": {"name": "西王母", "style": "雍容华贵、头戴玉胜、昆仑主神"},
        "hongqun": {"name": "红裙九尾狐", "style": "红裙飘逸、九尾灵动、妖媚神性"},
    }

    @classmethod
    def summary(cls):
        return {
            "agent_id": __import__("agent").__agent_id__,
            "version": __import__("agent").__version__,
            "mode": cls.RUN_MODE,
            "ws_url": f"ws://{cls.WS_HOST}:{cls.WS_PORT}/ws",
            "http_preview": f"http://{cls.HTTP_HOST}:{cls.HTTP_PORT}/preview",
            "ark_configured": bool(cls.ARK_API_KEY),
            "max_retries": cls.MAX_RETRIES,
            "quality_gate": cls.QUALITY_GATE_ENABLED,
        }
