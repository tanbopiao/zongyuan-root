@echo off
chcp 65001 >nul
title 昆仑洞天本地自治代理 v2.0
echo ==================================================
echo   昆仑洞天本地自治代理 v2.0
echo ==================================================
echo.

python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未检测到Python，请先安装Python 3.8+
    pause
    exit /b 1
)

python -c "import websockets" >nul 2>&1
if errorlevel 1 (
    echo [提示] 正在安装依赖...
    pip install websockets
)

echo [启动] 正在启动本地代理...
echo [提示] 按 Ctrl+C 停止代理
echo.
python start_agent.py

pause
