# 昆仑洞天本地自治代理 KD-LOCAL-AGENT v2.0

火斗云智AIOS · 昆仑洞天短剧生产工作台的本地执行代理。

## v2.0 架构升级

- **插件化架构**：7个独立阶段插件，可单独替换
- **生成器抽象**：BaseGenerator基类，MockGenerator/ArkGenerator可插拔
- **事件驱动**：EventBus事件总线，阶段间完全解耦
- **任务队列**：异步任务队列 + JSON持久化，重启不丢失
- **质量门禁**：QM1-QM5五项自动质量检查
- **Range视频流**：HTTP服务支持Range请求，视频可拖动进度条
- **结构化日志**：logging模块，控制台+文件双输出
- **CORS跨域**：完整的跨域支持

## 快速开始

```bash
pip install -r requirements.txt
python3 start_agent.py              # 前台运行
python3 start_agent.py --daemon     # 后台运行
python3 start_agent.py --status     # 查看状态
python3 start_agent.py --stop       # 停止
```

然后打开 https://huodouai.com/kunlun/workbench.html

## 目录结构

```
kd_local_agent/
├── start_agent.py / .bat      # 启动入口
├── requirements.txt
├── .env.example
├── README.md
├── agent/
│   ├── config.py              # 配置管理
│   ├── logging_setup.py       # 结构化日志
│   ├── event_bus.py           # 事件总线
│   ├── task_queue.py          # 任务队列+持久化
│   ├── quality_gate.py        # 质量门禁引擎
│   ├── pipeline.py            # 流水线调度器
│   ├── ws_server.py           # WebSocket服务器
│   ├── http_server.py         # HTTP预览服务(Range支持)
│   ├── generators/
│   │   ├── base.py            # 生成器基类
│   │   ├── mock.py            # ffmpeg模拟生成器
│   │   └── ark.py             # 火山方舟生成器
│   └── stages/
│       ├── base.py            # 阶段基类
│       └── impl.py            # 7个阶段实现
├── data/tasks/                # 任务状态持久化
└── output/                    # 视频输出
```

## 质量门禁 QM1-QM5

| 编号 | 检查项 | 说明 |
|---|---|---|
| QM1 | 角色一致性 | 所有镜头角色信息完整 |
| QM2 | 风格一致性 | 生成器风格统一 |
| QM3 | 视频质量 | 输出文件大小合理 |
| QM4 | 音频同步 | 所有镜头视频文件完整 |
| QM5 | 溯源水印 | Ω₀⊂⊙∞⊂Ω 水印已嵌入 |

## HTTP API

| 路径 | 说明 |
|---|---|
| `/health` | 健康检查 |
| `/preview/<task_id>/<file>` | 视频/图片文件访问（支持Range） |
| `/api/tasks` | 任务列表 |

## WebSocket协议

见 README 协议文档或 workbench 前端代码。

## 溯源

- DID: DID-BR-000002
- 溯源标识: Ω₀⊂⊙∞⊂Ω
- 版本: v2.0.0
