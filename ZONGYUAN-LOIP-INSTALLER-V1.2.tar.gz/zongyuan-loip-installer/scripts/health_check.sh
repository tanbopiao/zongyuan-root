#!/bin/bash
# ZONGYUAN-ROOT 健康检查脚本
echo "============================================"
echo "  ZONGYUAN-ROOT 健康检查"
echo "============================================"
echo ""

PASS=0
FAIL=0
WARNINGS=0

check_endpoint() {
    local name=$1
    local url=$2
    local code=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 "$url" 2>/dev/null)
    if [ "$code" = "200" ]; then
        echo -e "  [\033[32mPASS\033[0m] $name → HTTP $code"
        PASS=$((PASS+1))
    else
        echo -e "  [\033[31mFAIL\033[0m] $name → HTTP $code"
        FAIL=$((FAIL+1))
    fi
}

echo "[1] 服务端口检查..."
check_endpoint "Ω-Brainμ (8000)" "http://127.0.0.1:8000/health"
check_endpoint "LOIP API (8001)" "http://127.0.0.1:8001/api/v1/status"
check_endpoint "ANCE (8002)" "http://127.0.0.1:8002/ance/health"
check_endpoint "Vector DB (8003)" "http://127.0.0.1:8003/vector/api/v1/stats"
check_endpoint "Monitor (8004)" "http://127.0.0.1:8004/monitor/"
check_endpoint "政务AI (8005)" "http://127.0.0.1:8005/gov-api/health"
check_endpoint "锚定服务 (8006)" "http://127.0.0.1:8006/anchor/health"

echo ""
echo "[2] 系统资源检查..."
DISK=$(df -h / | tail -1 | awk '{print $5}' | tr -d '%')
MEM=$(free | grep Mem | awk '{printf "%.0f", $3/$2*100}')
echo "  磁盘使用: ${DISK}%"
echo "  内存使用: ${MEM}%"
if [ "$DISK" -gt 80 ]; then
    echo -e "  [\033[33mWARN\033[0m] 磁盘使用率超过80%"
    WARNINGS=$((WARNINGS+1))
fi
if [ "$MEM" -gt 85 ]; then
    echo -e "  [\033[33mWARN\033[0m] 内存使用率超过85%"
    WARNINGS=$((WARNINGS+1))
fi

echo ""
echo "[3] 内核状态检查..."
if [ -f /opt/ZONGYUAN-ROOT/kernel_state.json ]; then
    echo -e "  [\033[32mPASS\033[0m] kernel_state.json 存在"
    PASS=$((PASS+1))
else
    echo -e "  [\033[31mFAIL\033[0m] kernel_state.json 不存在"
    FAIL=$((FAIL+1))
fi
if [ -f /opt/ZONGYUAN-ROOT/task_registry.json ]; then
    echo -e "  [\033[32mPASS\033[0m] task_registry.json 存在"
    PASS=$((PASS+1))
else
    echo -e "  [\033[31mFAIL\033[0m] task_registry.json 不存在"
    FAIL=$((FAIL+1))
fi

echo ""
echo "============================================"
echo "  检查结果: $PASS 通过 / $FAIL 失败 / $WARNINGS 警告"
echo "============================================"
if [ "$FAIL" -eq 0 ]; then
    echo -e "  \033[32m系统健康，所有服务正常运行\033[0m"
else
    echo -e "  \033[31m存在故障，请运行 manage.sh status 查看详情\033[0m"
fi
echo ""
echo "Ω₀⊂⊙∞⊂Ω · ZONGYUAN-ROOT"
