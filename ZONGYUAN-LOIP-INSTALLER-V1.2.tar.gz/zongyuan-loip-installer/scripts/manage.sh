#!/bin/bash
# ZONGYUAN-ROOT 服务管理脚本
INSTALL_DIR="/opt/ZONGYUAN-ROOT"
SERVICES="zongyuan-omega-brain zongyuan-loip zongyuan-ance zongyuan-vector zongyuan-monitor zongyuan-gov-ai zongyuan-anchor"

case "$1" in
    start)
        echo "启动所有服务..."
        systemctl start $SERVICES
        sleep 2
        $0 status
        ;;
    stop)
        echo "停止所有服务..."
        systemctl stop $SERVICES
        echo "已停止"
        ;;
    restart)
        echo "重启所有服务..."
        systemctl restart $SERVICES
        sleep 2
        $0 status
        ;;
    status)
        echo "============================================"
        echo "  ZONGYUAN-ROOT 服务状态"
        echo "============================================"
        printf "%-20s %-10s %-8s\n" "服务" "状态" "端口"
        echo "--------------------------------------------"
        declare -A PORTS=(
            [zongyuan-omega-brain]=8000
            [zongyuan-loip]=8001
            [zongyuan-ance]=8002
            [zongyuan-vector]=8003
            [zongyuan-monitor]=8004
            [zongyuan-gov-ai]=8005
            [zongyuan-anchor]=8006
        )
        for svc in $SERVICES; do
            status=$(systemctl is-active $svc 2>/dev/null)
            port=${PORTS[$svc]}
            if [ "$status" = "active" ]; then
                printf "%-20s \033[32m%-10s\033[0m %-8s\n" "$svc" "$status" "$port"
            else
                printf "%-20s \033[31m%-10s\033[0m %-8s\n" "$svc" "$status" "$port"
            fi
        done
        echo "============================================"
        running=$(echo "$SERVICES" | wc -w)
        active=$(systemctl is-active $SERVICES 2>/dev/null | grep -c active)
        echo "运行中: $active / $running"
        ;;
    logs)
        if [ -z "$2" ]; then
            echo "用法: $0 logs <服务名>"
            echo "可用: omega-brain loip ance vector monitor gov-ai anchor"
            exit 1
        fi
        journalctl -u zongyuan-$2 -f --lines 50
        ;;
    *)
        echo "ZONGYUAN-ROOT 服务管理"
        echo ""
        echo "用法: $0 {start|stop|restart|status|logs <服务名>}"
        echo ""
        echo "  start    - 启动所有服务"
        echo "  stop     - 停止所有服务"
        echo "  restart  - 重启所有服务"
        echo "  status   - 查看服务状态"
        echo "  logs     - 查看服务日志"
        ;;
esac
