#!/bin/bash
echo "正在卸载 ZONGYUAN-ROOT..."
systemctl stop zongyuan-omega-brain zongyuan-loip zongyuan-ance zongyuan-vector zongyuan-monitor zongyuan-gov-ai zongyuan-anchor 2>/dev/null
systemctl disable zongyuan-omega-brain zongyuan-loip zongyuan-ance zongyuan-vector zongyuan-monitor zongyuan-gov-ai zongyuan-anchor 2>/dev/null
rm -f /etc/systemd/system/zongyuan-*.service /etc/systemd/system/zongyuan.target
systemctl daemon-reload
echo "服务已移除"
read -p "是否删除 /opt/ZONGYUAN-ROOT 目录？(y/N): " confirm
if [ "$confirm" = "y" ] || [ "$confirm" = "Y" ]; then
    rm -rf /opt/ZONGYUAN-ROOT
    echo "目录已删除"
fi
echo "卸载完成"
