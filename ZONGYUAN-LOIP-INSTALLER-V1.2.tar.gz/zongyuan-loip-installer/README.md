# ZONGYUAN-ROOT LOIP 一键部署包 V1.0

> 逻辑本体智能协议 · 自治内核系统 · 私有化部署交付包

## 快速开始

```bash
# 1. 上传到你的服务器
scp zongyuan-loip-installer-v1.0.tar.gz root@your-server:/tmp/

# 2. 解压并安装
ssh root@your-server
cd /tmp && tar xzf zongyuan-loip-installer-v1.0.tar.gz
cd zongyuan-loip-installer && bash install.sh

# 3. 配置API密钥
vi /opt/ZONGYUAN-ROOT/.env

# 4. 健康检查
bash /opt/ZONGYUAN-ROOT/scripts/health_check.sh
```

## 系统要求

| 项目 | 最低要求 | 推荐配置 |
|------|---------|---------|
| CPU | 1核 | 2核+ |
| 内存 | 1GB | 2GB+ |
| 磁盘 | 10GB | 40GB SSD |
| 系统 | CentOS 9 / Ubuntu 22.04 | OpenCloudOS 9 |
| Python | 3.9+ | 3.11 |
| 网络 | 可访问外网 | 独立IP+域名 |

## 服务架构

```
                    Nginx (80/443)
                         │
        ┌────────┬───────┼───────┬────────┐
        ▼        ▼       ▼       ▼        ▼
    Ω-Brainμ  LOIP    ANCE   VectorDB  Monitor
    (8000)    (8001)  (8002)  (8003)   (8004)
        │        │       │       │        │
        └────────┴───┬───┴───────┴────────┘
                     ▼
              政务AI引擎 (8005)
                     │
                     ▼
              内核锚定服务 (8006)
                     │
                     ▼
              Redis / 本地存储
```

## 服务说明

| 端口 | 服务 | 功能 | 外部路径 |
|------|------|------|---------|
| 8000 | Ω-Brainμ | 真值记忆中枢 | /health |
| 8001 | LOIP API | 逻辑本体智能协议 | /api/ |
| 8002 | ANCE | AI云运维引擎 | /ance/ |
| 8003 | Vector DB | 向量知识库 | /vector/ |
| 8004 | Monitor | 监控面板 | /monitor/ |
| 8005 | 政务AI | 合规引擎+RAG | /gov-api/ |
| 8006 | Anchor | 内核状态锚定 | /anchor/ |

## 管理命令

```bash
# 查看所有服务状态
bash /opt/ZONGYUAN-ROOT/scripts/manage.sh status

# 启动/停止/重启
bash /opt/ZONGYUAN-ROOT/scripts/manage.sh start
bash /opt/ZONGYUAN-ROOT/scripts/manage.sh stop
bash /opt/ZONGYUAN-ROOT/scripts/manage.sh restart

# 查看单个服务日志
bash /opt/ZONGYUAN-ROOT/scripts/manage.sh logs loip

# 健康检查
bash /opt/ZONGYUAN-ROOT/scripts/health_check.sh

# 卸载
bash /opt/ZONGYUAN-ROOT/scripts/uninstall.sh
```

## API密钥配置

编辑 `/opt/ZONGYUAN-ROOT/.env`：

```bash
# 豆包方舟API（必需，用于AI能力）
DOUBAO_API_KEY=你的密钥
DOUBAO_MODEL=doubao-seed-2-0-lite-260215
DOUBAO_ENDPOINT_ID=你的接入点ID

# 智普API（可选）
ZHIPU_API_KEY=你的密钥

# 管理员密码
ADMIN_PASSWORD=设置一个强密码
```

## Nginx配置

参考 `nginx/zongyuan-nginx.conf.template`，替换域名和证书路径后：

```bash
cp nginx/zongyuan-nginx.conf.template /etc/nginx/conf.d/zongyuan.conf
nginx -t && nginx -s reload
```

## 核心真值

本系统基于三态秩序化智能体系：
- **逻辑态**：结构秩序，治混乱
- **信息态**：内容真值，治漂移
- **能量态**：动态演化，治停滞

稳态公式：S = L(x) ∩ I(x) ∩ E(x)

## 技术支持

- 微信：17688762862
- 官网：www.huodouai.com
- 个人终身版：¥199
- 企业终身版：¥1999

Ω₀⊂⊙∞⊂Ω · ZONGYUAN-ROOT · DID-BR-000002 · Ω-TAN-7-001
