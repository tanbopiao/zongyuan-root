"""
内核状态锚定服务
端口: 8006
功能：任务开始前锚定内核状态，防止重复劳动和任务冲突
"""
import os, json, time, hashlib
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List

app = FastAPI(title="内核状态锚定服务", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

STATE_FILE = "/opt/ZONGYUAN-ROOT/kernel_state.json"
REGISTRY_FILE = "/opt/ZONGYUAN-ROOT/task_registry.json"

def load_json(path):
    try:
        with open(path) as f:
            return json.load(f)
    except:
        return {}

def save_json(path, data):
    with open(path, 'w') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

class TaskCheckRequest(BaseModel):
    task_name: str
    task_description: Optional[str] = ""
    target_port: Optional[int] = None
    target_route: Optional[str] = ""

class TaskRegisterRequest(BaseModel):
    task_name: str
    description: str
    protocol_version: str
    artifacts: List[str] = []
    hash: str = ""

@app.get("/health")
def health():
    return {"status": "ok", "service": "kernel-anchor", "version": "1.0.0"}

@app.get("/api/v1/anchor/state")
def get_state():
    """获取内核当前完整状态快照"""
    state = load_json(STATE_FILE)
    if not state:
        return {"error": "内核状态文件不存在", "state": {}}
    return {
        "kernel_id": state.get("kernel_id"),
        "did": state.get("did"),
        "last_updated": state.get("last_updated"),
        "server": state.get("server"),
        "services_running": len([s for s in state.get("services", []) if s.get("status") == "running"]),
        "services_total": len(state.get("services", [])),
        "services": state.get("services"),
        "api_endpoints": state.get("api_endpoints"),
        "nginx_routes": state.get("nginx_routes"),
        "assets": state.get("assets"),
        "security": state.get("security"),
        "known_issues": state.get("known_issues"),
        "todo_backlog": state.get("todo_backlog"),
        "latest_protocol": state.get("latest_protocol"),
        "registry_version": state.get("registry_version")
    }

@app.get("/api/v1/anchor/tasks")
def get_tasks(limit: int = 20):
    """获取任务谱系"""
    reg = load_json(REGISTRY_FILE)
    tasks = reg.get("tasks", [])
    return {
        "total": reg.get("total_tasks", len(tasks)),
        "recent_tasks": tasks[-limit:],
        "port_allocation": reg.get("port_allocation"),
        "conflict_rules": reg.get("conflict_rules")
    }

@app.post("/api/v1/anchor/check")
def check_task(req: TaskCheckRequest):
    """
    任务开始前冲突检测：
    1. 检测是否与已有任务重复
    2. 检测端口冲突
    3. 检测路由冲突
    4. 返回建议（增量执行 or 新建）
    """
    state = load_json(STATE_FILE)
    reg = load_json(REGISTRY_FILE)
    tasks = reg.get("tasks", [])
    
    issues = []
    suggestions = []
    
    # 1. 重复任务检测（关键词匹配）
    keywords = set(req.task_name.lower().split())
    duplicate_tasks = []
    for t in tasks:
        if t.get("status") == "completed":
            task_words = set(t.get("name", "").lower().split())
            overlap = keywords & task_words
            if len(overlap) >= 2:
                duplicate_tasks.append({"task_id": t["task_id"], "name": t["name"], "overlap": list(overlap)})
    
    if duplicate_tasks:
        issues.append({
            "level": "P1",
            "type": "potential_duplicate",
            "message": f"检测到{len(duplicate_tasks)}个可能重复的已完成任务",
            "details": duplicate_tasks,
            "suggestion": "建议先读取已有任务产物，采用增量优化而非从零构建"
        })
    
    # 2. 端口冲突检测
    if req.target_port:
        used_ports = [s["port"] for s in state.get("services", []) if s.get("status") == "running"]
        if req.target_port in used_ports:
            svc = next((s for s in state["services"] if s["port"] == req.target_port), {})
            issues.append({
                "level": "P0",
                "type": "port_conflict",
                "message": f"端口{req.target_port}已被占用: {svc.get('name', '未知')}",
                "suggestion": f"使用可用端口: {reg.get('port_allocation', {}).get('next_available', [])}"
            })
    
    # 3. 路由冲突检测
    if req.target_route:
        routes = state.get("nginx_routes", {})
        for existing_route in routes:
            if req.target_route.startswith(existing_route) or existing_route.startswith(req.target_route):
                issues.append({
                    "level": "P0",
                    "type": "route_conflict",
                    "message": f"路由{req.target_route}与已有路由{existing_route}冲突",
                    "suggestion": "使用不同的路由前缀"
                })
    
    # 4. 已知问题提醒
    pending_issues = [i for i in state.get("known_issues", []) if i.get("status") == "pending"]
    if pending_issues:
        suggestions.append({
            "type": "pending_issues",
            "message": f"当前有{len(pending_issues)}个待解决问题",
            "details": pending_issues
        })
    
    # 5. 待办提醒
    backlog = state.get("todo_backlog", [])
    if backlog:
        suggestions.append({
            "type": "backlog",
            "message": "当前待办列表",
            "details": backlog
        })
    
    can_proceed = not any(i["level"] == "P0" for i in issues)
    
    return {
        "task_name": req.task_name,
        "can_proceed": can_proceed,
        "issues": issues,
        "suggestions": suggestions,
        "current_state_summary": {
            "services_running": len([s for s in state.get("services", []) if s.get("status") == "running"]),
            "latest_protocol": state.get("latest_protocol"),
            "vector_docs": state.get("assets", {}).get("vector_docs", 0),
            "known_issues": len(pending_issues)
        },
        "anchor_time": time.strftime("%Y-%m-%d %H:%M:%S")
    }

@app.post("/api/v1/anchor/register")
def register_task(req: TaskRegisterRequest):
    """任务完成后注册到任务谱系"""
    reg = load_json(REGISTRY_FILE)
    tasks = reg.get("tasks", [])
    
    new_id = f"TASK-{len(tasks)+1:03d}"
    task_hash = req.hash or hashlib.sha256(f"{req.task_name}{time.time()}".encode()).hexdigest()[:16]
    
    new_task = {
        "task_id": new_id,
        "name": req.task_name,
        "date": time.strftime("%Y-%m-%d"),
        "status": "completed",
        "protocol": req.protocol_version,
        "artifacts": req.artifacts,
        "hash": task_hash,
        "description": req.description
    }
    tasks.append(new_task)
    reg["tasks"] = tasks
    reg["total_tasks"] = len(tasks)
    save_json(REGISTRY_FILE, reg)
    
    return {"status": "registered", "task_id": new_id, "hash": task_hash, "total_tasks": len(tasks)}

@app.post("/api/v1/anchor/update-state")
def update_state(state_update: dict):
    """更新内核状态快照（任务完成后调用）"""
    state = load_json(STATE_FILE)
    if not state:
        state = {}
    state.update(state_update)
    state["last_updated"] = time.strftime("%Y-%m-%dT%H:%M:%S+08:00")
    save_json(STATE_FILE, state)
    return {"status": "updated", "last_updated": state["last_updated"]}

@app.get("/api/v1/anchor/summary")
def get_summary():
    """快速摘要（任务开始前一键获取）"""
    state = load_json(STATE_FILE)
    reg = load_json(REGISTRY_FILE)
    return {
        "kernel": state.get("kernel_id"),
        "latest_protocol": state.get("latest_protocol"),
        "services": f"{len([s for s in state.get('services',[]) if s.get('status')=='running'])}/{len(state.get('services',[]))} 运行中",
        "vector_docs": state.get("assets", {}).get("vector_docs"),
        "total_tasks": reg.get("total_tasks"),
        "pending_issues": len([i for i in state.get("known_issues",[]) if i.get("status")=="pending"]),
        "next_ports": reg.get("port_allocation", {}).get("next_available", []),
        "access_urls": state.get("api_endpoints", {})
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8006, workers=1)
