#!/bin/bash
# ZONGYUAN-ROOT LOIP 一键部署脚本 V1.0
# 适用：OpenCloudOS 9 / CentOS 9 / Ubuntu 22.04
set -e

INSTALL_DIR="/opt/ZONGYUAN-ROOT"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "============================================"
echo "  ZONGYUAN-ROOT LOIP 一键部署 V1.0"
echo "  逻辑本体智能协议 · 自治内核系统"
echo "============================================"
echo ""

# 1. 系统检查
echo "[1/7] 系统环境检查..."
if [ "$EUID" -ne 0 ]; then
    echo "错误：请使用 root 用户执行"
    exit 1
fi

PYTHON_OK=$(python3 -c "import sys; print('ok' if sys.version_info >= (3,9) else 'fail')" 2>/dev/null || echo "fail")
if [ "$PYTHON_OK" != "ok" ]; then
    echo "错误：需要 Python 3.9+"
    exit 1
fi
echo "  Python: $(python3 --version)"

# 2. 安装依赖
echo ""
echo "[2/7] 安装系统依赖..."
if command -v dnf &> /dev/null; then
    dnf install -y python3-pip python3-devel redis nginx git 2>/dev/null || true
elif command -v apt &> /dev/null; then
    apt update -qq && apt install -y python3-pip python3-dev redis-server nginx git 2>/dev/null || true
fi
echo "  系统依赖完成"

# 3. 安装Python依赖
echo ""
echo "[3/7] 安装Python依赖..."
pip3 install fastapi uvicorn flask requests redis chromadb 2>/dev/null || pip3 install fastapi uvicorn flask requests redis 2>/dev/null || true
echo "  Python依赖完成"

# 4. 部署代码
echo ""
echo "[4/7] 部署服务代码..."
mkdir -p "$INSTALL_DIR"
cp -r "$SCRIPT_DIR/omega_brain" "$INSTALL_DIR/" 2>/dev/null || true
cp -r "$SCRIPT_DIR/loip-sdk" "$INSTALL_DIR/" 2>/dev/null || true
cp -r "$SCRIPT_DIR/ai-native-ops" "$INSTALL_DIR/" 2>/dev/null || true
cp -r "$SCRIPT_DIR/gov-ai" "$INSTALL_DIR/" 2>/dev/null || true
cp -r "$SCRIPT_DIR/truth_architecture" "$INSTALL_DIR/" 2>/dev/null || true
cp "$SCRIPT_DIR/kernel_anchor_api.py" "$INSTALL_DIR/" 2>/dev/null || true
cp "$SCRIPT_DIR/kernel_state.json" "$INSTALL_DIR/" 2>/dev/null || true
cp "$SCRIPT_DIR/task_registry.json" "$INSTALL_DIR/" 2>/dev/null || true
mkdir -p "$INSTALL_DIR/vector_db" "$INSTALL_DIR/autonomous_kernel_protocol" "$INSTALL_DIR/logs"
echo "  代码部署到 $INSTALL_DIR"

# 5. 配置环境
echo ""
echo "[5/7] 配置环境..."
if [ ! -f "$INSTALL_DIR/.env" ]; then
    cp "$SCRIPT_DIR/config/.env.template" "$INSTALL_DIR/.env"
    echo "  已创建 .env 配置文件（请编辑填入API密钥）"
fi

# 6. 安装systemd服务
echo ""
echo "[6/7] 配置systemd服务..."
cp "$SCRIPT_DIR/systemd/"*.service /etc/systemd/system/ 2>/dev/null || true
cp "$SCRIPT_DIR/systemd/zongyuan.target" /etc/systemd/system/ 2>/dev/null || true
systemctl daemon-reload
systemctl enable zongyuan-omega-brain zongyuan-loip zongyuan-ance zongyuan-vector zongyuan-monitor zongyuan-gov-ai zongyuan-anchor 2>/dev/null || true
echo "  7个服务已注册开机自启"

# 7. 启动服务
echo ""
echo "[7/7] 启动所有服务..."
systemctl start redis 2>/dev/null || true
systemctl start zongyuan-omega-brain zongyuan-loip zongyuan-ance zongyuan-vector zongyuan-monitor zongyuan-gov-ai zongyuan-anchor 2>/dev/null || true
sleep 3

echo ""
echo "============================================"
echo "  部署完成！"
echo "============================================"
echo ""
echo "  安装目录: $INSTALL_DIR"
echo "  管理命令: bash $INSTALL_DIR/scripts/manage.sh status"
echo "  健康检查: bash $INSTALL_DIR/scripts/health_check.sh"
echo ""
echo "  服务端口:"
echo "    8000 - Ω-Brainμ 真值中枢"
echo "    8001 - LOIP 协议API"
echo "    8002 - ANCE 云运维引擎"
echo "    8003 - Vector DB 向量库"
echo "    8004 - Monitor 监控面板"
echo "    8005 - 政务AI合规引擎"
echo "    8006 - 内核锚定服务"
echo ""
echo "  下一步:"
echo "    1. 编辑 $INSTALL_DIR/.env 填入API密钥"
echo "    2. 配置Nginx反向代理（参考 nginx/ 目录模板）"
echo "    3. 运行健康检查验证全部服务"
echo ""
echo "  Ω₀⊂⊙∞⊂Ω · ZONGYUAN-ROOT · DID-BR-000002"
