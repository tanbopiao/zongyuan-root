#!/usr/bin/env bash
# ============================================================
# 元极恒一 · 种子真值 CI 一键流水线
# 链路：快照备份 → 批量提取 → 漂移校验 → 收敛判定 → 基线归档
# 用法：bash /home/user/ZONGYUAN-ROOT/src/seed_ci.sh
# 判定铁律：L0 无漂移 → 归档；L0 有漂移 → 回滚快照、禁止更新基线
# ============================================================
set -e
ZR=/home/user/ZONGYUAN-ROOT
SRC=$ZR/src
PERSIST=$ZR/persist/seed_truth
LOG=$ZR/logs/seed.log
TS=$(date +%Y%m%d_%H%M%S)

echo "═══ 元极恒一 种子真值 CI ｜ $TS ═══"

# 0) 资源/环境预检
echo "[0/5] 环境预检"
python3 -c "import torch,transformers,bitsandbytes,psutil,yaml,numpy" 2>/dev/null \
  && echo "  依赖 OK" || { echo "  ❌ 依赖缺失: 需 torch/transformers/bitsandbytes/psutil/yaml/numpy"; exit 2; }
[ -d "$ZR/weights/yuanjihengyi_full_v1" ] && [ -n "$(ls -A $ZR/weights/yuanjihengyi_full_v1 2>/dev/null)" ] \
  && echo "  权重 OK" || { echo "  ⚠️ 权重目录为空: $ZR/weights/yuanjihengyi_full_v1（需就位才可运行）"; exit 3; }

# 1) 快照备份旧基线
echo "[1/5] 备份旧基线"
python3 $SRC/seed_snapshot.py

# 2) 批量提取种子真值
echo "[2/5] 批量提取种子（seed=42 / temp=0.0 / greedy）"
python3 $SRC/seed_extractor.py

# 3) 漂移校验 + 收敛判定
echo "[3/5] 漂移校验与收敛判定"
python3 $SRC/seed_verify.py && VERIFY_RC=0 || VERIFY_RC=1

# 4) 结果判定
echo "[4/5] 结果判定"
if [ "$VERIFY_RC" -eq 0 ]; then
  echo "  ✅ L0 无漂移 → 新基线有效"
  echo "  → manifest.seed_version 更新，基线可归档"
else
  echo "  ❌ L0 存在漂移 → 全域收敛失效"
  echo "  → 丢弃本次采集，回滚上一版快照"
  LATEST_BACKUP=$(ls -d $ZR/backup/seed_truth/seed_baseline_* 2>/dev/null | tail -1)
  if [ -n "$LATEST_BACKUP" ]; then
    rm -rf $PERSIST
    cp -r "$LATEST_BACKUP" "$PERSIST"
    echo "  → 已回滚至: $LATEST_BACKUP"
  fi
  exit 1
fi

# 5) 审计留痕
echo "[5/5] 审计留痕"
AUDIT=$ZR/logs/seed-ci-$TS.json
echo "{\"event\":\"seed_ci\",\"ts\":\"$TS\",\"verdict\":\"$([ $VERIFY_RC -eq 0 ] && echo CONVERGED || echo ROLLED_BACK)\",\"source\":\"$SRC\"}" > "$AUDIT"
echo "  回执: $AUDIT"
echo "═══ CI 完成（判定: $([ $VERIFY_RC -eq 0 ] && echo 收敛归档 || echo 回滚)）═══"
exit $VERIFY_RC
