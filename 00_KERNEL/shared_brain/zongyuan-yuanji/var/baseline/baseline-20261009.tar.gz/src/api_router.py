"""
API路由引擎 - 多模型自动路由
- 统一入口，后端自动选最优模型
- 失败自动降级
- 按速度/成本/可用性路由
"""
import requests, time, json

# 模型池
MODELS = {
    "doubao": {
        "url": "https://ark.cn-beijing.volces.com/api/v3/chat/completions",
        "key": "ark-800a6f28-5c7f-4ec5-9766-4b7da1a58f1d-50a70",
        "model": "ep-20260925170233-g4f7w",
        "priority": 1,  # 最高优先级
        "type": "main"
    },
    "deepseek-pro": {
        "url": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
        "key": "sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb",
        "model": "deepseek-v4-pro-0813",
        "priority": 2,
        "type": "fallback"
    },
    "deepseek-flash": {
        "url": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
        "key": "sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb",
        "model": "deepseek-v4-flash-0731",
        "priority": 3,
        "type": "fast"
    },
    "glm": {
        "url": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
        "key": "sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb",
        "model": "glm-5.3",
        "priority": 4,
        "type": "fallback"
    },
    "ms-deepseek-flash": {
        "url": "https://api-inference.modelscope.cn/v1/chat/completions",
        "key": "ms-673547d6-508b-4242-a862-85de112a3ce7",
        "model": "deepseek-ai/DeepSeek-V4.1-Flash",
        "priority": 5,
        "type": "free"
    }
}

def route_chat(messages, max_tokens=200, strategy="auto"):
    """
    路由对话请求
    strategy: auto(自动选) / fast(要快) / quality(要好) / fallback(备用)
    """
    # 按优先级排序
    sorted_models = sorted(MODELS.items(), key=lambda x: x[1]["priority"])
    
    if strategy == "fast":
        # 只要快，先试flash
        sorted_models.sort(key=lambda x: 0 if x[1]["type"]=="fast" else 1)
    elif strategy == "quality":
        # 只要好，先试pro
        sorted_models.sort(key=lambda x: 0 if "pro" in x[0] else 1)
    
    errors = []
    for name, cfg in sorted_models:
        try:
            t0 = time.time()
            headers = {
                "Authorization": f"Bearer {cfg['key']}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": cfg["model"],
                "messages": messages,
                "max_tokens": max_tokens
            }
            r = requests.post(cfg["url"], json=payload, headers=headers, timeout=30)
            elapsed = time.time() - t0
            
            if r.status_code == 200:
                data = r.json()
                content = data["choices"][0]["message"]["content"]
                return {
                    "content": content,
                    "model_used": name,
                    "latency": round(elapsed, 2),
                    "tokens": data.get("usage", {}).get("total_tokens", 0)
                }
            else:
                errors.append(f"{name}: HTTP {r.status_code}")
        except Exception as e:
            errors.append(f"{name}: {str(e)[:100]}")
    
    # 所有外部API都失败 → 本地兜底
    try:
        import subprocess, urllib.request
        # 检查llama是否在跑
        try:
            requests.get("http://127.0.0.1:18081/health", timeout=2)
        except:
            # 没跑，启动它
            subprocess.Popen(["nohup","python3","-m","llama_cpp.server",
                "--model","/root/.cache/modelscope/models/Qwen--Qwen2.5-1.5B-Instruct-GGUF/snapshots/master/qwen2.5-1.5b-instruct-q4_k_m.gguf",
                "--port","18081","--n_ctx","2048","--n_threads","4","--chat_format","chatml"],
                stdout=open("/root/zongyuan-yuanji/logs/llama.log","a"), stderr=subprocess.STDOUT)
            time.sleep(8)  # 等模型加载
        
        # 调本地模型
        t0 = time.time()
        local_payload = {"messages": messages, "max_tokens": max_tokens}
        r = requests.post("http://127.0.0.1:18081/v1/chat/completions", json=local_payload, timeout=30)
        if r.status_code == 200:
            data = r.json()
            return {
                "content": data["choices"][0]["message"]["content"],
                "model_used": "local-qwen-fallback",
                "latency": round(time.time() - t0, 2),
                "tokens": 0,
                "note": "所有外部API失败，本地兜底"
            }
    except Exception as e:
        errors.append(f"local: {str(e)[:100]}")
    
    return {"error": "all models failed", "errors": errors}

if __name__ == "__main__":
    # 测试
    result = route_chat([{"role":"user","content":"你好，一句话介绍"}])
    print(json.dumps(result, ensure_ascii=False, indent=2))
