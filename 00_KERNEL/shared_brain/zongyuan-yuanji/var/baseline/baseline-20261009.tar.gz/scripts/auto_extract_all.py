#!/usr/bin/env python3
import json, glob, os, time
# 全自动全域提炼
sources = {
    "本地脚本": glob.glob("/root/zongyuan-yuanji/scripts/*.py"),
    "任务": glob.glob("/root/zongyuan-yuanji/var/tasks/*.json"),
    "记忆": glob.glob("/root/zongyuan-yuanji/var/trajectories/*.json"),
}
for k, files in sources.items():
    print(k, ":", len(files), "个文件")
