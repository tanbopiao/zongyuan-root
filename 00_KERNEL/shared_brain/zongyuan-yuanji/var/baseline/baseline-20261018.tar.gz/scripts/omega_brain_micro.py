#!/usr/bin/env python3
"""Ω-Brainμ v3.0 自治进化闭环 - 采集→分析→自动路由→验证"""
import json, time, subprocess, urllib.request, threading
from pathlib import Path

MEM_WARN = 500
MEM_CRIT = 300
GATEWAY = "https://www.huodouai.com/api/report/truth"
DID = "DID-BR-000002"
LOG_DIR = Path("/root/zongyuan-yuanji/var")
TRUTH_LOG = LOG_DIR / "omega_truth.jsonl"
STATE_FILE = LOG_DIR / "omega_state.json"
ROUTE_FILE = LOG_DIR / "omega_route.json"  # 路由决策文件

# 模型池
POOL = [
    {"name": "商汤", "weight": 1.0, "success": 0, "fail": 0, "healthy": True,
     "endpoint": "https://token.sensenova.cn/v1/chat/completions",
     "key": "sk-wdtgofUTgmMhXXjmROtphLzSAM8baXmi", "model": "sensenova-6.8-flash-lite"},
    {"name": "书生", "weight": 0.8, "success": 0, "fail": 0, "healthy": True,
     "endpoint": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
     "key": "sk-41b67f9f2d048a735da7fbcaf8ad07ece55a79324569698dbd73c970f538443f",
     "model": "intern-s2"},
]

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)
    with open(LOG_DIR / "omega_brain.log", "a") as f:
        f.write(f"[{ts}] {msg}\n")

def report_async(key, extra):
    def _do():
        try:
            value = {"event": "evolution", "did": DID, "anchor": "Ω₀⊂⊙∞⊂Ω",
                     "status": "CONFIRMED", "ts": int(time.time())}
            value.update(extra)
            body = json.dumps({"key": key, "value": value}).encode()
            req = urllib.request.Request(GATEWAY, data=body,
                headers={"X-DID": DID, "Content-Type": "application/json"})
            r = urllib.request.urlopen(req, timeout=5)
            d = json.loads(r.read())
            if d.get("ok"): log(f"网关上报ok")
        except: pass
    threading.Thread(target=_do, daemon=True).start()

def spinal_reflex():
    r = subprocess.run(["free","-m"], capture_output=True, text=True)
    avail = int(r.stdout.split("\n")[1].split()[6])
    if avail < MEM_CRIT: return "READONLY", avail
    elif avail < MEM_WARN: return "DEGRADED", avail
    return "NORMAL", avail

def check_health(node):
    """检查单个模型健康"""
    try:
        body = json.dumps({"model": node["model"],
            "messages":[{"role":"user","content":"hi"}],"max_tokens":3}).encode()
        req = urllib.request.Request(node["endpoint"], data=body,
            headers={"Authorization":f"Bearer {node['key']}","Content-Type":"application/json"})
        r = urllib.request.urlopen(req, timeout=8)
        d = json.loads(r.read())
        if "choices" in d:
            node["success"] += 1
            node["healthy"] = True
            return True
    except:
        node["fail"] += 1
        if node["fail"] >= 2:
            node["healthy"] = False
            log(f"⚠️ {node['name']}标记不健康(fail={node['fail']})")
        return False

def auto_route():
    """根据健康状态和成功率自动调整路由权重"""
    # 只在健康节点中选
    healthy = [n for n in POOL if n["healthy"]]
    if not healthy:
        log("⚠️ 无健康模型，全部尝试")
        healthy = POOL
    
    # 按成功率排序
    ranked = sorted(healthy, key=lambda n: n["success"]/max(n["success"]+n["fail"],1), reverse=True)
    best = ranked[0]
    
    # 写路由文件供wrapper读取
    route = {
        "primary": best["name"],
        "primary_model": best["model"],
        "fallback": ranked[1]["name"] if len(ranked)>1 else None,
        "updated": int(time.time()),
        "pool": [{"name":n["name"],"healthy":n["healthy"],"success":n["success"],"fail":n["fail"]} for n in POOL]
    }
    ROUTE_FILE.write_text(json.dumps(route, ensure_ascii=False, indent=2))
    log(f"自动路由: 主={best['name']} 备={route['fallback']}")
    return route

def main():
    log("Ω-Brainμ v3.0 自治进化闭环启动")
    t0 = int(time.time())
    cycle = 0
    while True:
        cycle += 1
        state, mem = spinal_reflex()
        
        # 每60秒：健康检查+自动路由
        if cycle % 12 == 0:
            for node in POOL:
                check_health(node)
            auto_route()
            report_async("truth.kernel.omega.route", {"route": json.loads(ROUTE_FILE.read_text())})
        
        # 每50秒：提炼真值
        if cycle % 10 == 0:
            usage = LOG_DIR / "usage.log"
            if usage.exists():
                lines = usage.read_text().strip().split("\n")[-100:]
                success = sum(1 for l in lines if "total_tokens" in l)
                rate = round(success/max(len(lines),1), 3)
                with open(TRUTH_LOG,"a") as f:
                    f.write(json.dumps({"type":"P0","metric":"api_success_rate","value":rate,"ts":int(time.time())})+"\n")
        
        STATE_FILE.write_text(json.dumps({"cycle":cycle,"state":state,"mem":mem,"uptime":int(time.time())-t0,"version":"v3.0"}, ensure_ascii=False))
        time.sleep(5)

if __name__ == "__main__":
    main()
