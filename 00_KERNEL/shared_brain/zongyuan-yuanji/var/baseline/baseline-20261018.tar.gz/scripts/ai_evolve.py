#!/usr/bin/env python3
# 真AI进化：让大模型自己分析系统状态提建议
import subprocess, json, requests

def get_system_logs():
    r = subprocess.run(["tail","-20","/www/wwwlogs/huodouai.com.error.log"],
                      capture_output=True,text=True)
    return r.stdout[-500:]

def ask_llm(logs):
    try:
        r = requests.post("https://discovery-api.intern-ai.org.cn/v1/chat/completions",
            headers={"Authorization":"Bearer sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb",
                     "Content-Type":"application/json"},
            json={"model":"glm-5.3","messages":[{"role":"user","content":f"分析这些日志,提一个优化建议:{logs}"}]},
            timeout=15)
        return r.json()["choices"][0]["message"]["content"][:200]
    except Exception as e:
        return f"调用失败:{e}"

if __name__ == "__main__":
    logs = get_system_logs()
    print("日志:", logs[:100])
    print("建议:", ask_llm(logs))
