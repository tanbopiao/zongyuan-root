#!/usr/bin/env python3
import json, time, requests

POOL = [
    {"name":"sensenova","url":"https://token.sensenova.cn/v1/chat/completions","key":"sk-wdtgofUTgmMhXXjmROtphLzSAM8baXmi","model":"sensenova-6.8-flash-lite"},
    {"name":"agents-a1","url":"https://discovery-api.intern-ai.org.cn/v1/chat/completions","key":"sk-41b67f9f2d048a735da7fbcaf8ad07ece55a79324569698dbd73c970f538443f","model":"Agents-A1"},
    {"name":"intern-s2","url":"https://discovery-api.intern-ai.org.cn/v1/chat/completions","key":"sk-41b67f9f2d048a735da7fbcaf8ad07ece55a79324569698dbd73c970f538443f","model":"intern-s2"},
]

def chat(messages, max_tokens=500):
    errors = []
    for m in POOL:
        try:
            body = json.dumps({"model": m["model"], "messages": messages, "max_tokens": max_tokens}).encode()
            r = requests.post(m["url"], data=body, headers={"Authorization": "Bearer "+m["key"], "Content-Type": "application/json"}, timeout=30)
            d = r.json()
            if "choices" in d:
                content = d["choices"][0]["message"].get("content") or d["choices"][0]["message"].get("reasoning") or ""
                if content and len(content) > 3:
                    return {"content": content, "model": m["name"], "ok": True}
            errors.append(m["name"] + ": no choices")
        except Exception as e:
            errors.append(m["name"] + ": " + str(e)[:50])
    return {"content": "[所有模型均不可用] " + "; ".join(errors), "model": "none", "ok": False}

def health():
    result = []
    for m in POOL:
        try:
            body = json.dumps({"model": m["model"], "messages":[{"role":"user","content":"hi"}], "max_tokens":5}).encode()
            r = requests.post(m["url"], data=body, headers={"Authorization": "Bearer "+m["key"], "Content-Type": "application/json"}, timeout=10)
            ok = "choices" in r.json()
            result.append({"name": m["name"], "status": "ok" if ok else "fail"})
        except:
            result.append({"name": m["name"], "status": "error"})
    return result

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "health":
        for h in health():
            print("  " + h["name"] + ": " + h["status"])
    else:
        r = chat([{"role":"user","content":"你好"}])
        print("[" + r["model"] + "] " + r["content"][:100])
