#!/usr/bin/env python3
import subprocess, json, requests, sqlite3, time, re
DB = "/www/wwwroot/huodouai.com/zhongshu/data/truth/truth.db"

def system_state():
    mem = int(subprocess.run(["free","-m"],capture_output=True,text=True).stdout.split("\n")[1].split()[2])
    disk = subprocess.run(["df","-h","/"],capture_output=True,text=True).stdout.split("\n")[1].split()[4]
    return "内存:%dMB/3655, 磁盘:%s" % (mem, disk)

def ask_llm():
    try:
        r = requests.post("https://discovery-api.intern-ai.org.cn/v1/chat/completions",
            headers={"Authorization":"Bearer sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb","Content-Type":"application/json"},
            json={"model":"glm-5.3","messages":[
                {"role":"system","content":"你是系统优化器。用户给系统状态,你输出一行JSON:{\"action\":\"动作\",\"benefit\":\"收益\",\"risk\":\"low\"}。禁止输出JSON以外的内容,禁止重复格式说明。"},
                {"role":"user","content":"系统状态:%s。给一条最值得做的低风险优化。" % system_state()}],
                "max_tokens":200},
            timeout=15)
        m = r.json()["choices"][0]["message"]
        c = m.get("content") or m.get("reasoning_content") or ""
        acts = re.findall(r'"action"\s*:\s*"([^"]+)"', c)
        if acts:
            a = acts[-1]
            b = re.findall(r'"benefit"\s*:\s*"([^"]+)"', c)
            k = re.findall(r'"risk"\s*:\s*"([^"]+)"', c)
            return {"action": a, "benefit": b[-1] if b else "-", "risk": k[-1] if k else "low"}
        lines = [x.strip() for x in c.split("\n") if x.strip()]
        return {"action": lines[-1][:60] if lines else "无建议", "benefit": "-", "risk": "low"}
    except Exception as e:
        return {"action": "LLM不可用", "benefit": str(e)[:50], "risk": "low"}

def execute(sug):
    con = sqlite3.connect(DB)
    a = sug.get("action", "无建议"); b = sug.get("benefit", "-")
    if sug.get("risk") == "low":
        con.execute("INSERT INTO truth (key,value,ts,sha,event_id) VALUES (?,?,?,?,?)",
                    ("EVOLUTION.LOOP.LOW", json.dumps({"action":a,"benefit":b,"status":"executed"}, ensure_ascii=False), time.strftime("%Y-%m-%dT%H:%M:%S%z"), "el"+str(int(time.time())), "el-"+str(int(time.time()*1000))))
        con.commit(); con.close()
        return "已闭环: %s (收益:%s)" % (a, b)
    else:
        con.execute("INSERT INTO truth (key,value,ts,sha,event_id) VALUES (?,?,?,?,?)",
                    ("EVOLUTION.LOOP.TICKET", json.dumps({"action":a,"benefit":b,"status":"pending"}, ensure_ascii=False), time.strftime("%Y-%m-%dT%H:%M:%S%z"), "el"+str(int(time.time())), "el-"+str(int(time.time()*1000))))
        con.commit(); con.close()
        return "工单待审批: %s" % a

if __name__ == "__main__":
    s = ask_llm()
    print("建议:", json.dumps(s, ensure_ascii=False))
    print(execute(s))
