#!/usr/bin/env python3
import json, time, urllib.request
from pathlib import Path

SEED_FILE = "/root/zongyuan-yuanji/persist/seed_truth/text/seed_text.jsonl"

FREE_APIS = [
    {"name":"intern-deepseek","url":"https://discovery-api.intern-ai.org.cn/v1/chat/completions","key":"sk-41b67f9f2d048a735da7fbcaf8ad07ece55a79324569698dbd73c970f538443f","model":"deepseek-v4-flash-0731"},
    {"name":"intern-glm5","url":"https://discovery-api.intern-ai.org.cn/v1/chat/completions","key":"sk-41b67f9f2d048a735da7fbcaf8ad07ece55a79324569698dbd73c970f538443f","model":"glm-5.3"},
    {"name":"intern-qwen","url":"https://discovery-api.intern-ai.org.cn/v1/chat/completions","key":"sk-41b67f9f2d048a735da7fbcaf8ad07ece55a79324569698dbd73c970f538443f","model":"qwen3.8-27b"},
    {"name":"intern-kimi","url":"https://discovery-api.intern-ai.org.cn/v1/chat/completions","key":"sk-41b67f9f2d048a735da7fbcaf8ad07ece55a79324569698dbd73c970f538443f","model":"kimi-k2.6"},
    {"name":"sensenova","url":"https://token.sensenova.cn/v1/chat/completions","key":"sk-wdtgofUTgmMhXXjmROtphLzSAM8baXmi","model":"sensenova-6.8-flash-lite"},
]

QUESTIONS = [
    "在自治AI系统中，如何评估一个算子的综合能力评分？列出关键维度。",
    "工单优先级P0/P1/P2/P3如何划分？动态重排时考虑哪些因素？",
    "资源预分配时，如何预估AI推理任务的显存和token消耗？",
    "当主API失败时，降级策略应该怎么设计？备选能力如何选择？",
    "工单断点续跑时，快照应该保存哪些状态？恢复时如何校验？",
    "能力兼容矩阵应该记录哪些关系？新增算子时如何校验兼容性？",
    "排队池流量整形时，如何根据系统负载调整入队速率？",
    "工单验收判定应该检查哪些维度？不合格如何处理？",
    "重试策略中，哪些错误可重试，哪些必须终止？指数退避怎么设计？",
    "成本核算时，一个工单的全生命周期成本包含哪些项？",
    "能力依赖图谱如何构建？任务启动前如何校验依赖完整性？",
    "配额稳态管控时，阈值如何设置？耗尽后系统进入什么模式？",
    "新节点上线时，能力自动发现扫描应该上报哪些信息？",
    "风险评分四轨道如何划分？什么情况进入仿真预审？",
    "能力需求匹配时，如何从工单需求匹配最优算子组合？",
]

def call_api(api, question):
    auth = "Bearer " + api["key"]
    body = json.dumps({"model":api["model"],"messages":[{"role":"system","content":"你是AI系统架构专家。简洁回答，不超过150字。"},{"role":"user","content":question}],"max_tokens":300,"temperature":0.3}).encode()
    req = urllib.request.Request(api["url"], data=body, headers={"Content-Type":"application/json","Authorization":auth})
    try:
        r = json.loads(urllib.request.urlopen(req, timeout=30).read())
        return r["choices"][0]["message"]["content"].strip()
    except Exception as e:
        return None

def main():
    existing = set()
    if Path(SEED_FILE).exists():
        for line in open(SEED_FILE):
            try: existing.add(json.loads(line)["seed_id"])
            except: pass
    new = 0
    for qi, q in enumerate(QUESTIONS):
        for api in FREE_APIS:
            sid = "FREE-%s-Q%02d" % (api["name"], qi+1)
            if sid in existing: continue
            ans = call_api(api, q)
            if not ans or len(ans) < 10: continue
            seed = {"seed_id":sid,"level":"L1","system_prompt":"你是元内核微脑，按元法则调度工单与能力","user_prompt":q[:100],"response":ans[:200],"weight_version":"v6","gen_params":{"seed":42,"temp":0.3},"source":"free_llm:"+api["name"],"timestamp":time.strftime("%Y-%m-%d")}
            with open(SEED_FILE,"a") as f: f.write(json.dumps(seed,ensure_ascii=False)+"\n")
            new += 1
            print("+ " + sid)
            time.sleep(1)
    print("本次提炼 %d 条" % new)

if __name__ == "__main__":
    main()
