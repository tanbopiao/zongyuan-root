#!/usr/bin/env python3
"""
Ω-Brainμ 协同编排器
串联：工单执行 → 真值提炼 → API故障切换 → 记忆检索
"""
import json, time, subprocess, urllib.request, threading
from pathlib import Path

LOG_DIR = Path("/root/zongyuan-yuanji/var")
STATE_FILE = LOG_DIR / "orchestrator_state.json"
TRUTH_LOG = LOG_DIR / "omega_truth.jsonl"

# 模型池（带健康状态）
POOL = [
    {"name": "商汤", "endpoint": "https://token.sensenova.cn/v1/chat/completions",
     "key": "sk-wdtgofUTgmMhXXjmROtphLzSAM8baXmi", "model": "sensenova-6.8-flash-lite",
     "healthy": True, "fail_count": 0},
    {"name": "书生", "endpoint": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
     "key": "sk-41b67f9f2d048a735da7fbcaf8ad07ece55a79324569698dbd73c970f538443f",
     "model": "intern-s2", "healthy": True, "fail_count": 0},
]

def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)
    with open(LOG_DIR / "orchestrator.log", "a") as f:
        f.write(f"[{ts}] {msg}\n")

def check_model_health(node):
    """检查单个模型健康状态"""
    try:
        body = json.dumps({
            "model": node["model"],
            "messages": [{"role": "user", "content": "hi"}],
            "max_tokens": 5
        }).encode()
        req = urllib.request.Request(node["endpoint"], data=body,
            headers={"Authorization": f"Bearer {node['key']}", "Content-Type": "application/json"})
        r = urllib.request.urlopen(req, timeout=8)
        d = json.loads(r.read())
        if "choices" in d:
            node["healthy"] = True
            node["fail_count"] = 0
            return True
    except:
        node["fail_count"] += 1
        if node["fail_count"] >= 2:
            node["healthy"] = False
            log(f"⚠️ {node['name']} 标记为不健康")
        return False

def health_check_loop():
    """每60秒检查所有模型健康状态"""
    while True:
        for node in POOL:
            check_model_health(node)
        healthy = [n["name"] for n in POOL if n["healthy"]]
        log(f"模型健康: {healthy}")
        time.sleep(60)

def extract_from_logs():
    """从wrapper日志提炼真值"""
    extracted = []
    usage = LOG_DIR / "usage.log"
    if usage.exists():
        lines = usage.read_text().strip().split("\n")[-50:]
        for line in lines:
            if "total_tokens" in line:
                try:
                    d = json.loads(line)
                    extracted.append({
                        "type": "P0",
                        "model": d.get("model", "unknown"),
                        "tokens": d.get("total_tokens", 0),
                        "ts": int(time.time())
                    })
                except: pass
    return extracted[-10:]  # 最近10条

def main():
    log("Ω 协同编排器启动")
    
    # 启动健康检查线程
    threading.Thread(target=health_check_loop, daemon=True).start()
    
    t0 = int(time.time())
    cycle = 0
    while True:
        cycle += 1
        
        # 每30秒提炼一次
        if cycle % 6 == 0:
            truths = extract_from_logs()
            if truths:
                log(f"提炼{len(truths)}条P0真值")
                with open(TRUTH_LOG, "a") as f:
                    for t in truths:
                        f.write(json.dumps(t, ensure_ascii=False) + "\n")
        
        # 写状态
        STATE_FILE.write_text(json.dumps({
            "cycle": cycle,
            "healthy_models": [n["name"] for n in POOL if n["healthy"]],
            "uptime": int(time.time()) - t0
        }, ensure_ascii=False))
        
        time.sleep(5)

if __name__ == "__main__":
    main()
