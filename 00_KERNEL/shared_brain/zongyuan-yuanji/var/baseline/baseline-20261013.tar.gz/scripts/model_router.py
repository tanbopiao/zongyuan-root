#!/usr/bin/env python3
import requests, time, json

MODELS = [
    {"name":"shusheng-glm","url":"https://discovery-api.intern-ai.org.cn/v1/chat/completions","key":"sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb","model":"glm-5.3"},
    {"name":"doubao","url":"https://ark.cn-beijing.volces.com/api/v3/chat/completions","key":"ark-800a6f28-5c7f-4ec5-9766-4b7da1a58f1d-50a70","model":"ep-20261008171222-97c7z"},
    {"name":"zhipu","url":"https://open.bigmodel.cn/api/paas/v4/chat/completions","key":"d63c880c0e1b424d8ad242f686e83451.vhHr5d5OQUY5UHNp","model":"glm-4.7-flash"},
]

def call_best(msgs, mt=300):
    for m in MODELS:
        try:
            t=time.time()
            body=json.dumps({"model":m["model"],"messages":msgs,"max_tokens":mt}).encode()
            r=requests.post(m["url"],data=body,headers={"Authorization":"Bearer "+m["key"],"Content-Type":"application/json"},timeout=60)
            ms=int((time.time()-t)*1000)
            d=r.json()
            msg=d["choices"][0]["message"]
            ans=msg.get("content") or msg.get("reasoning_content") or ""
            if ans and len(ans)>5:
                print("[router] used",m["name"],ms,"ms")
                return ans
        except Exception as e:
            print("[router]",m["name"],"failed:",str(e)[:60])
    return "[所有模型均不可用]"

if __name__=="__main__":
    print(call_best([{"role":"user","content":"hi"}],50))
