#!/bin/bash
# yuanji GGUF 推理引擎（llama-cpp-python OpenAI兼容）
MODEL="${1:-/root/.cache/modelscope/models/Qwen--Qwen2.5-0.5B-Instruct-GGUF/snapshots/master/qwen2.5-0.5b-instruct-q2_k.gguf}"
PORT="${2:-8080}"
THREADS="${3:-2}"
exec python3 -m llama_cpp.server --model "$MODEL" --host 127.0.0.1 --port "$PORT" --n_ctx 2048 --n_threads "$THREADS" >> /tmp/llama_server.log 2>&1
