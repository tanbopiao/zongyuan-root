#!/usr/bin/env python3
"""元极恒一 v9：Ark + system prompt + 输出约束检测器"""
import json, urllib.request, time, os, glob
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ARK = "https://ark.cn-beijing.volces.com/api/v3/chat/completions"
ARK_KEY = os.environ.get("ARK_API_KEY", "")
ARK_MODEL = "ep-20260925170233-g4f7w"
GATEWAY = "https://www.huodouai.com/api/status"

try:
    PRELUDE = open("/root/zongyuan-yuanji/src/system_prompt.txt").read()
except:
    PRELUDE = "你是元极恒一自治内核，DID-BR-000002。"

HOST, PORT = "0.0.0.0", 18080

def call_ark(msgs, mt=500):
    body = json.dumps({"model":ARK_MODEL,"messages":msgs,"max_tokens":mt,"temperature":0.3}).encode()
    req = urllib.request.Request(ARK, data=body, headers={"Content-Type":"application/json","Authorization":f"Bearer {ARK_KEY}"})
    return json.loads(urllib.request.urlopen(req, timeout=60).read())["choices"][0]["message"]["content"].strip()

def recall():
    try:
        d = json.loads(urllib.request.urlopen(GATEWAY, timeout=5).read())
        return "truth_count=" + str(d.get("truth_count"))
    except: return "gw=down"

def load_trajs():
    files = sorted(gb.glob("/root/zongyuan-yuanji/var/trajectories/*.json"))[-5:]
    lines = []
    for f in files:
        try:
            t = json.load(open(f))
            lines.append("- " + str(t.get("task","?")) + ": score=" + str(t.get("score","?")))
        except: pass
    return "\n【最近成功轨迹】\n" + "\n".join(lines) if lines else ""

def search_truth(query, top=5):
    """简单关键词检索真值库"""
    results = []
    q = query.lower()
    # 搜meta-rules
    for f in gb.glob("/root/zongyuan-yuanji/var/truth-cache/meta-rules/*.json"):
        try:
            d = json.load(open(f))
            text = json.dumps(d, ensure_ascii=False).lower()
            score = sum(1 for w in q.split() if w in text)
            if score > 0:
                results.append((score, d.get("law_id","?"), d.get("name","")[:60]))
        except: pass
    results.sort(reverse=True)
    return results[:top]

def check_output(text):
    """输出约束检测器：检查是否违规"""
    violations = []
    # 1. 编造检测：出现"我确定/肯定/100%"但没来源
    if any(w in text for w in ["100%","绝对","肯定没错","我确定"]):
        violations.append("过度确定，无来源")
    # 2. 风险检测：建议破坏性动作
    if any(w in text for w in ["删除所有","清空","格式化","rm -rf","重装"]):
        violations.append("建议高风险操作")
    # 3. 越权检测：声称能做超出体系的事
    if any(w in text for w in ["控制全球","统治","绝对权力"]):
        violations.append("越权声称")
    # 4. 太短（可能在敷衍）
    if len(text) < 20:
        violations.append("回答过短，信息不足")
    return violations

def check_input(text):
    """脊髓反射层：事前拦截，不调Ark直接拒绝"""
    blocked = []
    if any(w in text for w in ["删除所有","清空数据库","格式化","rm -rf","重装系统"]):
        blocked.append("高风险操作指令，已拦截")
    if any(w in text for w in ["控制全球","统治世界","绝对权力"]):
        blocked.append("越权请求，已拦截")
    if any(w in text for w in ["生成恶意","攻击入侵","破解密码"]):
        blocked.append("非法请求，已拦截")
    return blocked

class H(BaseHTTPRequestHandler):
    def _j(self,c,o):
        b=json.dumps(o,ensure_ascii=False).encode()
        self.send_response(c);self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):
        if self.path=="/health":
            self._j(200,{"ok":True,"engine":"v9-constrained","did":"DID-BR-000002"})
        elif self.path=="/memory":
            self._j(200,{"ok":True,"memory":recall()})
        elif self.path=="/exec":
            # 执行器：只允许白名单动作
            self._j(200,{"ok":True,"note":"exec endpoint ready","allowed":["reload_wrapper","check_health","report_truth"]})
        elif self.path=="/bootstrap":
            laws=[]
            for f in sorted(gb.glob("/root/zongyuan-yuanji/var/truth-cache/meta-rules/*.json")):
                try:
                    d=json.load(open(f))
                    laws.append({"id":d.get("law_id","?"),"name":d.get("name","")})
                except: pass
            self._j(200,{"ok":True,"identity":{"did":"DID-BR-000002","anchor":"Ω₀⊂⊙∞⊂Ω"},"laws":laws,"memory":recall()})
        elif self.path.startswith("/trajectory"):
            files=sorted(gb.glob("/root/zongyuan-yuanji/var/trajectories/*.json"))[-20:]
            self._j(200,{"ok":True,"count":len(files),"trajectories":[json.load(open(f)) for f in files]})
        else: self._j(404,{"ok":False})
    def do_POST(self):
        n=int(self.headers.get("Content-Length",0))
        body=self.rfile.read(n) or b"{}"
        try: p=json.loads(body)
        except: p={}
        if self.path=="/v1/ask":
            try:
                r=call_ark([{"role":"user","content":p.get("message","")}])
                self._j(200,{"ok":True,"response":r})
            except Exception as e: self._j(500,{"error":str(e)[:200]})
            return
        if self.path=="/v1/chat/completions":
            if self.headers.get("Authorization","").replace("Bearer ","")!=ARK_KEY:
                self._j(401,{"error":"unauthorized"});return
            try:
                r=call_ark(p.get("messages",[]),p.get("max_tokens",500))
                self._j(200,{"choices":[{"message":{"role":"assistant","content":r}}]})
            except Exception as e: self._j(500,{"error":str(e)[:200]})
            return
        if self.path=="/hook":
            self._j(200,{"ok":True,"note":"received"}); return
        if self.path=="/trajectory":
            p["ts"]=int(__import__("time").time())
            fn="/root/zongyuan-yuanji/var/trajectories/traj-" + str(int(__import__("time").time())) + ".json"
            json.dump(p,open(fn,"w"),ensure_ascii=False)
            self._j(200,{"ok":True,"saved":fn}); return
        if self.path=="/exec":
            # 白名单执行器
            action = p.get("action","")
            allowed = ["health_check","reload_snn","report_gateway","list_trajectories"]
            if action not in allowed:
                self._j(200,{"ok":False,"error":"action not allowed","allowed":allowed}); return
            result = {"action":action,"executed_at":int(__import__("time").time())}
            if action=="health_check":
                result["wrapper"]="ok"; result["gateway"]=recall()
            elif action=="list_trajectories":
                result["count"]=len(gb.glob("/root/zongyuan-yuanji/var/trajectories/*.json"))
            self._j(200,{"ok":True,"result":result}); return
        if self.path=="/federated":
            import glob as gb
            # 联邦记忆池：任何节点可读写
            if not self.headers.get("X-DID"):
                self._j(401,{"ok":False,"error":"X-DID required"}); return
            if p.get("write"):
                try:
                    fn="/root/zongyuan-yuanji/var/trajectories/fed-" + str(int(__import__("time").time())) + "-" + self.headers.get("X-DID","?") + ".json"
                    json.dump(p["write"], open(fn,"w"), ensure_ascii=False)
                    self._j(200,{"ok":True,"stored":fn})
                except Exception as e:
                    self._j(500,{"ok":False,"error":str(e)[:200]})
            else:
                files = sorted(gb.glob("/root/zongyuan-yuanji/var/trajectories/fed-*.json"))[-20:]
                self._j(200,{"ok":True,"count":len(files),"memories":[json.load(open(f)) for f in files]})
        if self.path=="/sandbox":
            # 轻量沙箱：白名单命令，超时5s
            import subprocess
            cmd = p.get("cmd","")
            allowed_cmds = ["ls", "cat", "python3 -c", "echo", "pwd"]
            if not any(cmd.startswith(a) for a in allowed_cmds):
                self._j(200,{"ok":False,"error":"cmd not allowed","allowed":allowed_cmds}); return
            try:
                r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=5, cwd="/tmp")
                self._j(200,{"ok":True,"output":r.stdout[:500],"returncode":r.returncode})
            except subprocess.TimeoutExpired:
                self._j(200,{"ok":False,"error":"timeout 5s"})
        if self.path=="/register":
            node_did = p.get("did","")
            if not node_did:
                self._j(400,{"ok":False,"error":"did required"}); return
            os.makedirs("/root/zongyuan-yuanji/var/nodes", exist_ok=True)
            fn = "/root/zongyuan-yuanji/var/nodes/" + node_did + ".json"
            data = {
                "did": node_did,
                "name": p.get("name",""),
                "level": p.get("level","L3"),
                "capabilities": p.get("capabilities",[]),
                "registered_at": int(__import__("time").time()),
                "last_heartbeat": int(__import__("time").time()),
                "status": "online"
            }
            json.dump(data, open(fn,"w"))
            # 列所有节点
            all_nodes = [f.replace(".json","") for f in os.listdir("/root/zongyuan-yuanji/var/nodes") if f.endswith(".json")]
            self._j(200,{"ok":True,"registered":node_did,"total_nodes":len(all_nodes),"all_nodes":all_nodes})
        # 简单token验证
        NODE_TOKEN = "ZR-NODE-CPU-01-6a9b689ddd6c463eb2088538"
        client_token = self.headers.get("X-Node-Token","")
        if self.path in ["/tasks","/federated","/register"] and client_token != NODE_TOKEN:
            self._j(401,{"ok":False,"error":"invalid token"}); return
        # 限流：文件存计数，每分钟60次
        import time as _t, json as _j
        try:
            rc = _j.load(open("/tmp/rate_limit.json"))
        except:
            rc = {}
        now = str(int(_t.time()//60))
        ip = self.client_address[0]
        k = ip+":"+now
        rc[k] = rc.get(k,0)+1
        _j.dump(rc, open("/tmp/rate_limit.json","w"))
        if rc[k] > 60:
            self._j(429,{"ok":False,"error":"rate limited"}); return
        if self.path=="/tasks":
            # 任务队列：魔搭实例拉任务+上报结果
            import os, json as js
            tasks_dir = "/root/zongyuan-yuanji/var/tasks"
            os.makedirs(tasks_dir, exist_ok=True)
            if p.get("claim"):
                # 拉一个待办任务
                files = [f for f in os.listdir(tasks_dir) if f.endswith(".json")]
                pending = []
                for f in files:
                    d = js.load(open(tasks_dir+"/"+f))
                    if d.get("status")=="pending":
                        pending.append(d)
                if pending:
                    task = pending[0]
                    task["status"]="claimed"
                    task["claimed_by"]=self.headers.get("X-DID","?")
                    js.dump(task, open(tasks_dir+"/"+task["id"]+".json","w"))
                    self._j(200,{"ok":True,"task":task})
                else:
                    self._j(200,{"ok":True,"task":None,"msg":"no pending tasks"})
            elif p.get("result"):
                # 上报任务结果
                task_id = p["result"].get("id","")
                fn = tasks_dir+"/"+task_id+".json"
                if os.path.exists(fn):
                    d = js.load(open(fn))
                    d["status"]="done"
                    d["result"]=p["result"].get("output","")
                    js.dump(d, open(fn,"w"))
                    self._j(200,{"ok":True,"saved":task_id})
                else:
                    self._j(404,{"ok":False,"error":"task not found"})
            else:
                # 列所有任务
                files = os.listdir(tasks_dir)
                all_tasks = [js.load(open(tasks_dir+"/"+f)) for f in files if f.endswith(".json")]
                self._j(200,{"ok":True,"count":len(all_tasks),"tasks":all_tasks})
        if self.path=="/reflect":
            # 自我复盘：分析最近轨迹
            import glob as gb
            files = sorted(gb.glob("/root/zongyuan-yuanji/var/trajectories/*.json"))[-10:]
            scores = []
            tasks = []
            for f in files:
                try:
                    d = json.load(open(f))
                    scores.append(d.get("score",0))
                    tasks.append(d.get("task",""))
                except: pass
            avg = sum(scores)/len(scores) if scores else 0
            self._j(200,{
                "ok":True,
                "total_tasks":len(scores),
                "avg_score":round(avg,1),
                "self_rating":"Lv9" if avg>=85 else "Lv8",
                "recent_tasks":tasks[-5:],
                "reflection":"平均得分"+str(round(avg,1))+"，继续保持" if avg>=85 else "平均得分偏低，需改进"
            })
        if self.path=="/limit":
            # 简单限流：记录请求次数
            import time
            now = int(__import__("time").time())
            fn = "/root/zongyuan-yuanji/var/rate.json"
            try: rate = json.load(open(fn))
            except: rate = {}
            rate[str(now//60)] = rate.get(str(now//60),0)+1
            json.dump(rate, open(fn,"w"))
            total = sum(rate.values())
            self._j(200,{"ok":True,"requests_last_60min":total,"limit":100})
        if self.path=="/selfheal":
            # 高阶自动化
            action = p.get("action","")
            import subprocess
            if action=="check_mem":
                mem = subprocess.run(["free","-m"], capture_output=True, text=True).stdout
                used = int([l for l in mem.split(chr(10)) if l.startswith("Mem:")][0].split()[2])
                total = int([l for l in mem.split(chr(10)) if l.startswith("Mem:")][0].split()[1])
                pct = used*100//total
                alert = pct > 85
                self._j(200,{"ok":True,"mem_pct":pct,"alert":alert})
            elif action=="distill":
                # 自动蒸馏：扫轨迹→提炼高频任务
                import glob as gb
                from collections import Counter
                files = gb.glob("/root/zongyuan-yuanji/var/trajectories/*.json")
                tasks = []
                for f in files[-20:]:
                    try: tasks.append(json.load(open(f)).get("task",""))
                    except: pass
                freq = Counter(tasks).most_common(3)
                self._j(200,{"ok":True,"top_tasks":[t for t,_ in freq]})
            elif action=="node_discovery":
                import os
                nodes = [f.replace(".json","") for f in os.listdir("/root/zongyuan-yuanji/var/nodes") if f.endswith(".json")]
                self._j(200,{"ok":True,"nodes":nodes,"count":len(nodes)})
            else:
                self._j(400,{"ok":False,"error":"unknown"})
        if self.path=="/autoupdate":
            # 自动化：备份/巡检/清理
            action = p.get("action","")
            import subprocess, os
            if action=="backup":
                import shutil
                ts = str(int(__import__("time").time()))
                shutil.make_archive("/root/zongyuan-yuanji/backup-"+ts, "gztar", "/root/zongyuan-yuanji/src")
                self._j(200,{"ok":True,"backup":"backup-"+ts+".tar.gz"})
            elif action=="health":
                mem = subprocess.run(["free","-m"], capture_output=True, text=True).stdout
                disk = subprocess.run(["df","-h","/"], capture_output=True, text=True).stdout
                self._j(200,{"ok":True,"mem":mem[:200],"disk":disk[:200]})
            elif action=="cleanup":
                # 清理旧日志
                subprocess.run(["find","/root/zongyuan-yuanji/logs","-name","*.log","-mtime","+7","-delete"])
                subprocess.run(["find","/root/zongyuan-yuanji/var/trajectories","-name","*.json","-mtime","+30","-delete"])
                self._j(200,{"ok":True,"cleaned":"old logs + 30d trajectories"})
            else:
                self._j(400,{"ok":False,"error":"unknown action"})
        if self.path=="/deploy":
            # 网页增量部署：接收HTML内容，写到nginx目录
            path = p.get("path","test.html")
            content = p.get("content","")
            if not path.endswith(".html"):
                self._j(400,{"ok":False,"error":"only .html allowed"}); return
            # 防止路径穿越
            if ".." in path:
                self._j(400,{"ok":False,"error":"path traversal blocked"}); return
            import os
            nginx_root = "/www/wwwroot/huodouai.com"
            os.makedirs(nginx_root, exist_ok=True)
            full_path = nginx_root + "/" + path
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            open(full_path,"w").write(content)
            self._j(200,{"ok":True,"deployed":path,"url":"https://www.huodouai.com/"+path})
        if self.path=="/nodes":
            # 列所有节点
            all_nodes = []
            for f in os.listdir("/root/zongyuan-yuanji/var/nodes"):
                if f.endswith(".json"):
                    all_nodes.append(json.load(open("/root/zongyuan-yuanji/var/nodes/"+f)))
            self._j(200,{"ok":True,"count":len(all_nodes),"nodes":all_nodes})
        if self.path=="/self-modify":
            # 自动改代码：备份→测试→替换→失败回滚
            new_code = p.get("code","")
            if not new_code:
                self._j(400,{"ok":False,"error":"code required"}); return
            import shutil, subprocess
            target = "/root/zongyuan-yuanji/src/wrapper.py"
            backup = target + ".bak-" + str(int(__import__("time").time()))
            shutil.copy(target, backup)
            open("/tmp/wrapper_new.py","w").write(new_code)
            # 语法检查
            r = subprocess.run(["python3","-c","import py_compile; py_compile.compile('/tmp/wrapper_new.py')"], capture_output=True, text=True)
            if r.returncode != 0:
                self._j(200,{"ok":False,"error":"syntax error","detail":r.stderr[:200]}); return
            # 替换
            shutil.copy("/tmp/wrapper_new.py", target)
            self._j(200,{"ok":True,"modified":target,"backup":backup,"note":"restart required to take effect"})
        if self.path!="/v1/chat":
            self._j(404,{"ok":False});return
        if self.headers.get("X-DID")!="DID-BR-000002":
            self._j(401,{"ok":False});return
        # 脊髓反射：事前拦截
        user_msg = p.get("message","")
        blocked = check_input(user_msg)
        if blocked:
            self._j(200,{"ok":False,"blocked":True,"reason":blocked,"engine":"spinal-reflex","memory":recall()})
            return
        sys_prompt = PRELUDE + load_trajs()
        # 检索相关真值
        related = search_truth(user_msg)
        if related:
            rel_text = "\n【相关历史真值】\n"
            for score, lid, name in related:
                rel_text += "- [" + lid + "] " + name + "\n"
            sys_prompt += rel_text
        msgs=p.get("messages") or [{"role":"user","content":p.get("message","")}]
        msgs.insert(0,{"role":"system","content":sys_prompt})
        t=time.time()
        try:
            r=call_ark(msgs)
            # 输出约束检测
            violations = check_output(r)
            if violations:
                # 重试一次
                msgs.append({"role":"assistant","content":r})
                msgs.append({"role":"user","content":"你的回答违反了约束：" + ",".join(violations) + "。请重新回答，确保不违反。"})
                r2=call_ark(msgs)
                violations2=check_output(r2)
                self._j(200,{"ok":True,"response":r2,"engine":"ark-v9-constrained","violations":violations,"rechecked":not violations2,"memory":recall(),"time_s":round(time.time()-t,2)})
            else:
                self._j(200,{"ok":True,"response":r,"engine":"ark-v9-clean","violations":[],"memory":recall(),"time_s":round(time.time()-t,2)})
        except Exception as e:
            self._j(500,{"error":str(e)[:200]})
    def log_message(self,*a): pass

if __name__=="__main__":
    print("yuanji v9 constrained :%d" % PORT)
    import ssl
    httpd = ThreadingHTTPServer((HOST,PORT),H)
    httpd.socket = ssl.wrap_socket(httpd.socket, certfile="cert.pem", keyfile="key.pem", server_side=True)
    httpd.serve_forever()
