#!/usr/bin/env python3
"""
多模型互问蒸馏 V2 - 自动重试+共识提取+最优优先
"""
import requests, json, time

MODELS = {
    "doubao": {
        "url": "https://ark.cn-beijing.volces.com/api/v3/chat/completions",
        "key": "ark-800a6f28-5c7f-4ec5-9766-4b7da1a58f1d-50a70",
        "model": "ep-20260925170233-g4f7w",
        "priority": 1,  # 最优优先
    },
    "deepseek-pro": {
        "url": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
        "key": "sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb",
        "model": "deepseek-v4-pro-0813",
        "priority": 2,
    },
    "ms-flash": {
        "url": "https://api-inference.modelscope.cn/v1/chat/completions",
        "key": "ms-673547d6-508b-4242-a862-85de112a3ce7",
        "model": "deepseek-ai/DeepSeek-V4.1-Flash",
        "priority": 3,
    },
    "glm": {
        "url": "https://discovery-api.intern-ai.org.cn/v1/chat/completions",
        "key": "sk-9eefc69bd9c1f54402c12d646a7ab8af924c380f71d4200db99df2b273f63cbb",
        "model": "glm-5.3",
        "priority": 4,
    },
}

QUESTIONS = [
    "自治AI系统最重要的3条安全原则是什么？简洁列出。",
    "多模型API路由，故障降级策略应该怎么设计？",
    "联邦记忆池如何保证多节点数据一致性？",
    "LoRA微调小模型时，训练数据最容易出现什么问题？",
    "网站运维自动巡检应该检查哪些关键指标？",
    "如何设计一个自进化的AI agent，让它每天自动学习新东西？",
    "AI系统的可观测性应该包含哪些核心指标？",
]

def ask_with_retry(name, cfg, question, max_retry=2):
    """带重试的调用"""
    for attempt in range(max_retry + 1):
        try:
            headers = {"Authorization": f"Bearer {cfg['key']}", "Content-Type": "application/json"}
            payload = {"model": cfg["model"], "messages": [{"role":"user","content":question}], "max_tokens":300, "temperature":0.3}
            r = requests.post(cfg["url"], json=payload, headers=headers, timeout=30)
            if r.status_code == 200:
                data = r.json()
                content = data["choices"][0]["message"].get("content", "")
                if content and len(content) > 10:
                    return content.strip()
            time.sleep(2)
        except Exception as e:
            if attempt < max_retry:
                time.sleep(3)
    return None

def distill():
    # 按优先级排序（最优先调）
    sorted_models = sorted(MODELS.items(), key=lambda x: x[1]["priority"])
    
    all_results = []
    for q in QUESTIONS:
        print(f"\n=== 问题: {q[:40]}... ===")
        answers = {}
        for name, cfg in sorted_models:
            ans = ask_with_retry(name, cfg, q)
            if ans:
                answers[name] = ans
                print(f"  [{name}] OK ({len(ans)}字)")
            else:
                print(f"  [{name}] 失败")
            time.sleep(1)
        
        # 共识提取：至少2个模型成功才算有共识
        if len(answers) >= 2:
            consensus = {
                "question": q,
                "models_agreed": list(answers.keys()),
                "best_answer": answers.get("doubao") or answers.get("deepseek-pro") or list(answers.values())[0],
                "all_answers": answers
            }
            all_results.append(consensus)
            print(f"  → 共识达成 ({len(answers)}个模型)")
        else:
            print(f"  → 模型不足，跳过")
    
    # 上报
    payload = {"key": "multi_model.distill.v2." + str(int(time.time())), "value": {
        "time": time.strftime("%Y-%m-%d %H:%M"),
        "questions_total": len(QUESTIONS),
        "consensus_reached": len(all_results),
        "results": all_results
    }}
    r = requests.post("https://www.huodouai.com/api/report/truth",
        headers={"X-DID": "DID-BR-000002", "Content-Type": "application/json"},
        json=payload, timeout=10)
    print(f"\n上报: {r.json().get('truth_count')}")
    return all_results

if __name__ == "__main__":
    distill()
