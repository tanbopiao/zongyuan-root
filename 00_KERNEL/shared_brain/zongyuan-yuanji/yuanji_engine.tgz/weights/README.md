# 元极恒一 · 元端服务器运行环境依赖
# 说明：这是 seed_extractor / seed_verify / hf_yuanji_steady 的运行前提
# 本机当前(2026-10-05)实测：python 3.12.11，缺 torch/transformers/bitsandbytes，无 GPU，内存 3GB

# 必装依赖（CPU 版，适配本机无 GPU）
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu
pip install transformers bitsandbytes psutil pyyaml numpy

# 若后续接入 GPU/CUDA，改用：
# pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121

# 运行顺序
# 1. bash src/seed_ci.sh          # 一键：快照→提取→校验→判定
# 2. 分步：python src/seed_snapshot.py && python src/seed_extractor.py && python src/seed_verify.py

# 权重硬前提：/home/user/ZONGYUAN-ROOT/weights/yuanjihengyi_full_v1/ 必须就位
#   - config.json / modeling_*.py / tokenizer* / pytorch_model*.bin|safetensors
