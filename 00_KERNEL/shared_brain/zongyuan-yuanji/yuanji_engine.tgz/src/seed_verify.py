import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import json
import numpy as np
from pathlib import Path
from hf_yuanji_steady import model, tokenizer, cfg
from seed_extractor import extract_seed_truth, SEED_ROOT


def cosine_similarity(a,b):
    return np.dot(a, b)/(np.linalg.norm(a)*np.linalg.norm(b))


def verify_seed_consistency():
    manifest = json.loads(Path(SEED_ROOT,"manifest.json").read_text(encoding="utf-8"))
    text_lines = Path(SEED_ROOT,"text/seed_text.jsonl").read_text(encoding="utf-8").splitlines()
    drift_stat = {"L0":0,"L1":0,"L2":0}
    pass_stat = {"L0":0,"L1":0,"L2":0}

    for line in text_lines:
        old_seed = json.loads(line)
        level = old_seed["level"]
        new_seed = extract_seed_truth(old_seed["system_prompt"], old_seed["user_prompt"], level)
        old_vec = np.load(SEED_ROOT / "embedding" / old_seed["hidden_vector_file"])
        new_vec = np.load(SEED_ROOT / "embedding" / new_seed["hidden_vector_file"])
        cos_sim = cosine_similarity(old_vec, new_vec)
        threshold = cfg["seed_check"][level]["cos_threshold"]
        text_ok = False

        if level == "L0":
            text_ok = (new_seed["response"] == old_seed["response"])
        elif level == "L1":
            text_ok = (new_seed["response"].strip() == old_seed["response"].strip())
        else:
            text_ok = True

        vec_ok = cos_sim >= threshold
        if text_ok and vec_ok:
            pass_stat[level] +=1
            print(f"✅[{level}] {old_seed['seed_id'][:12]} OK, sim={cos_sim:.4f}")
        else:
            drift_stat[level] +=1
            print(f"⚠️[{level}] {old_seed['seed_id'][:12]} 漂移，sim={cos_sim:.4f}")

    print("\n====收敛校验汇总====")
    for lv in ["L0","L1","L2"]:
        print(f"{lv}: 通过={pass_stat[lv]},漂移={drift_stat[lv]}")
    total_drift = sum(drift_stat.values())
    if drift_stat["L0"] == 0:
        print("✅【L0核心公理无漂移，基准收敛有效】")
        return 0
    else:
        print("❌【L0公理漂移，全域收敛失效，禁止更新基线】")
        return 1


if __name__ == "__main__":
    torch = __import__("torch")
    torch.manual_seed(42)
    sys.exit(verify_seed_consistency())
