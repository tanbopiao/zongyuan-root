#!/usr/bin/env python3
"""
kernel_lora_agent.py — 微模型控制适配器层
职责：
1. token计数 + 上下文裁剪（n_ctx=2048）
2. LoRA热切换（set_adapter）
3. 推理参数固定（temp=0.1, max_tokens=256）
4. 输出预处理 + 真值校验失败路由云端
"""
import json, time, requests
from pathlib import Path

# ========== 配置 ==========
LOCAL_LLM = "http://127.0.0.1:8080/v1/chat/completions"  # llama_cpp
CLOUD_ARK = "https://ark.cn-beijing.volces.com/api/v3/chat/completions"
ARK_KEY = "ark-800a6f28-5c7f-4ec5-9766-4b7da1a58f1d-50a70"
ARK_MODEL = "ep-20261008171222-97c7z"

N_CTX = 2048
RESERVE_TOKENS = 300  # 剩余预警线
MAX_NEW_TOKENS = 256
TEMPERATURE = 0.1

# LoRA技能包映射
LORA_SKILLS = {
    "meta_constitution": {
        "adapter": "lora_meta_constitution",
        "system_prompt": "你是元极恒一元内核微脑。输出必须符合元宪法：风险最小>成本最小>收益最大。简洁结构化输出。"
    },
    "task_router": {
        "adapter": "lora_task_router",
        "system_prompt": "你是工单调度微脑。判断任务优先级P0-P3，评估资源，输出调度方案。"
    },
    "self_check": {
        "adapter": "lora_self_check",
        "system_prompt": "你是自检微脑。分析系统状态，识别异常，输出健康报告。"
    },
    "extract_truth": {
        "adapter": "lora_extract_truth",
        "system_prompt": "你是真值抽取微脑。从文本中结构化提取seed_id/user_prompt/response三元组。"
    },
    "archive": {
        "adapter": "lora_archive",
        "system_prompt": "你是归档格式化微脑。把审计记录格式化为标准JSON上报条目。"
    },
}


def estimate_tokens(text: str) -> int:
    """粗略估算：中文1字≈1.5token，英文1词≈1.3token"""
    cn = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
    en = len(text) - cn
    return int(cn * 1.5 + en * 1.3)


class KernelLoraAgent:
    def __init__(self):
        self.current_adapter = None
        self.history = []

    def set_skill(self, skill: str):
        """切换LoRA技能包"""
        if skill not in LORA_SKILLS:
            raise ValueError(f"未知技能: {skill}")
        self.current_adapter = LORA_SKILLS[skill]["adapter"]
        print(f"[LoRA] 切换到 {self.current_adapter}")

    def _build_messages(self, user_input: str) -> list:
        """构建消息，控制总token不超过n_ctx"""
        sys_prompt = LORA_SKILLS[self._current_skill()]["system_prompt"]
        sys_tokens = estimate_tokens(sys_prompt)
        user_tokens = estimate_tokens(user_input)

        # 裁剪历史
        history = []
        hist_tokens = 0
        for msg in reversed(self.history[-10:]):
            t = estimate_tokens(msg["content"])
            if hist_tokens + t + sys_tokens + user_tokens + RESERVE_TOKENS > N_CTX:
                break
            history.insert(0, msg)
            hist_tokens += t

        messages = [{"role": "system", "content": sys_prompt}]
        messages.extend(history)
        messages.append({"role": "user", "content": user_input})
        return messages

    def _current_skill(self) -> str:
        for k, v in LORA_SKILLS.items():
            if v["adapter"] == self.current_adapter:
                return k
        return "meta_constitution"

    def local_infer(self, user_input: str) -> str:
        """本地llama_cpp推理"""
        messages = self._build_messages(user_input)
        body = {
            "model": "local",
            "messages": messages,
            "max_tokens": MAX_NEW_TOKENS,
            "temperature": TEMPERATURE
        }
        try:
            r = requests.post(LOCAL_LLM, json=body, timeout=30)
            if r.status_code == 200:
                return r.json()["choices"][0]["message"]["content"].strip()
        except Exception as e:
            print(f"[本地推理失败] {e}")
        return None

    def cloud_fallback(self, user_input: str) -> str:
        """云端ark兜底"""
        body = {
            "model": ARK_MODEL,
            "messages": [{"role": "user", "content": user_input}],
            "max_tokens": 500,
            "temperature": 0.3
        }
        try:
            r = requests.post(CLOUD_ARK, json=body,
                              headers={"Authorization": f"Bearer {ARK_KEY}"},
                              timeout=30)
            if r.status_code == 200:
                return r.json()["choices"][0]["message"]["content"].strip()
        except Exception as e:
            print(f"[云端兜底失败] {e}")
        return "[ERROR] 本地和云端均不可用"

    def run(self, skill: str, user_input: str) -> str:
        """完整闭环：切技能→本地推理→失败路由云端→记录历史"""
        self.set_skill(skill)
        result = self.local_infer(user_input)
        if not result:
            print("[路由] 本地失败，切云端")
            result = self.cloud_fallback(user_input)
        self.history.append({"role": "user", "content": user_input})
        self.history.append({"role": "assistant", "content": result})
        return result


if __name__ == "__main__":
    agent = KernelLoraAgent()
    # 测试：用extract_truth技能
    r = agent.run("extract_truth", "把这句话提炼成种子：系统应该在资源不足时自动降级")
    print(f"输出: {r}")
