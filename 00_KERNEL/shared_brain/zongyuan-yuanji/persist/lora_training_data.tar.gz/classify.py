#!/usr/bin/env python3
"""把种子按5个LoRA技能包分类"""
import json
from pathlib import Path

BASE = Path("/home/user/Doubao/chats/38444214541567234/lora_skills")

# 分类规则：seed_id前缀 → 技能包
def classify(sid: str) -> str:
    s = sid.upper()
    # 元宪法/哲学
    if s.startswith("PHI") or "CONSTITUTION" in s or "AXIOM" in s or s.startswith("L0-ISO") or s.startswith("L0-FIVE") or s.startswith("L0-HILBERT") or s.startswith("L0-ROM"):
        return "meta_constitution"
    # 任务路由/工单调度
    if s.startswith("L0-WO") or s.startswith("L0-PRIORITY") or s.startswith("L0-QUEUE") or s.startswith("L0-PREALLOC") or s.startswith("L0-RESUME") or s.startswith("L0-ACCEPT") or s.startswith("L0-RETRY") or s.startswith("L0-COST") or s.startswith("L0-DISPATCH") or s.startswith("L0-ARCHIVE") or "WORKORDER" in s or s.startswith("L0-DAL"):
        return "task_router"
    # 自检/安全/巡检
    if s.startswith("L0-INTRUSION") or s.startswith("L0-HIGH-RISK") or s.startswith("L0-INSPECT") or s.startswith("L0-MONITOR") or s.startswith("L0-QUOTA") or s.startswith("L0-FUSE") or s.startswith("L0-DETECT") or s.startswith("L0-OOM") or "SECURITY" in s or "ARBITER" in s:
        return "self_check"
    # 真值抽取/能力数据
    if s.startswith("L0-CAP") or s.startswith("CAP") or s.startswith("L0-ASK") or s.startswith("L0-SAMPLE") or s.startswith("L0-AUTO") or s.startswith("L0-EXTRACT") or "CAPABILITY" in s or "DISTILL" in s:
        return "extract_truth"
    # 归档锁档/记忆网关
    if s.startswith("L0-MG") or s.startswith("L0-MEMORY") or s.startswith("L0-SNAPSHOT") or s.startswith("L0-LOCK") or s.startswith("L0-BUFFER") or s.startswith("L0-REPORT") or "GATEWAY" in s or "MEMORY" in s:
        return "archive"
    # 默认：元宪法
    return "meta_constitution"

buckets = {k: [] for k in ["meta_constitution", "task_router", "self_check", "extract_truth", "archive"]}

with open(BASE / "seed_all.jsonl") as f:
    for line in f:
        try:
            s = json.loads(line)
            cat = classify(s["seed_id"])
            buckets[cat].append(s)
        except: pass

for cat, seeds in buckets.items():
    out = BASE / cat / "train.jsonl"
    with open(out, "w") as f:
        for s in seeds:
            f.write(json.dumps(s, ensure_ascii=False) + "\n")
    print(f"{cat}: {len(seeds)} 条 → {out}")
