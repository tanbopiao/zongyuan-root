# ZONGYUAN 微模型 LoRA 技能包

## 架构

```
元内核调度（云端wrapper.py）
    ↓
KernelLoraAgent（控制适配器层）
    ├── 1. token计数 + 上下文裁剪（n_ctx=2048）
    ├── 2. LoRA热切换（5个技能包）
    └── 3. 本地推理失败 → 云端ark兜底
    ↓
INT4 基座（Qwen2.5-1.5B q4_k_m，n_ctx=2048）
```

## 5个技能包

| 技能包 | 条数 | 用途 |
|---|---|---|
| meta_constitution | 255 | 元宪法对齐、真值判定、合规护栏 |
| task_router | 13 | 工单优先级、资源调度、路由决策 |
| self_check | 5 | 自检、安全裁决、异常识别 |
| extract_truth | 16 | 从文本提炼种子真值 |
| archive | 11 | 锁档格式化、审计记录 |

## 文件

- `classify.py` — 种子分类脚本
- `kernel_lora_agent.py` — 微模型控制适配器（token计数+LoRA切换+云端兜底）
- `*/train.jsonl` — 各技能包训练数据

## 下一步

1. 在魔搭免费GPU上分别训练5个LoRA（r=8，每个~5MB）
2. 云端部署1个最常用的（extract_truth），其他下发本地
3. kernel_lora_agent.py 接入wrapper.py路由
