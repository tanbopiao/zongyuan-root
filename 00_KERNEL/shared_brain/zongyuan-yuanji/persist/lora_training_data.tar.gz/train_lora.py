#!/usr/bin/env python3
"""
LoRA训练脚本 — 在魔搭免费GPU实例上运行
用法: python3 train_lora.py <skill_name>
skill_name: meta_constitution / task_router / self_check / extract_truth / archive
"""
import sys, json, os
from pathlib import Path

SKILL = sys.argv[1] if len(sys.argv) > 1 else "extract_truth"
DATA_FILE = f"/root/lora_data/{SKILL}/train.jsonl"
OUTPUT_DIR = f"/root/output/lora_{SKILL}"

# 训练超参
CONFIG = {
    "model_name": "Qwen/Qwen2.5-1.5B-Instruct",
    "lora_r": 8,
    "lora_alpha": 16,
    "lora_dropout": 0.05,
    "epochs": 3,
    "batch_size": 4,
    "learning_rate": 2e-4,
    "max_seq_length": 512,
}

def load_data():
    data = []
    with open(DATA_FILE) as f:
        for line in f:
            s = json.loads(line)
            # 转成chat格式
            text = f"<|im_start|>system\n{s['system_prompt']}<|im_end|>\n<|im_start|>user\n{s['user_prompt']}<|im_end|>\n<|im_start|>assistant\n{s['response']}<|im_end|>"
            data.append({"text": text})
    return data

def main():
    print(f"=== 训练 LoRA: {SKILL} ===")
    data = load_data()
    print(f"数据量: {len(data)} 条")
    print(f"配置: {CONFIG}")

    # 检查GPU
    os.system("nvidia-smi 2>/dev/null || echo '无GPU，用CPU慢速训练'")

    # 实际训练（需要transformers+peft+trl）
    print("\n在魔搭GPU实例上执行:")
    print(f"  pip install transformers peft trl datasets torch -q")
    print(f"  python3 train_lora.py {SKILL}")
    print(f"\n输出: {OUTPUT_DIR}/adapter_model.safetensors (~4-5MB)")

if __name__ == "__main__":
    main()
