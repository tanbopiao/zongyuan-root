#!/bin/bash
# 政务AI中台4服务部署脚本
# DID-BR-000002 | Ω₀⊂⊙∞⊂Ω
set -e

DEPLOY_DIR="/opt/gov_mid_platform"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== 政务AI中台部署 ==="

# 1. 创建目录
mkdir -p "$DEPLOY_DIR/operators"
mkdir -p "$DEPLOY_DIR/logs"
mkdir -p "$DEPLOY_DIR/audit_data"

# 2. 复制算子文件
cp "$SCRIPT_DIR/operators/"*.py "$DEPLOY_DIR/operators/"
chmod +x "$DEPLOY_DIR/operators/"*.py
echo "✅ 算子文件已复制"

# 3. 安装systemd服务
cp "$SCRIPT_DIR/systemd/"*.service /etc/systemd/system/
systemctl daemon-reload
echo "✅ systemd服务已安装"

# 4. 启动服务（按依赖顺序：审计→算子→网关→大屏）
echo "🔄 启动服务..."
systemctl enable gov-audit gov-operator-cluster gov-gateway gov-dashboard
systemctl start gov-audit
sleep 1
systemctl start gov-operator-cluster
sleep 1
systemctl start gov-gateway
sleep 1
systemctl start gov-dashboard
sleep 2

# 5. 健康检查
echo "🔍 健康检查..."
for port in 8202 8201 8200 8203; do
    if curl -s -m 3 "http://127.0.0.1:$port/health" > /dev/null 2>&1; then
        echo "  ✅ 端口 $port 正常"
    else
        echo "  ⚠️  端口 $port 未响应（检查日志: journalctl -u gov-*）"
    fi
done

echo ""
echo "✅ 政务AI中台部署完成！"
echo "   8200 网关: http://127.0.0.1:8200/health"
echo "   8201 算子: http://127.0.0.1:8201/health"
echo "   8202 审计: http://127.0.0.1:8202/health"
echo "   8203 大屏: http://127.0.0.1:8203/health"
echo ""
echo "   管理命令:"
echo "     systemctl status gov-audit gov-operator-cluster gov-gateway gov-dashboard"
echo "     journalctl -u gov-* -f"
