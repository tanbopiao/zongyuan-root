#!/bin/bash
# ZONGYUAN-ROOT 记忆网关生产级优化 V2.0
# DID-BR-000002 | Ω₀⊂⊙∞⊂Ω
# 基于全网搜索最佳实践：WAL+连接池+进程守护+Nginx调优
set -e

GATEWAY_DIR="/opt/ZONGYUAN-ROOT/gateway"
BACKUP_DIR="/opt/ZONGYUAN-ROOT/backup/gateway_$(date +%Y%m%d_%H%M%S)"

echo "====================================="
echo "记忆网关生产级优化 V2.0"
echo "====================================="

# 0. 备份当前配置
echo "[0/6] 备份当前网关配置..."
if [ -d "$GATEWAY_DIR" ]; then
    mkdir -p "$BACKUP_DIR"
    cp -r "$GATEWAY_DIR"/* "$BACKUP_DIR/" 2>/dev/null || true
    echo "  ✅ 已备份到 $BACKUP_DIR"
fi

# 1. SQLite WAL模式优化
echo "[1/6] SQLite WAL模式优化..."
cat > /tmp/wal_optimize.py << 'PYEOF'
import sqlite3, os, glob
db_paths = glob.glob("/opt/ZONGYUAN-ROOT/**/*.db", recursive=True) + \
           glob.glob("/opt/ZONGYUAN-ROOT/**/*.sqlite*", recursive=True)
for db in db_paths:
    try:
        conn = sqlite3.connect(db)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA wal_autocheckpoint=1000")
        conn.execute("PRAGMA cache_size=-64000")  # 64MB缓存
        conn.execute("PRAGMA temp_store=MEMORY")
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        conn.close()
        print(f"  ✅ {os.path.basename(db)}: {mode}模式")
    except Exception as e:
        print(f"  ⚠️ {os.path.basename(db)}: {e}")
PYEOF
python3 /tmp/wal_optimize.py

# 2. 进程守护（systemd）
echo "[2/6] 配置systemd进程守护..."
cat > /etc/systemd/system/zr-gateway.service << 'EOF'
[Unit]
Description=ZONGYUAN-ROOT Memory Gateway
After=network.target
StartLimitIntervalSec=60
StartLimitBurst=5

[Service]
Type=simple
User=root
WorkingDirectory=/opt/ZONGYUAN-ROOT/gateway
ExecStart=/usr/bin/python3 /opt/ZONGYUAN-ROOT/gateway/gateway_server.py
Restart=always
RestartSec=3
Environment=PYTHONUNBUFFERED=1
Environment=ZR_WAL_MODE=1
Environment=ZR_CONNECTION_POOL=8
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable zr-gateway 2>/dev/null || true
echo "  ✅ systemd服务已配置（自动重启，3秒间隔，5次/分钟上限）"

# 3. Nginx调优
echo "[3/6] Nginx调优..."
if [ -f /www/server/nginx/conf/nginx.conf ]; then
    # 备份
    cp /www/server/nginx/conf/nginx.conf /www/server/nginx/conf/nginx.conf.bak.$(date +%Y%m%d)
    # 调整worker和超时
    sed -i 's/worker_connections .*/worker_connections 4096;/' /www/server/nginx/conf/nginx.conf
    # 在http块添加网关专用配置
    grep -q "zr-gateway-upstream" /www/server/nginx/conf/nginx.conf || cat >> /www/server/nginx/conf/nginx.conf << 'NGINXEOF'

# ZR Gateway优化
upstream zr-gateway-upstream {
    server 127.0.0.1:9120 max_fails=3 fail_timeout=10s;
    keepalive 32;
}
proxy_connect_timeout 10s;
proxy_read_timeout 30s;
proxy_send_timeout 10s;
NGINXEOF
    nginx -t 2>/dev/null && echo "  ✅ Nginx配置已更新" || echo "  ⚠️ Nginx配置测试失败，已保留备份"
fi

# 4. 连接池配置
echo "[4/6] 生成连接池配置..."
cat > /opt/ZONGYUAN-ROOT/gateway/db_pool_config.json << 'EOF'
{
  "pool_size": 8,
  "max_overflow": 16,
  "pool_timeout": 30,
  "pool_recycle": 1800,
  "wal_mode": true,
  "synchronous": "NORMAL",
  "cache_size_mb": 64,
  "busy_timeout_ms": 5000
}
EOF
echo "  ✅ 连接池配置: 8连接+16溢出, WAL模式, 64MB缓存"

# 5. 健康检查端点
echo "[5/6] 配置健康检查..."
cat > /opt/ZONGYUAN-ROOT/gateway/health_check.sh << 'HEALTHEOF'
#!/bin/bash
STATUS=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 http://127.0.0.1:9120/api/report/status)
if [ "$STATUS" != "200" ]; then
    echo "$(date): Gateway unhealthy (HTTP $STATUS), restarting..."
    systemctl restart zr-gateway
    logger -t zr-gateway "Auto-restart triggered: HTTP $STATUS"
fi
HEALTHEOF
chmod +x /opt/ZONGYUAN-ROOT/gateway/health_check.sh
# 每30秒健康检查
(crontab -l 2>/dev/null | grep -v "zr-gateway/health_check"; echo "* * * * * /opt/ZONGYUAN-ROOT/gateway/health_check.sh") | crontab -
echo "  ✅ 健康检查已配置（每分钟检测，异常自动重启）"

# 6. 重启网关
echo "[6/6] 重启网关服务..."
systemctl restart zr-gateway 2>/dev/null || echo "  ⚠️ 请手动重启网关"
sleep 2
STATUS=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 http://127.0.0.1:9120/api/report/status 2>/dev/null || echo "000")
echo "  网关状态: HTTP $STATUS"

echo ""
echo "====================================="
echo "✅ 记忆网关生产级优化 V2.0 完成"
echo "优化项: WAL模式 + 连接池 + systemd守护 + Nginx调优 + 健康检查"
echo "备份: $BACKUP_DIR"
echo "====================================="
