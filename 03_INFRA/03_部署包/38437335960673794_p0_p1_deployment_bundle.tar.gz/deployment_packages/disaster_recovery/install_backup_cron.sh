#!/bin/bash
# 安装容灾备份定时任务
cp zr_backup.sh /opt/ZONGYUAN-ROOT/backups/zr_backup.sh
chmod +x /opt/ZONGYUAN-ROOT/backups/zr_backup.sh
mkdir -p /opt/ZONGYUAN-ROOT/backups
# 每天凌晨3点执行备份
(crontab -l 2>/dev/null | grep -v "zr_backup.sh"; echo "0 3 * * * /opt/ZONGYUAN-ROOT/backups/zr_backup.sh >> /var/log/zr_backup.log 2>&1") | crontab -
echo "✅ 容灾备份已安装，每天03:00自动执行"
echo "   手动执行: /opt/ZONGYUAN-ROOT/backups/zr_backup.sh"
