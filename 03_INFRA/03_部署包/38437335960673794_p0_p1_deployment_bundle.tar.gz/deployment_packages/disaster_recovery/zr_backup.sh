#!/bin/bash
# ZONGYUAN-ROOT 异地容灾备份 V1.0
# DID-BR-000002 | Ω₀⊂⊙∞⊂Ω
# 功能：定时快照 + AES加密 + 多副本 + 完整性校验
set -e

BACKUP_ROOT="/opt/ZONGYUAN-ROOT/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="$BACKUP_ROOT/$TIMESTAMP"
RETENTION_DAYS=7
ENCRYPTION_KEY="${ZR_BACKUP_KEY:-ZONGYUAN-ROOT-DEFAULT-KEY-CHANGE-ME}"

echo "====================================="
echo "ZONGYUAN-ROOT 容灾备份 $TIMESTAMP"
echo "====================================="

# 1. 创建备份目录
mkdir -p "$BACKUP_DIR"

# 2. 备份核心数据
echo "[1/5] 备份核心数据..."
# 内核状态
cp -r ~/.zongyuan_root/ "$BACKUP_DIR/kernel/" 2>/dev/null || true
# 根状态
cp -r ~/.meta_order/ "$BACKUP_DIR/meta_order/" 2>/dev/null || true
# 网关数据
cp -r /opt/ZONGYUAN-ROOT/gateway/ "$BACKUP_DIR/gateway/" 2>/dev/null || true
# 知识图谱
cp -r ~/.zongyuan_root/knowledge_graph/ "$BACKUP_DIR/knowledge_graph/" 2>/dev/null || true
# 态元数据库
cp ~/.zongyuan_root/state_atoms.db "$BACKUP_DIR/" 2>/dev/null || true
# 配置文件
cp -r /etc/zr/ "$BACKUP_DIR/config/" 2>/dev/null || true

# 3. 生成清单和哈希
echo "[2/5] 生成完整性校验..."
find "$BACKUP_DIR" -type f -exec sha256sum {} \; > "$BACKUP_DIR/MANIFEST.sha256"
TOTAL_FILES=$(find "$BACKUP_DIR" -type f | wc -l)
TOTAL_SIZE=$(du -sh "$BACKUP_DIR" | cut -f1)
echo "  文件数: $TOTAL_FILES, 大小: $TOTAL_SIZE"

# 4. 加密备份
echo "[3/5] AES-256加密..."
tar czf - -C "$BACKUP_ROOT" "$TIMESTAMP" 2>/dev/null | \
    openssl enc -aes-256-cbc -salt -pbkdf2 -pass "pass:$ENCRYPTION_KEY" \
    -out "$BACKUP_ROOT/zr_backup_${TIMESTAMP}.tar.gz.enc" 2>/dev/null
BACKUP_HASH=$(sha256sum "$BACKUP_ROOT/zr_backup_${TIMESTAMP}.tar.gz.enc" | cut -d' ' -f1)
echo "  加密备份: zr_backup_${TIMESTAMP}.tar.gz.enc"
echo "  SHA256: $BACKUP_HASH"

# 5. 多副本（本地+飞书云盘）
echo "[4/5] 多副本同步..."
# 本地副本
cp "$BACKUP_ROOT/zr_backup_${TIMESTAMP}.tar.gz.enc" "$BACKUP_ROOT/latest.enc"
# 飞书云盘上传（如果lark-cli可用）
if command -v lark-cli &> /dev/null; then
    lark-cli drive +upload --file "$BACKUP_ROOT/zr_backup_${TIMESTAMP}.tar.gz.enc" 2>/dev/null && \
        echo "  ✅ 已上传飞书云盘" || echo "  ⚠️ 飞书云盘上传失败"
else
    echo "  ⚠️ lark-cli不可用，跳过云盘上传"
fi

# 6. 清理过期备份
echo "[5/5] 清理过期备份（保留${RETENTION_DAYS}天）..."
find "$BACKUP_ROOT" -name "zr_backup_*.tar.gz.enc" -mtime +$RETENTION_DAYS -delete 2>/dev/null || true
find "$BACKUP_ROOT" -mindepth 1 -maxdepth 1 -type d -mtime +$RETENTION_DAYS -exec rm -rf {} \; 2>/dev/null || true
echo "  ✅ 清理完成"

# 7. 输出备份元数据
cat > "$BACKUP_ROOT/backup_meta.json" << EOF
{
  "backup_id": "ZR-BACKUP-$TIMESTAMP",
  "timestamp": "$(date -Iseconds)",
  "files": $TOTAL_FILES,
  "size": "$TOTAL_SIZE",
  "encryption": "AES-256-CBC",
  "sha256": "$BACKUP_HASH",
  "retention_days": $RETENTION_DAYS,
  "did": "DID-BR-000002",
  "trace": "Ω₀⊂⊙∞⊂Ω"
}
EOF

echo ""
echo "====================================="
echo "✅ 容灾备份完成"
echo "备份ID: ZR-BACKUP-$TIMESTAMP"
echo "文件数: $TOTAL_FILES | 大小: $TOTAL_SIZE"
echo "加密: AES-256-CBC | SHA256: ${BACKUP_HASH:0:16}..."
echo "====================================="
