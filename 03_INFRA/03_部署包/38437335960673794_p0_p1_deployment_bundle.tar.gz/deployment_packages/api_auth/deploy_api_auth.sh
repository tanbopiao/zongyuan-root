#!/bin/bash
# API鉴权中间件部署脚本
# DID-BR-000002 | Ω₀⊂⊙∞⊂Ω
set -e

echo "====================================="
echo "ZONGYUAN-ROOT API鉴权中间件部署"
echo "====================================="

# 1. 创建目录
mkdir -p /opt/ZONGYUAN-ROOT/auth
mkdir -p /etc/zr
mkdir -p /var/log

# 2. 部署中间件
cp auth_middleware.py /opt/ZONGYUAN-ROOT/auth/
chmod +x /opt/ZONGYUAN-ROOT/auth/auth_middleware.py

# 3. 生成初始Token
if [ ! -f /etc/zr/tokens.json ]; then
    TOKEN=$(head -c 32 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | head -c 48)
    cat > /etc/zr/tokens.json << EOF
{
  "tokens": [
    {
      "token": "$TOKEN",
      "name": "default-admin",
      "created": "$(date -Iseconds)",
      "active": true,
      "scope": "full"
    }
  ]
}
EOF
    echo "✅ 初始Token已生成: $TOKEN"
    echo "   请妥善保存，后续API调用需在Header中携带: X-Capture-Token: $TOKEN"
else
    echo "✅ Token配置已存在，跳过生成"
fi

# 4. 配置环境变量
grep -q "ZR_API_TOKEN" /etc/environment 2>/dev/null || echo "ZR_API_TOKEN=$(grep -o '"token": "[^"]*"' /etc/zr/tokens.json | head -1 | cut -d'"' -f4)" >> /etc/environment

# 5. 验证安装
python3 /opt/ZONGYUAN-ROOT/auth/auth_middleware.py

echo ""
echo "====================================="
echo "✅ API鉴权中间件部署完成"
echo "路径: /opt/ZONGYUAN-ROOT/auth/auth_middleware.py"
echo "Token配置: /etc/zr/tokens.json"
echo "审计日志: /var/log/zr_api_audit.log"
echo "====================================="
