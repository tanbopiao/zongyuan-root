#!/usr/bin/env python3
"""
ZONGYUAN-ROOT 云端守护代理
7×24常驻运行：定时巡检+读任务台账+上报真值+心跳
DID: DID-BR-000002
"""
import requests, json, time, os
from datetime import datetime

GATEWAY = "https://www.huodouai.com/api/report/truth"
CAPTURE_TOKEN = "ZR-CAPTURE-2026-OMEGA-d04bb54ba2a55a7d"
NODE_ID = "NODE-DEV-CLOUD-DAEMON-001"
CHECK_INTERVAL = 1800  # 30分钟巡检一次（最小消耗）

def report_truth(truth_key, truth_value, truth_type="data"):
    """上报真值到记忆网关"""
    try:
        r = requests.post(GATEWAY,
            headers={"Content-Type": "application/json", "X-Capture-Token": CAPTURE_TOKEN},
            json={
                "truth_key": truth_key,
                "truth_value": truth_value,
                "source_node": NODE_ID,
                "confidence": 1.0,
                "truth_type": truth_type
            }, timeout=10)
        return r.json().get("success", False)
    except Exception as e:
        print(f"[{datetime.now()}] 上报失败: {e}")
        return False

def heartbeat():
    """发送心跳"""
    return report_truth(
        f"HEARTBEAT.{NODE_ID}.{datetime.now().strftime('%Y%m%d%H')}",
        f"心跳正常 {datetime.now().isoformat()}",
        "data"
    )

def health_check():
    """健康检查：网关连通性"""
    try:
        r = requests.get("https://www.huodouai.com/api/report/status", timeout=5)
        data = r.json()
        return f"网关正常, 真值数: {data['stats']['truths']}"
    except Exception as e:
        return f"网关异常: {e}"

def run_loop():
    """主循环"""
    print(f"[{datetime.now()}] ZONGYUAN-ROOT云端守护代理启动")
    print(f"节点: {NODE_ID}")
    print(f"巡检间隔: {CHECK_INTERVAL}秒")
    print("=" * 50)
    
    # 启动心跳
    heartbeat()
    
    loop_count = 0
    while True:
        loop_count += 1
        now = datetime.now()
        
        # 健康检查
        status = health_check()
        print(f"[{now}] 第{loop_count}轮巡检: {status}")
        
        # 每4次循环上报一次（2小时一次完整上报）
        if loop_count % 4 == 0:
            report_truth(
                f"DAEMON.HEALTH.{NODE_ID}.{now.strftime('%Y%m%d%H%M')}",
                f"守护代理运行正常, 第{loop_count}轮, {status}",
                "data"
            )
            print(f"  → 已上报巡检状态")
        
        time.sleep(CHECK_INTERVAL)

if __name__ == "__main__":
    run_loop()
