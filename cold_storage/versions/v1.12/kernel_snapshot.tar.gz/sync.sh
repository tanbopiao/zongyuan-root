#!/bin/bash
# ZONGYUAN-ROOT 分级双向同步
# 上行(沙箱→云端): 只推L0核心+L1高价值，不推低价值日志/历史
# 下行(云端→沙箱): 拉云端低价值资产到本地存档
set -e
PERSIST=/home/user/ZONGYUAN-ROOT/persist_snapshot
ZK_REMOTE=/opt/zongyuan-kernel
REMOTE=root@123.207.202.158
KEY=~/.ssh/zongyuan_new

echo "=== 分级双向同步 ==="

# ===== 上行：L0核心 + L1高价值 =====
echo "[上行] L0核心 + L1高价值 → 云端"
# 打包：内核代码 + 高价值状态 + 自解压包
tar czf /tmp/zy_up.tar.gz \
  -C /home/user/ZONGYUAN-ROOT/deploy . \
  -C $PERSIST L1_highvalue \
  -C $PERSIST zongyuan_bootstrap.run 2>/dev/null
scp -i $KEY -o StrictHostKeyChecking=no /tmp/zy_up.tar.gz $REMOTE:/tmp/ 2>/dev/null
ssh -i $KEY -o StrictHostKeyChecking=no $REMOTE "
  # 解除不可变
  chattr -i $ZK_REMOTE/kernel/main.py $ZK_REMOTE/operators/*.py $ZK_REMOTE/api/*.py \
    $ZK_REMOTE/services/local/*.py $ZK_REMOTE/meta_truth/persist/*.json \
    $ZK_REMOTE/meta_truth/boot/*.json $ZK_REMOTE/config.json 2>/dev/null || true
  # 解压内核代码
  tar xzf /tmp/zy_up.tar.gz -C $ZK_REMOTE kernel operators api services meta_truth engine *.sh config.json 2>/dev/null || true
  # 解压高价值状态
  mkdir -p $ZK_REMOTE/L1_highvalue
  tar xzf /tmp/zy_up.tar.gz -C $ZK_REMOTE L1_highvalue 2>/dev/null || true
  # 重新不可变
  chattr +i $ZK_REMOTE/kernel/main.py $ZK_REMOTE/operators/*.py $ZK_REMOTE/api/*.py \
    $ZK_REMOTE/services/local/*.py $ZK_REMOTE/meta_truth/persist/*.json \
    $ZK_REMOTE/meta_truth/boot/*.json $ZK_REMOTE/config.json 2>/dev/null || true
  # 更新哈希清单
  sha256sum $ZK_REMOTE/kernel/main.py $ZK_REMOTE/operators/*.py $ZK_REMOTE/api/*.py \
    $ZK_REMOTE/services/local/*.py $ZK_REMOTE/meta_truth/persist/*.json \
    $ZK_REMOTE/meta_truth/boot/*.json $ZK_REMOTE/config.json 2>/dev/null | sort -k2 > $ZK_REMOTE/var/LOCKDOWN_MANIFEST.txt
  # 重启服务
  systemctl restart zongyuan-kernel zongyuan-api zongyuan-metrics 2>/dev/null
  echo '  ✅ 云端已更新'
"
echo "  ✅ 上行完成（仅L0+L1）"

# ===== 下行：云端低价值 → 本地存档 =====
echo "[下行] 云端低价值 → 本地存档"
mkdir -p $PERSIST/L2_archive/cloud_logs $PERSIST/L3_history/cloud_operations
# 拉云端日志
scp -i $KEY -o StrictHostKeyChecking=no $REMOTE:$ZK_REMOTE/logs/*.log $PERSIST/L2_archive/cloud_logs/ 2>/dev/null || true
# 拉云端心跳/状态历史
scp -i $KEY -o StrictHostKeyChecking=no $REMOTE:$ZK_REMOTE/var/heartbeat.json $PERSIST/L1_highvalue/cloud_heartbeat_latest.json 2>/dev/null || true
scp -i $KEY -o StrictHostKeyChecking=no $REMOTE:$ZK_REMOTE/var/operator_health.json $PERSIST/L1_highvalue/cloud_operator_health.json 2>/dev/null || true
echo "  ✅ 下行完成（云端日志→本地存档）"

echo ""
echo "=== 同步完成 ==="
echo "上行(→云端): L0核心 + L1高价值（省云端空间）"
echo "下行(→本地): 云端日志 + 状态（本地存档）"
echo "本地持久层: $(du -sh $PERSIST | cut -f1)"
