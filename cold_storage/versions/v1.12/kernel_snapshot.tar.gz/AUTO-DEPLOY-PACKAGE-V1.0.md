# ZONGYUAN-ROOT 全自动部署包 V1.0

> DID: DID-BR-000002 | Ω₀⊂⊙∞⊂Ω
> 版本: V1.0 | 状态: 待飞书审批后部署

---

## 部署包内容

| 文件 | 作用 |
|------|------|
| daemon_agent.py | 7×24守护代理主程序 |
| install.sh | 一键部署脚本（systemd托管） |
| auto_deploy_api.py | 自动部署API核心 |
| test_auto_deploy.py | 部署API仿真测试 |
| DEPLOY-GUIDE.md | 部署+回滚指南 |
| TEST-AUTO-DEPLOY-API-V1.0.md | 测试报告 |

---

## 部署步骤（审批通过后执行）

```bash
# 1. 拉取最新代码
cd /opt/ZONGYUAN-ROOT && git pull origin main

# 2. 一键部署守护代理
bash deploy/install.sh

# 3. 验证服务状态
systemctl status zongyuan-daemon
```

---

## 部署效果

- 7×24自动巡检（每30分钟）
- 自动上报心跳到记忆网关
- 服务挂了自动重启
- 对现有官网零影响

---

## 资源占用

| 项目 | 预估 |
|------|------|
| CPU | <5% |
| 内存 | ~50MB |
| 月流量 | <10MB |

---

## 回滚方案

```bash
systemctl stop zongyuan-daemon
systemctl disable zongyuan-daemon
rm /etc/systemd/system/zongyuan-daemon.service
systemctl daemon-reload
```

---

## 审批状态

- [x] 部署包开发完成
- [x] 仿真测试 6/6 通过
- [x] 上报记忆网关
- [x] 写入飞书任务台账
- [ ] 飞书审批（待发起）
- [ ] 云服务器部署执行
- [ ] 部署后验证

---

Ω₀⊂⊙∞⊂Ω | DID-BR-000002
