#!/bin/bash
# ZONGYUAN-ROOT 自举启动脚本 V1.0
# 用法: bash /opt/ZONGYUAN-ROOT/deploy/approved/bootstrap-v1.0/bootstrap.sh
# 作用: 拉代码 → 起Worker消费进程 → 自检 → 闭环自转
set -e
cd /opt/ZONGYUAN-ROOT
git config gc.auto 0
git fetch origin main
(git checkout main && git merge origin/main) || git checkout -B main origin/main
# 起消费进程(幂等)
if ! pgrep -f cloud_worker_consumer.py >/dev/null; then
  nohup python3 deploy/approved/cloud-worker-consumer-v1.0/cloud_worker_consumer.py --loop 60 >> /var/log/cloud_worker.log 2>&1 &
  echo "✅ Worker 已启动 pid=$!"
else
  echo "ℹ️ Worker 已在运行"
fi
sleep 2
# 自检
echo "=== 自检 ==="
pgrep -f cloud_worker_consumer.py && echo "✅ 进程存活"
tail -5 /var/log/cloud_worker.log 2>/dev/null || echo "(日志待生成)"
