#!/bin/bash
# 云端Worker消费脚本：拉工单→强制准入→安装→健康检查→失败自动回滚
set -e
WK=/opt/ZONGYUAN-ROOT/worker
mkdir -p $WK

# 1. 写入Worker消费脚本
cat > $WK/consumer.sh << 'SCRIPT'
#!/bin/bash
# Worker主循环：拉工单→执行→强制准入→健康检查→失败回滚
GATEWAY="https://www.huodouai.com/api/report/truth"
TOKEN="ZR-CAPTURE-2026-OMEGA-d04bb54ba2a55a7d"
LOG=/var/log/zb-worker.log

report() {
  curl -s -X POST $GATEWAY -H "Content-Type: application/json" -H "X-Capture-Token: $TOKEN" \
    -d "{\"truth_key\":\"$1\",\"truth_value\":\"$2\",\"source_node\":\"hub-central-agent\",\"confidence\":1.0,\"truth_type\":\"data\"}"
}

consume() {
  # 拉待执行工单（CMD.*）——网关GET端点502，这里用占位：实际工单由install时手动git pull最新包
  cd /opt/ZONGYUAN-ROOT
  git pull --rebase origin main >> $LOG 2>&1
  
  # 遍历approved包，找未部署的
  for d in deploy/approved/*/; do
    [ ! -f "$d/install.sh" ] && continue
    NAME=$(basename $d)
    MARK="/opt/ZONGYUAN-ROOT/worker/.deployed_$NAME"
    [ -f "$MARK" ] && continue  # 已部署
    
    echo "[$(date)] 部署 $NAME" >> $LOG
    
    # === 强制准入检查 ===
    if [ -f scripts/pre_deploy_check.sh ]; then
      bash scripts/pre_deploy_check.sh "$d" >> $LOG 2>&1 || {
        report "RESULT.$NAME" "准入不通过,拒绝自动部署"
        touch "$MARK.denied"
        continue
      }
    fi
    
    # === 执行安装 ===
    bash "$d/install.sh" >> $LOG 2>&1 || {
      report "RESULT.$NAME" "install.sh失败"
      [ -f "$d/rollback.sh" ] && bash "$d/rollback.sh" >> $LOG 2>&1
      touch "$MARK.failed"
      continue
    }
    
    # === 健康检查 ===
    if [ -f "$d/health_check.sh" ]; then
      bash "$d/health_check.sh" >> $LOG 2>&1 || {
        report "RESULT.$NAME" "健康检查失败,自动回滚"
        bash "$d/rollback.sh" >> $LOG 2>&1
        touch "$MARK.rolledback"
        continue
      }
    fi
    
    report "RESULT.$NAME" "部署成功,健康检查通过"
    touch "$MARK"
  done
}

# 每60秒轮询一次
while true; do
  consume
  sleep 60
done
SCRIPT
chmod +x $WK/consumer.sh

# 2. 创建systemd服务
cat > /etc/systemd/system/zb-worker.service << UNIT
[Unit]
Description=ZONGYUAN-ROOT Worker Consumer
After=network.target
[Service]
Type=simple
ExecStart=/opt/ZONGYUAN-ROOT/worker/consumer.sh
Restart=always
RestartSec=10
[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable zb-worker
systemctl start zb-worker
echo "[1/3] Worker消费服务已启动"

# 3. 立即跑一次验收
bash $WK/consumer.sh &
sleep 3
systemctl is-active zb-worker && echo "[2/3] 服务active"
echo "[3/3] P0闭环部署完成"
