#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
云端Worker工单消费脚本 V1.0
DID-BR-000002 | Ω₀⊂⊙∞⊂Ω | ZONGYUAN-ROOT

职责: 轮询网关拉CMD.*工单 -> 安全白名单执行 -> 回写RESULT.* -> 标记已完成
原则: 纯标准库/只读网关/危险命令拒执/不碰核心架构

用法:
  python3 cloud_worker_consumer.py --dry-run    # 只看不跑(安全默认)
  python3 cloud_worker_consumer.py --once       # 拉一次并执行(白名单内)
  python3 cloud_worker_consumer.py --loop 60    # 每60秒轮询一次
"""
import json, urllib.request, subprocess, sys, os, time, re
from datetime import datetime, timezone, timedelta

GATEWAY = os.environ.get("GATEWAY", "https://www.huodouai.com/api")
TOKEN = os.environ.get("ZR_TOKEN", "ZR-CAPTURE-2026-OMEGA-d04bb54ba2a55a7d")
NODE = os.environ.get("WORKER_NODE", "cloud-worker-consumer")
TZ = timezone(timedelta(hours=8))

# 安全白名单: 只允许这些命令前缀执行
SAFE_PREFIX = ("cd ", "python3 ", "git ", "ls ", "cat ", "bash ", "python ")
# 黑名单: 任何含这些模式一律拒
DANGER = re.compile(r"(\brm\s+-rf\s+/|mkfs|dd\s+if=|:\(\)\{|shutdown|reboot|>\s*/dev/sd)")


def _get(path):
    req = urllib.request.Request(GATEWAY + path, headers={"X-Capture-Token": TOKEN})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


def _post(body):
    req = urllib.request.Request(GATEWAY + "/report/truth", data=json.dumps(body).encode(),
                                headers={"Content-Type": "application/json", "X-Capture-Token": TOKEN})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


def fetch_cmd_orders():
    """拉取待执行工单(按已知CMD前缀探测)"""
    orders = []
    # 目前网关按key精确读,这里轮询已知工单key
    known = [
        "CMD.DEPLOY.DIGESTION-V1.1",
        "CMD.REMIND.EXEC-DIGESTION",
    ]
    for k in known:
        try:
            d = _get(f"/truth/{k}")
            t = d.get("truth", d)
            if t and "执行" in (t.get("truth_value", "") or ""):
                orders.append({"key": k, "value": t.get("truth_value", "")})
        except Exception:
            pass
    return orders


def safe_check(cmd_text):
    """安全检查: 返回(ok, reason)"""
    lines = [l.strip() for l in cmd_text.splitlines() if l.strip() and not l.strip().startswith("#")]
    for l in lines:
        # 提取命令名
        m = re.match(r"cd\s+\S+\s*&&\s*(.*)", l)
        cmd = m.group(1) if m else l
        base = cmd.split()[0] if cmd.split() else ""
        if DANGER.search(l):
            return False, f"危险模式被拒: {l[:50]}"
        if not any(cmd.startswith(p) for p in SAFE_PREFIX):
            return False, f"非白名单命令: {base}"
    return True, "ok"


def extract_exec(cmd_text):
    """从工单文本提取实际命令行"""
    exec_lines = []
    for l in cmd_text.splitlines():
        l = l.strip()
        if l.startswith("cd ") or l.startswith("python") or l.startswith("git ") or l.startswith("bash "):
            exec_lines.append(l)
    return "\n".join(exec_lines)


def run_one(order, dry_run=True):
    key, value = order["key"], order["value"]
    cmd = extract_exec(value)
    ok, reason = safe_check(cmd)
    now = datetime.now(TZ).isoformat()
    if not ok:
        print(f"[安全拒绝] {key}: {reason}")
        return
    if dry_run:
        print(f"[DRY-RUN] {key}: 将执行: {cmd[:80]}")
        return
    print(f"[执行] {key}: {cmd[:80]}")
    try:
        r = subprocess.run(["bash", "-c", cmd], capture_output=True, text=True, timeout=120)
        out = (r.stdout or "")[-1500:]
        status = "OK" if r.returncode == 0 else f"EXIT{r.returncode}"
    except Exception as e:
        out = str(e)
        status = "ERROR"
    result_key = "RESULT." + key.split(".", 1)[1]
    try:
        _post({"truth_key": result_key, "truth_value": f"[{now}][{NODE}][{status}]\n{out}",
               "source_node": NODE, "confidence": 0.9, "truth_type": "data"})
        print(f"[回写] {result_key} {status}")
    except Exception as e:
        print(f"[回写失败] {e}")


def main():
    dry = "--dry-run" in sys.argv
    loop = 1
    for i, a in enumerate(sys.argv):
        if a == "--loop" and i + 1 < len(sys.argv):
            loop = int(sys.argv[i + 1])
    once = "--once" in sys.argv
    if not once and not dry:
        dry = True  # 安全默认
    rounds = 1 if once or dry else loop
    for _ in range(rounds):
        print(f"--- 轮询 {datetime.now(TZ).strftime('%H:%M:%S')} ---")
        orders = fetch_cmd_orders()
        print(f"  拉到工单 {len(orders)} 条")
        for o in orders:
            run_one(o, dry_run=dry)
        if loop and not once and not dry:
            time.sleep(loop)


if __name__ == "__main__":
    main()
