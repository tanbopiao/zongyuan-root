#!/bin/bash
# 云端Worker工单消费进程启动脚本 V1.0 (白名单内: bash start_worker.sh)
cd /opt/ZONGYUAN-ROOT
git config gc.auto 0
git fetch origin main
(git checkout main && git merge origin/main) || git checkout -B main origin/main
# 启动消费进程(每60秒轮询),已存在则不重复起
if ! pgrep -f cloud_worker_consumer.py >/dev/null; then
  nohup python3 deploy/approved/cloud-worker-consumer-v1.0/cloud_worker_consumer.py --loop 60 >> /var/log/cloud_worker.log 2>&1 &
  echo "worker started pid=$!"
else
  echo "worker already running"
fi
python3 deploy/approved/cloud-worker-consumer-v1.0/cloud_worker_consumer.py --dry-run
