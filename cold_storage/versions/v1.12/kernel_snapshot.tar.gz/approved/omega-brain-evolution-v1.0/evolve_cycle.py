#!/usr/bin/env python3
"""Ω-Brainμ 全自动推演进化闭环 V1.0"""
import json, urllib.request, time, subprocess, os

GATEWAY = "https://www.huodouai.com/api/report/truth"
TOKEN = "ZR-CAPTURE-2026-OMEGA-d04bb54ba2a55a7d"
BASE = "DgnMbLqZiaIUDKshqCrcD4DvnBg"

def report(key, value, ttype="data"):
    H = {"Content-Type":"application/json","X-Capture-Token":TOKEN}
    d = {"truth_key":key,"truth_value":value,"source_node":"NODE-DEV-DOUBAO-WORK-001",
         "confidence":0.95,"truth_type":ttype}
    r = urllib.request.Request(GATEWAY, data=json.dumps(d).encode(), headers=H)
    return json.loads(urllib.request.urlopen(r, timeout=12).read())

def score(benefit, risk, cost):
    """三维仲裁: 收益40% + 风险(反向)35% + 成本(反向)25%"""
    return benefit*0.40 + (1-risk)*0.35 + (1-cost)*0.25

def run_cycle():
    print("=== Ω-Brainμ 推演进化循环 ===")
    # 1. 仲裁演示：3个候选任务评分
    candidates = [
        ("真值消化管道优化", 0.9, 0.1, 0.2),
        ("GPU节点部署", 0.8, 0.6, 0.8),
        ("飞书台账整理", 0.6, 0.05, 0.1),
    ]
    ranked = sorted(candidates, key=lambda x: score(x[1],x[2],x[3]), reverse=True)
    print("仲裁结果:")
    for name,b,r,c in ranked:
        s = score(b,r,c)
        action = "立即执行" if s>=0.85 else ("本轮执行" if s>=0.7 else "放弃")
        print(f"  {name}: {s:.3f} → {action}")

    # 2. 上报本轮进化结果
    ts = time.strftime("%Y%m%d-%H")
    res = report(f"OMEGA-EVOLVE.{ts}",
        f"推演循环完成: 仲裁3任务,最优={ranked[0][0]}(score={score(*ranked[0][1:]):.3f}), 三维稳态仲裁生效。",
        "decision")
    print(f"中枢上报: {res.get('action')}")
    return ranked

if __name__ == "__main__":
    run_cycle()
