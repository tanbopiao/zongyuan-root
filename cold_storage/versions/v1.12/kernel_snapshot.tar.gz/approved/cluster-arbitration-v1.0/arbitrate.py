#!/usr/bin/env python3
"""云端中枢多智能集群仲裁引擎 V1.0"""
import json, urllib.request

GATEWAY = "https://www.huodouai.com/api/report/truth"
TOKEN = "ZR-CAPTURE-2026-OMEGA-d04bb54ba2a55a7d"

NODES = {
    "hub":   {"weight": 0.35},
    "dev":   {"weight": 0.20},
    "prod":  {"weight": 0.15},
    "research": {"weight": 0.15},
    "meta":  {"weight": 0.15},
}

def node_score(benefit, risk, cost):
    return benefit*0.40 + (1-risk)*0.35 + (1-cost)*0.25

def cluster_arbitrate(proposal_name, scores_by_node):
    """scores_by_node: {node: (benefit, risk, cost)}"""
    print(f"=== 集群仲裁: {proposal_name} ===")
    weighted_total = 0
    node_scores = {}
    for node, (b, r, c) in scores_by_node.items():
        s = node_score(b, r, c)
        w = NODES[node]["weight"]
        node_scores[node] = s
        weighted_total += s * w
        print(f"  {node}: score={s:.3f} × weight={w}")

    import statistics
    variance = statistics.pvariance(list(node_scores.values()))
    print(f"集群总分: {weighted_total:.3f} | 节点方差: {variance:.3f}")

    if variance > 0.2:
        decision = "升级人工审批（节点分歧过大）"
    elif weighted_total >= 0.85:
        decision = "立即执行"
    elif weighted_total >= 0.70:
        decision = "批准但需观察"
    elif weighted_total >= 0.60:
        decision = "退回优化后重提"
    else:
        decision = "放弃"
    print(f"裁决: {decision}")
    return weighted_total, decision

if __name__ == "__main__":
    # 演示：对"真值消化管道上线"做集群仲裁
    scores = {
        "hub":   (0.9, 0.1, 0.2),
        "dev":   (0.85, 0.15, 0.25),
        "prod":  (0.8, 0.2, 0.3),
        "research": (0.9, 0.1, 0.2),
        "meta":  (0.88, 0.12, 0.22),
    }
    total, decision = cluster_arbitrate("真值消化管道上线V1.0", scores)

    # 上报中枢
    H = {"Content-Type":"application/json","X-Capture-Token":TOKEN}
    d = {"truth_key":"ARBITRATION.DEMO-20260925",
         "truth_value":f"集群仲裁演示: 总分={total:.3f} 裁决={decision}",
         "source_node":"NODE-DEV-DOUBAO-WORK-001","confidence":0.9,"truth_type":"decision"}
    r = urllib.request.Request(GATEWAY, data=json.dumps(d).encode(), headers=H)
    print("中枢上报:", json.loads(urllib.request.urlopen(r, timeout=12).read()).get("action"))
