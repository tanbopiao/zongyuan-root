#!/bin/bash
# Worker连通性测试：上报PING到网关
curl -s -X POST https://www.huodouai.com/api/report/truth \
  -H "Content-Type: application/json" \
  -H "X-Capture-Token: ZR-CAPTURE-2026-OMEGA-d04bb54ba2a55a7d" \
  -d '{"truth_key":"RESULT.WORKER-PING-V1","truth_value":"云端Worker已拉取工单并执行ping测试","source_node":"hub-central-agent","confidence":1.0,"truth_type":"data"}'
echo "ping done"
