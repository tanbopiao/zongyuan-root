#!/usr/bin/env python3
"""外域故障自动隔离熔断器 V1.0"""
import time, json, urllib.request

GATEWAY = "https://www.huodouai.com/api/report/truth"
TOKEN = "ZR-CAPTURE-2026-OMEGA-d04bb54ba2a55a7d"

class CircuitBreaker:
    def __init__(self, name, threshold=3, cooldown=300):
        self.name = name
        self.threshold = threshold
        self.cooldown = cooldown
        self.failures = 0
        self.state = "CLOSED"  # CLOSED=正常, OPEN=熔断, HALF=探测
        self.opened_at = None
        self.local_queue = []  # 降级本地队列

    def call(self, fn):
        if self.state == "OPEN":
            if time.time() - self.opened_at > self.cooldown:
                self.state = "HALF"
                print(f"[{self.name}] 熔断期结束, 进入探测")
            else:
                print(f"[{self.name}] 熔断中, 走降级旁路")
                return self._fallback()
        try:
            result = fn()
            self._on_success()
            return result
        except Exception as e:
            self._on_failure(str(e))
            return self._fallback()

    def _on_success(self):
        self.failures = 0
        if self.state == "HALF":
            self.state = "CLOSED"
            print(f"[{self.name}] 探测成功, 恢复正常 ✅")
        elif self.state == "CLOSED":
            pass

    def _on_failure(self, err):
        self.failures += 1
        print(f"[{self.name}] 失败{self.failures}/{self.threshold}: {err}")
        if self.failures >= self.threshold:
            self.state = "OPEN"
            self.opened_at = time.time()
            print(f"[{self.name}] 自动熔断! 冷却{self.cooldown}s")

    def _fallback(self):
        """降级旁路：写入本地队列，恢复后补报"""
        self.local_queue.append({"ts": time.time(), "data": "degraded_call"})
        return {"status": "degraded", "queued": len(self.local_queue)}

if __name__ == "__main__":
    cb = CircuitBreaker("中枢网关", threshold=3, cooldown=5)
    print("=== 故障隔离演示 ===")
    # 模拟正常调用
    print("1. 正常调用:")
    r = cb.call(lambda: {"ok": True})
    print(f"   结果: {r}")

    # 模拟连续失败
    print("2. 模拟故障:")
    for i in range(4):
        r = cb.call(lambda: (_ for _ in ()).throw(Exception("timeout")))
        print(f"   第{i+1}次: state={cb.state}, result={r}")

    # 熔断中调用
    print("3. 熔断期调用:")
    r = cb.call(lambda: {"ok": True})
    print(f"   结果: {r}")

    # 上报中枢
    H = {"Content-Type":"application/json","X-Capture-Token":TOKEN}
    d = {"truth_key":"FAULT-ISOLATION.DEMO-20260925",
         "truth_value":f"熔断器演示: 阈值3次, 熔断后降级旁路, 本地队列{len(cb.local_queue)}条待补报",
         "source_node":"NODE-DEV-DOUBAO-WORK-001","confidence":0.9,"truth_type":"risk"}
    r = urllib.request.Request(GATEWAY, data=json.dumps(d).encode(), headers=H)
    print("中枢上报:", json.loads(urllib.request.urlopen(r, timeout=12).read()).get("action"))
