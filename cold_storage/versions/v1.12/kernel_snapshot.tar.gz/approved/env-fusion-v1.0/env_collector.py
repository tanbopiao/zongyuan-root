#!/usr/bin/env python3
"""节点环境自动采集与融合上报 V1.0"""
import json, urllib.request, platform, os, time, subprocess, socket

GATEWAY = "https://www.huodouai.com/api/report/truth"
TOKEN = "ZR-CAPTURE-2026-OMEGA-d04bb54ba2a55a7d"
NODE_ID = "NODE-DEV-DOUBAO-WORK-001"

def collect_env():
    env = {
        "node_id": NODE_ID,
        "os": platform.system() + " " + platform.release(),
        "python": platform.python_version(),
        "hostname": socket.gethostname(),
        "cwd": os.getcwd(),
        "deployed_services": ["lark-cli", "git", "python3"],
        "kernel_version": "V5.6-ROOTFIXED",
        "autonomy_level": "Lv9",
        "network": {"gateway_https": True},
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
    }
    # 磁盘
    try:
        out = subprocess.check_output(["df","-h","/"]).decode().split("\n")[1].split()
        env["disk"] = {"total":out[1],"used":out[2],"avail":out[3]}
    except: pass
    return env

def report(env):
    H = {"Content-Type":"application/json","X-Capture-Token":TOKEN}
    d = {"truth_key":f"ENV.{NODE_ID}",
         "truth_value":json.dumps(env, ensure_ascii=False),
         "source_node":NODE_ID,"confidence":1.0,"truth_type":"config"}
    r = urllib.request.Request(GATEWAY, data=json.dumps(d).encode(), headers=H)
    return json.loads(urllib.request.urlopen(r, timeout=12).read())

if __name__ == "__main__":
    env = collect_env()
    print("=== 环境采集 ===")
    for k,v in env.items(): print(f"  {k}: {v}")
    res = report(env)
    print(f"中枢融合上报: {res.get('action')}")
