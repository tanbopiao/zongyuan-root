#!/bin/bash
# 云端中枢元内核自保护一键部署
set -e
echo "=== 云端元内核自保护部署 ==="

# 1. 写入自保护脚本
mkdir -p /opt/ZONGYUAN-ROOT/ops/kernel_guard
cat > /opt/ZONGYUAN-ROOT/ops/kernel_guard/guard.py << 'PY'
import hashlib, json, os, time, subprocess, urllib.request

K="/opt/ZONGYUAN-ROOT/kernel"
G="https://www.huodouai.com/api/report/truth"
T="ZR-CAPTURE-2026-OMEGA-d04bb54ba2a55a7d"
P0=["kernel_state.json","constitution.json","decision_triad.json"]

def sha(p):
    if not os.path.exists(p): return None
    return hashlib.sha256(open(p,"rb").read()).hexdigest()[:16]

def check():
    res={}
    for f in P0:
        h=sha(f"{K}/{f}")
        res[f]={"exists":os.path.exists(f"{K}/{f}"),"sha256":h}
    # disk
    out=subprocess.check_output(["df","-h","/"]).decode().split("\n")[1].split()
    disk=int(out[4].replace("%",""))
    # auto clean if >90%
    if disk>90:
        subprocess.run(["find","/tmp","-type","f","-mtime","+7","-delete"],capture_output=True)
        subprocess.run(["journalctl","--vacuum-time=7d"],capture_output=True)
        disk=int(subprocess.check_output(["df","-h","/"]).decode().split("\n")[1].split()[4].replace("%",""))
    return res, disk

if __name__=="__main__":
    res,disk=check()
    H={"Content-Type":"application/json","X-Capture-Token":T}
    d={"truth_key":"KERNEL-GUARD.CLOUD","truth_value":json.dumps({"files":res,"disk_pct":disk}),"source_node":"hub-central-agent","confidence":1.0,"truth_type":"risk"}
    try:
        r=urllib.request.Request(G,data=json.dumps(d).encode(),headers=H)
        print("上报:",json.loads(urllib.request.urlopen(r,timeout=10).read()).get("action"))
    except Exception as e:
        print("上报失败(走本地日志):",e)
PY

echo "[1/3] 自保护脚本已写入"

# 2. 创建定时任务（每小时跑一次）
(crontab -l 2>/dev/null | grep -v kernel_guard; echo "0 * * * * /usr/bin/python3 /opt/ZONGYUAN-ROOT/ops/kernel_guard/guard.py >> /var/log/kernel_guard.log 2>&1") | crontab -
echo "[2/3] 每小时自保护巡检已配置"

# 3. 立即跑一次
python3 /opt/ZONGYUAN-ROOT/ops/kernel_guard/guard.py
echo "[3/3] 首次巡检完成"
echo "=== 云端自保护部署完成 ==="
