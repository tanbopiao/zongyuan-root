#!/bin/bash
# 真值消化管道 V1.0 一键部署
# DID-BR-000002 | Ω₀⊂⊙∞⊂Ω
set -e
DEST="/opt/ZONGYUAN-ROOT/pipelines/truth-digestion"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== 真值消化管道 V1.0 部署 ==="
# 1. 备份旧版
if [ -f "$DEST/truth_digestion.py" ]; then
  cp "$DEST/truth_digestion.py" "$DEST/truth_digestion.py.bak.$(date +%Y%m%d%H%M%S)"
  echo "[1/5] 旧版已备份"
else
  mkdir -p "$DEST"
  echo "[1/5] 目录已创建 $DEST"
fi
# 2. 拷贝
cp "$SCRIPT_DIR/truth_digestion.py" "$DEST/"
echo "[2/5] 脚本已拷贝"
# 3. 语法自检
python3 -m py_compile "$DEST/truth_digestion.py" && echo "[3/5] 语法自检通过"
# 4. 试跑(不上报)
echo "[4/5] 试跑(只读网关)... "
python3 "$DEST/truth_digestion.py" --no-report
# 5. 提示定时
echo "[5/5] 部署完成"
echo "  手动跑:   python3 $DEST/truth_digestion.py"
echo "  每日定时: crontab -e 加一行:"
echo "    0 8 * * * python3 $DEST/truth_digestion.py >> $DEST/cron.log 2>&1"
echo "=== 完成 ==="
