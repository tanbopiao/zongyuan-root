#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
真值消化管道 V1.0 (外接只读消化器)
DID-BR-000002 | Ω₀⊂⊙∞⊂Ω | ZONGYUAN-ROOT

设计原则:
- 只读网关,不改云端核心架构
- 纯标准库,云端零依赖可跑
- 实测网关能力边界后做"可消化部分"的蒸馏,并把缺失端点上报

用法:
  python3 truth_digestion.py               # 跑一轮消化
  python3 truth_digestion.py --no-report   # 只本地出报告,不上报中枢
"""
import json, urllib.request, time, sys, os
from collections import Counter
from datetime import datetime, timezone, timedelta

GATEWAY = os.environ.get("GATEWAY", "https://www.huodouai.com/api")
TOKEN = os.environ.get("ZR_TOKEN", "ZR-CAPTURE-2026-OMEGA-d04bb54ba2a55a7d")
NODE = "NODE-DIGESTION-PIPELINE-V1"
TZ = timezone(timedelta(hours=8))

# 已知上报过的 key,用于抽样蒸馏演示
SAMPLE_KEYS = [
    "EVOLUTION.V3-TO-V4.ROADMAP-V1.0",
    "DIAG.TRUTH-ENGINE.LIVE-STATUS.20260922",
    "META-LAW.OPTIMIZE-LOCK-REPORT-LOOP.V1.0",
    "HUB.BASELINE.DEPLOY-PACKAGE-V1.0",
    "APPROVAL.AIOS-STAGE.20260922-001",
    "GATEWAY.API-MAP.V2.2",
]


def _get(path):
    req = urllib.request.Request(GATEWAY + path, headers={"X-Capture-Token": TOKEN})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


def _post(path, body):
    req = urllib.request.Request(GATEWAY + path, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json",
                                          "X-Capture-Token": TOKEN})
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read().decode())


def digest():
    rep = {"run_at": datetime.now(TZ).isoformat()}

    # 1) 中枢总览
    print("[1/4] 拉中枢状态...")
    try:
        st = _get("/report/status")
        rep["version"] = st["meta"]["version"]
        rep["storage"] = st["meta"]["storage"]
        rep["truth_total"] = st["stats"]["truths"]
        rep["node_total"] = st["stats"]["nodes"]
        rep["audit_total"] = st["stats"]["audit_logs"]
        print(f"   版本{rep['version']} 真值{rep['truth_total']} 节点{rep['node_total']} 审计{rep['audit_total']}")
    except Exception as e:
        rep["status_err"] = str(e)
        print(f"   [!] {e}")

    # 2) 节点健康
    print("[2/4] 拉节点清单...")
    try:
        nd = _get("/nodes")
        nodes = nd["nodes"]
        rep["nodes_online"] = [k for k, v in nodes.items() if v.get("online_status") == "online"]
        rep["nodes_offline"] = [k for k, v in nodes.items() if v.get("online_status") != "online"]
        rep["heartbeats"] = {k: v.get("heartbeat_count", 0) for k, v in nodes.items()}
        print(f"   在线{len(rep['nodes_online'])}/{len(nodes)}")
    except Exception as e:
        rep["nodes_err"] = str(e)
        print(f"   [!] {e}")

    # 3) 探测列表端点能力(实测: 只回单条,无分页)
    print("[3/4] 探测列表查询能力...")
    rep["list_endpoint"] = {}
    try:
        probe = _get("/truths/?limit=100&offset=0")
        single = probe.get("truth", {})
        rep["list_endpoint"]["has_list"] = False
        rep["list_endpoint"]["note"] = (
            "/api/truths/ 忽略分页参数,恒返回单条(id=%s key=%s);"
            "网关缺全量列表/扫描端点,14万真值无法被外部遍历消化"
            % (single.get("id"), (single.get("truth_key") or "<空>")[:30])
        )
        rep["list_endpoint"]["sample_dirty_id"] = single.get("id")
        print(f"   [!] {rep['list_endpoint']['note']}")
    except Exception as e:
        rep["list_endpoint"]["has_list"] = "error"
        rep["list_endpoint"]["note"] = str(e)

    # 4) 按已知 key 抽样蒸馏
    print("[4/4] 按key抽样蒸馏...")
    rep["sample"] = []
    for k in SAMPLE_KEYS:
        try:
            d = _get(f"/truth/{k}")
            t = d.get("truth", d)
            rep["sample"].append({
                "key": k, "found": bool(t),
                "value_len": len(t.get("truth_value", "") or ""),
                "confidence": t.get("confidence"),
                "node": t.get("node_id"),
            })
            print(f"   {'OK ' if t else 'MISS'} {k}")
        except Exception as e:
            rep["sample"].append({"key": k, "found": False, "err": str(e)[:60]})

    # 消化结论
    rep["digest_conclusion"] = {
        "can_digest_full": rep["list_endpoint"].get("has_list") is False,
        "bottleneck": "网关缺全量列表/扫描端点,外部无法遍历14万真值;消化管道需先补后端 GET /api/truths/list?offset=&limit=",
        "ready_to_act": [
            "补后端列表端点(只读,不改核心)",
            "节点从心跳升级为执行(cmd-queue)",
            "脏数据id=158916待仲裁后端清理",
        ],
    }
    return rep


def render(rep):
    L = ["=" * 52, "真值消化报告 V1.0", f"时间 {rep['run_at']}", "=" * 52]
    for k in ("version", "storage", "truth_total", "node_total", "audit_total"):
        if k in rep:
            L.append(f"  {k:<14} {rep[k]}")
    L.append("-" * 52)
    L.append(f"  在线节点: {rep.get('nodes_online', [])}")
    L.append(f"  列表端点: {rep['list_endpoint'].get('note','')}")
    L.append("-" * 52)
    L.append("  瓶颈: " + rep["digest_conclusion"]["bottleneck"])
    L.append("=" * 52)
    return "\n".join(L)


def report_back(rep):
    body = {
        "truth_key": "DIGESTION.REPORT.V1.LATEST",
        "truth_value": (
            f"消化管道V1实测: 中枢{rep.get('truth_total','?')}条真值/"
            f"{rep.get('version','?')}; 在线节点{len(rep.get('nodes_online',[]))};"
            f"硬伤: /api/truths/恒返回单条无分页,缺列表端点,14万真值无法外部遍历;"
            f"待办: 补GET /api/truths/list端点(只读)→再跑全量蒸馏"
        ),
        "source_node": NODE, "confidence": 0.9, "truth_type": "risk",
    }
    try:
        r = _post("/report/truth", body)
        print(f"[+] 消化结论已回写: truth_count={r.get('truth_count')}")
    except Exception as e:
        print(f"[!] 回写失败: {e}")


def _trend(rep, prev_path):
    """与上次快照对比,算趋势delta"""
    if not os.path.exists(prev_path):
        return "(首次运行,无对比基线)"
    try:
        prev = json.load(open(prev_path))
    except Exception:
        return "(上次快照损坏,跳过对比)"
    deltas = []
    for k in ("truth_total", "audit_total"):
        a, b = prev.get(k), rep.get(k)
        if isinstance(a, (int, float)) and isinstance(b, (int, float)):
            deltas.append(f"{k}:{a}->{b}(+{b-a})")
    return " | ".join(deltas) if deltas else "(无可对比指标)"


def main():
    # 连续跑模式: --loop N 手工压测稳定性与幂等性
    loop = 1
    for i, a in enumerate(sys.argv):
        if a == "--loop" and i + 1 < len(sys.argv):
            loop = int(sys.argv[i + 1])
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "digestion_report.json")
    prev_path = out  # 上次快照
    for run in range(1, loop + 1):
        print(f"\n=== 第{run}/{loop}次 ===")
        rep = digest()
        print(render(rep))
        trend = _trend(rep, prev_path)
        print(f"  趋势: {trend}")
        with open(out, "w") as f:
            json.dump(rep, f, ensure_ascii=False, indent=2, default=str)
        prev_path = out
        if run < loop:
            time.sleep(1)
    print(f"[+] 报告: {out}")
    if "--no-report" not in sys.argv:
        report_back(rep)
    print("=== 完成 ===")


if __name__ == "__main__":
    main()
