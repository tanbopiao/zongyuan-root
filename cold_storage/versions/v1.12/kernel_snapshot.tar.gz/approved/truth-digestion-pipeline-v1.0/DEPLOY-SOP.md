# 真值消化管道 V1.0 部署SOP

## 一键部署
\`\`\`bash
cd /opt/ZONGYUAN-ROOT
git pull
python3 deploy/approved/truth-digestion-pipeline-v1.0/truth_digestion.py --loop 10
\`\`\`

## 验收标准
- truth_value落库正常
- 管道无报错
- Merkle-DAG链路正常

## 文件清单
- truth_digestion.py: 消化管道主程序
- cloud_worker_consumer.py: 云端工单消费
- start_worker.sh: Worker启动脚本

DID-BR-000002 | Ω₀⊂⊙∞⊂Ω
