#!/bin/bash
# ZONGYUAN-ROOT 全域自检脚本
# 输出: /opt/zongyuan-kernel/logs/selfcheck_$(date +%Y%m%d_%H%M%S).json
ZK=/opt/zongyuan-kernel
TS=$(date -Iseconds)
REPORT=$ZK/logs/selfcheck_$(date +%Y%m%d_%H%M%S).json

# 1. 进程检查
KERNEL_PID=$(pgrep -f "python3 kernel/main.py" | head -1)
WD_PID=$(pgrep -f "watchdog.sh" | head -1)
DEPLOY_PID=$(pgrep -f "deploy_api_server" | head -1)
STATUS_PID=$(pgrep -f "status_server_8768" | head -1)

# 2. 端口检查
PORT_8766=$(ss -tlnp 2>/dev/null | grep -c 8766)
PORT_8768=$(ss -tlnp 2>/dev/null | grep -c 8768)

# 3. 接口健康
H_8768=$(curl -s --max-time 2 http://127.0.0.1:8768/health 2>/dev/null | grep -c ok)
H_8766=$(curl -s --max-time 2 http://127.0.0.1:8766/health 2>/dev/null | grep -c ok)

# 4. 心跳新鲜度（应在60s内）
HB_TS=$(python3 -c "import json; print(json.load(open('$ZK/var/heartbeat.json'))['ts'])" 2>/dev/null)
HB_AGE=$(python3 -c "
from datetime import datetime
try:
    hb=datetime.fromisoformat('$HB_TS')
    now=datetime.now(hb.tzinfo)
    print(round((now-hb).total_seconds()))
except: print(9999)
" 2>/dev/null)

# 5. 磁盘
DISK_USED=$(df -h / | tail -1 | awk '{print $5}')

# 6. 只读文件哈希校验（抽查3个）
HASH_OK=0; HASH_FAIL=0
while read h f; do
  if [ -f "$f" ]; then
    actual=$(sha256sum "$f" | awk '{print $1}')
    [ "$actual" = "$h" ] && HASH_OK=$((HASH_OK+1)) || HASH_FAIL=$((HASH_FAIL+1))
  fi
done < $ZK/var/LOCKDOWN_MANIFEST.txt

# 7. 算子健康
OPS_OK=$(python3 -c "import json; d=json.load(open('$ZK/var/operator_health.json')); print(sum(1 for v in d.values() if v['ok']))" 2>/dev/null)

# 汇总
python3 -c "
import json
r = {
  'ts': '$TS',
  'processes': {
    'kernel': '$KERNEL_PID', 'watchdog': '$WD_PID',
    'deploy_api': '$DEPLOY_PID', 'status_api': '$STATUS_PID'
  },
  'ports': {'8766': $PORT_8766, '8768': $PORT_8768},
  'health_api': {'8768_ok': $H_8768, '8766_ok': $H_8766},
  'heartbeat_age_sec': $HB_AGE,
  'disk_used': '$DISK_USED',
  'hash_check': {'ok': $HASH_OK, 'fail': $HASH_FAIL},
  'operators_ok': $OPS_OK,
  'overall': 'HEALTHY' if all([
    '$KERNEL_PID'!='', '$PORT_8768'=='1',
    $H_8768==1, $HB_AGE < 120, $HASH_FAIL==0
  ]) else 'DEGRADED'
}
print(json.dumps(r, ensure_ascii=False, indent=2))
open('$REPORT','w').write(json.dumps(r, ensure_ascii=False, indent=2))
"
echo ""
echo "报告: $REPORT"
