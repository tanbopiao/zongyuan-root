#!/usr/bin/env python3
"""
ZONGYUAN-ROOT 部署数据API (port 8766)
零依赖标准库实现，复用 api/auto_deploy_api.py 的 AutoDeployAPI 业务类。
DID: DID-BR-000002  锚定: Ω₀⊂⊙∞⊂Ω
"""
import json, os, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime, timezone, timedelta

sys.path.insert(0, "/opt/zongyuan-kernel/api")
try:
    from auto_deploy_api import AutoDeployAPI
    deploy_engine = AutoDeployAPI()
except Exception as e:
    deploy_engine = None
    print(f"[warn] AutoDeployAPI 加载失败: {e}")

tz = timezone(timedelta(hours=8))

class Handler(BaseHTTPRequestHandler):
    def _send(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False, indent=2).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path in ("/", "/deploy-api/", "/api/deploy"):
            deps = {}
            if deploy_engine:
                deps = deploy_engine.deployments
            self._send({
                "service": "zongyuan-deploy-api",
                "did": "DID-BR-000002",
                "trace_mark": "Ω₀⊂⊙∞⊂Ω",
                "time": datetime.now(tz).isoformat(),
                "pending_deployments": len(deps),
                "engine_loaded": deploy_engine is not None
            })
        elif self.path == "/health":
            self._send({"status": "ok", "service": "deploy-api", "time": datetime.now(tz).isoformat()})
        else:
            self._send({"error": "not found", "path": self.path}, 404)

    def log_message(self, *a): pass

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8766))
    print(f"[deploy-api] listening on 127.0.0.1:{port}")
    HTTPServer(("127.0.0.1", port), Handler).serve_forever()
