#!/bin/bash
# ZONGYUAN-ROOT 内核看门狗：主循环死了自动拉起
ZK=/opt/zongyuan-kernel
PIDFILE=$ZK/var/kernel.pid
LOG=$ZK/logs/watchdog.log

log(){ echo "[$(date '+%F %T')] $*" >> $LOG; }

while true; do
  if [ -f "$PIDFILE" ]; then
    pid=$(cat "$PIDFILE")
    if ! kill -0 "$pid" 2>/dev/null; then
      log "内核进程 $pid 已死，重启"
      cd $ZK && nohup python3 kernel/main.py >> logs/kernel.log 2>&1 &
      echo $! > "$PIDFILE"
      log "新内核 pid=$(cat $PIDFILE)"
    fi
  else
    cd $ZK && nohup python3 kernel/main.py >> logs/kernel.log 2>&1 &
    echo $! > "$PIDFILE"
    log "首次启动内核 pid=$(cat $PIDFILE)"
  fi
  sleep 10
done
