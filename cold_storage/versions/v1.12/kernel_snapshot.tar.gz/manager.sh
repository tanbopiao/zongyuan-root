#!/bin/bash
# ZONGYUAN-ROOT 本地仿真环境统一管理
# 用法: bash /opt/zongyuan-kernel/manager.sh {start|stop|status|restart}
ZK=/opt/zongyuan-kernel
cd $ZK

start() {
  setsid python3 kernel/main.py >> logs/kernel.log 2>&1 < /dev/null &
  setsid bash watchdog.sh >> logs/watchdog.log 2>&1 < /dev/null &
  setsid python3 api/deploy_api_server.py >> logs/deploy-api.log 2>&1 < /dev/null &
  setsid python3 services/local/status_server_8768.py >> logs/status-api.log 2>&1 < /dev/null &
  echo "✅ 已启动: kernel + watchdog + 8766 + 8768"
}
stop() {
  pkill -f "kernel/main.py" 2>/dev/null
  pkill -f "watchdog.sh" 2>/dev/null
  pkill -f "deploy_api_server" 2>/dev/null
  pkill -f "status_server_8768" 2>/dev/null
  echo "✅ 已停止"
}
status() {
  echo "--- 进程 ---"
  ps -ef | grep -E "kernel/main|watchdog|deploy_api|status_server" | grep -v grep || echo "无进程"
  echo "--- 端口 ---"
  ss -tlnp 2>/dev/null | grep -E "8766|8768" || echo "无监听"
  echo "--- 心跳 ---"
  cat var/heartbeat.json 2>/dev/null
  echo "--- 接口 ---"
  curl -s --max-time 2 http://127.0.0.1:8768/health && echo ""
  curl -s --max-time 2 http://127.0.0.1:8766/health && echo ""
}
case "$1" in
  start) start ;;
  stop) stop ;;
  status) status ;;
  restart) stop; sleep 2; start ;;
  *) echo "用法: $0 {start|stop|status|restart}" ;;
esac
