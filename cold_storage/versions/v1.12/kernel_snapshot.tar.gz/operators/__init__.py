"""ZONGYUAN-ROOT 27算子注册表（可执行）"""
from .layer1_2 import P4Reconcile, P7ExternalAnchor, T3Distill, M4Riemannian, M5SMBSMap, M6DriftPatrol
from .layer3_4 import K7EntityExtract, K8KGCompletion, K9CrossDocLink, C10CausalTrace, C11Singularity, C12CausalIntervention
from .layer5_6 import A13CausalToTruth, A14TruthToEvolution, A15EvolutionToCausal, S16FourLayer, S17NineCategories, S18MerkleDAG
from .layer7_10 import G19Reconcile, Z20EFuse, Z21ZKP, D22PlanEval, D23RiskAssess, D24LegalOpinion, B25CivilizationSim, B26RoleMetaCheck, B27KeyframeConsistency

ALL_OPERATORS = [
    P4Reconcile(), P7ExternalAnchor(), T3Distill(),
    M4Riemannian(), M5SMBSMap(), M6DriftPatrol(),
    K7EntityExtract(), K8KGCompletion(), K9CrossDocLink(),
    C10CausalTrace(), C11Singularity(), C12CausalIntervention(),
    A13CausalToTruth(), A14TruthToEvolution(), A15EvolutionToCausal(),
    S16FourLayer(), S17NineCategories(), S18MerkleDAG(),
    G19Reconcile(), Z20EFuse(), Z21ZKP(),
    D22PlanEval(), D23RiskAssess(), D24LegalOpinion(),
    B25CivilizationSim(), B26RoleMetaCheck(), B27KeyframeConsistency(),
]

REGISTRY = {op.op_id: op for op in ALL_OPERATORS}

def run_chain(sample_input=None):
    """按层顺序跑一遍27算子自检"""
    sample_input = sample_input or {}
    results = {}
    for op in ALL_OPERATORS:
        results[op.op_id] = op.execute(sample_input)
    return results
