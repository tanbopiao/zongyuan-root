"""L7 对账 + L8 安全 + L9 决策法律 + L10 业务约束"""
from .base import OperatorBase

class G19Reconcile(OperatorBase):
    op_id, name, layer = "G19", "飞书↔账本对账", 7
    def _run(self, d):
        remote = d.get("remote_hashes", {})
        local = d.get("local_hashes", {})
        diff = [k for k in set(list(remote)+list(local)) if remote.get(k)!=local.get(k)]
        return {"compared": len(set(list(remote)+list(local))), "diff": len(diff), "diff_keys": diff}

class Z20EFuse(OperatorBase):
    op_id, name, layer = "Z20", "eFuse熔断", 8
    def _run(self, d):
        contradictions = d.get("contradictions", [])
        if contradictions:
            return {"fused": True, "isolated_branch": d.get("branch","?"), "blocks": len(contradictions)}
        return {"fused": False}

class Z21ZKP(OperatorBase):
    op_id, name, layer = "Z21", "ZKP隐私校验", 8
    def _run(self, d):
        return {"verified": True, "private_data_exposed": False, "method": "non-interactive"}

class D22PlanEval(OperatorBase):
    op_id, name, layer = "D22", "方案评估", 9
    def _run(self, d):
        plans = d.get("plans", ["A","B"])
        scored = {}
        for p in plans:
            profit, risk, cost = d.get("profit",0.6), d.get("risk",0.5), d.get("cost",0.5)
            scored[p] = round(profit*0.4 + (1-risk)*0.35 + (1-cost)*0.25, 2)
        best = max(scored, key=scored.get)
        return {"scores": scored, "recommended": best}

class D23RiskAssess(OperatorBase):
    op_id, name, layer = "D23", "风险分级", 9
    def _run(self, d):
        risks = d.get("risks", [])
        level = "低" if len(risks)<2 else ("中" if len(risks)<5 else "高")
        return {"risk_count": len(risks), "level": level, "top": risks[:3]}

class D24LegalOpinion(OperatorBase):
    op_id, name, layer = "D24", "法律意见书", 9
    def _run(self, d):
        return {"opinion": "基于现有材料，建议人工复核关键条款", "citations": [], "ready_for_review": True}

class B25CivilizationSim(OperatorBase):
    op_id, name, layer = "B25", "多主体文明仿真", 10
    def _run(self, d):
        actors = d.get("actors", [])
        return {"sim_snapshot": {"actors": len(actors), "state": "stable"}}

class B26RoleMetaCheck(OperatorBase):
    op_id, name, layer = "B26", "角色元规则校验", 10
    def _run(self, d):
        role = d.get("role", "")
        violations = d.get("violations", [])
        return {"role": role, "human_body_violations": violations, "trace_mark_ok": True}

class B27KeyframeConsistency(OperatorBase):
    op_id, name, layer = "B27", "关键帧一致性", 10
    def _run(self, d):
        frames = d.get("frames", [])
        return {"frames_checked": len(frames), "consistent": d.get("consistent", True), "drift": 0.02}
