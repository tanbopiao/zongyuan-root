"""ZONGYUAN-ROOT 算子基类"""
import hashlib, time, json
from datetime import datetime, timezone, timedelta

tz = timezone(timedelta(hours=8))

class OperatorBase:
    op_id = "BASE"
    name = "基类"
    layer = 0
    description = ""

    def execute(self, data: dict = None) -> dict:
        data = data or {}
        t0 = time.time()
        try:
            result = self._run(data)
            result["op_id"] = self.op_id
            result["layer"] = self.layer
            result["elapsed_ms"] = round((time.time()-t0)*1000, 2)
            result["ok"] = True
        except Exception as e:
            result = {"ok": False, "error": str(e), "op_id": self.op_id}
        result["ts"] = datetime.now(tz).isoformat()
        return result

    def _run(self, data: dict) -> dict:
        raise NotImplementedError

    def sha256(self, s):
        return hashlib.sha256(str(s).encode()).hexdigest()
