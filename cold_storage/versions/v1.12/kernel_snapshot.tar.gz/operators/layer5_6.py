"""L5 CTE适配 + L6 结构化归档"""
from .base import OperatorBase

class A13CausalToTruth(OperatorBase):
    op_id, name, layer = "A13", "因果→真值", 5
    def _run(self, d):
        chain = d.get("chain", "")
        return {"truth_item": f"因果事实: {chain}", "confidence": d.get("probability",0.5)}

class A14TruthToEvolution(OperatorBase):
    op_id, name, layer = "A14", "真值→进化", 5
    def _run(self, d):
        purity = d.get("purity", 0.8)
        return {"fitness_phi": purity, "evolution_pressure": round(1-purity, 2)}

class A15EvolutionToCausal(OperatorBase):
    op_id, name, layer = "A15", "进化→因果", 5
    def _run(self, d):
        return {"do_intervention": d.get("strategy",""), "propagation": "注入因果网络"}

class S16FourLayer(OperatorBase):
    op_id, name, layer = "S16", "四层结构化拆分", 6
    def _run(self, d):
        raw = d.get("raw", {})
        return {
            "L1_meta": {"root_id": self.sha256(str(raw))[:16]},
            "L2_content": raw,
            "L3_relation": [],
            "L4_truth": {"confidence": 0.8, "version": "v1"}
        }

class S17NineCategories(OperatorBase):
    op_id, name, layer = "S17", "九元类归类", 6
    CATS = ["公理","定理","方法","数据","案例","决策","创意","风险","协议"]
    def _run(self, d):
        text = str(d.get("text",""))
        score = {c: text.count(c) for c in self.CATS}
        best = max(score, key=score.get)
        return {"assigned_category": best if score[best]>0 else "数据", "scores": score}

class S18MerkleDAG(OperatorBase):
    op_id, name, layer = "S18", "Merkle-DAG追加", 6
    def _run(self, d):
        leaf = d.get("data","")
        h = self.sha256(leaf)
        return {"leaf_hash": h, "prev_verified": d.get("prev_hash","GENESIS"), "appended": True}
