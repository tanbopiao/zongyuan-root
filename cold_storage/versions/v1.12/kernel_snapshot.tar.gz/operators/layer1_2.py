"""L1 真值过滤与深度蒸馏 + L2 流形度量"""
from .base import OperatorBase
import re, math

class P4Reconcile(OperatorBase):
    op_id, name, layer = "P4", "真值对账", 1
    def _run(self, d):
        items = d.get("items", [])
        facts, guesses, opinions = [], [], []
        for it in items:
            t = str(it)
            if re.search(r"\d{4}-\d{2}-\d{2}|SHA|hash|DID-", t): facts.append(t)
            elif "可能|也许|大概" in t: guesses.append(t)
            else: opinions.append(t)
        return {"processed": len(items), "facts": len(facts), "guesses": len(guesses), "opinions": len(opinions)}

class P7ExternalAnchor(OperatorBase):
    op_id, name, layer = "P7", "外部锚定", 1
    def _run(self, d):
        claims = d.get("claims", [])
        anchored = [c for c in claims if d.get("verified_sources")]
        return {"claims": len(claims), "anchored": len(anchored), "confidence": round(len(anchored)/max(len(claims),1), 2)}

class T3Distill(OperatorBase):
    op_id, name, layer = "T3", "真值蒸馏", 1
    def _run(self, d):
        raw = d.get("text", "")
        sents = [s.strip() for s in re.split(r"[。！？.!?]", raw) if s.strip()]
        seen, out = set(), []
        for s in sents:
            h = self.sha256(s)[:16]
            if h not in seen:
                seen.add(h); out.append(s)
        return {"raw_sentences": len(sents), "distilled": len(out), "compression": round(len(out)/max(len(sents),1),2)}

class M4Riemannian(OperatorBase):
    op_id, name, layer = "M4", "黎曼流形度量", 2
    def _run(self, d):
        vecs = d.get("vectors", [[0,0],[1,1]])
        jumps = 0
        for i in range(1, len(vecs)):
            dist = math.sqrt(sum((a-b)**2 for a,b in zip(vecs[i], vecs[i-1])))
            if dist > d.get("jump_threshold", 3.0): jumps += 1
        return {"points": len(vecs), "jumps_detected": jumps}

class M5SMBSMap(OperatorBase):
    op_id, name, layer = "M5", "SM-BS双向映射", 2
    def _run(self, d):
        concept = d.get("concept", "test")
        coord = [hash(c)%100 for c in concept]
        back = "".join(chr(ord('a')+x%26) for x in coord)
        return {"concept": concept, "coord": coord, "roundtrip": back, "distortion": round(sum(coord)/max(len(coord),1),2)}

class M6DriftPatrol(OperatorBase):
    op_id, name, layer = "M6", "漂移巡检", 2
    def _run(self, d):
        current = d.get("current", {})
        baseline = d.get("baseline", {})
        drifted = [k for k in baseline if k in current and current[k]!=baseline[k]]
        rate = round(len(drifted)/max(len(baseline),1)*100, 1)
        level = "绿" if rate<5 else ("黄" if rate<10 else "红")
        return {"drift_pct": rate, "level": level, "drifted_keys": drifted}
