"""L3 知识图谱 + L4 因果推理"""
from .base import OperatorBase
import re

class K7EntityExtract(OperatorBase):
    op_id, name, layer = "K7", "实体关系抽取", 3
    def _run(self, d):
        text = d.get("text", "")
        ents = re.findall(r"[\u4e00-\u9fa5]{2,6}(?=是|为|负责|属于|导致)", text)
        return {"entities": list(set(ents)), "entity_count": len(set(ents))}

class K8KGCompletion(OperatorBase):
    op_id, name, layer = "K8", "知识图谱补全", 3
    def _run(self, d):
        triples = d.get("triples", [])
        nodes = set()
        for t in triples:
            nodes.add(t[0]); nodes.add(t[2])
        return {"triples": len(triples), "nodes": len(nodes), "density": round(len(triples)/max(len(nodes),1),2)}

class K9CrossDocLink(OperatorBase):
    op_id, name, layer = "K9", "跨文档实体链接", 3
    def _run(self, d):
        mentions = d.get("mentions", [])
        unified = {}
        for m in mentions:
            key = m.get("canonical", m.get("name",""))
            unified.setdefault(key, []).append(m.get("doc",""))
        return {"mentions": len(mentions), "canonical_entities": len(unified)}

class C10CausalTrace(OperatorBase):
    op_id, name, layer = "C10", "因果链溯源", 4
    def _run(self, d):
        events = d.get("events", ["A","B","C"])
        chain = " -> ".join(events)
        return {"chain": chain, "depth": len(events), "nodes": events}

class C11Singularity(OperatorBase):
    op_id, name, layer = "C11", "奇点概率预测", 4
    def _run(self, d):
        prob = d.get("probability", 0.1)
        level = "蓝" if prob<0.1 else ("黄" if prob<0.3 else ("橙" if prob<0.6 else "红"))
        return {"probability": prob, "level": level, "watch": level in ("橙","红")}

class C12CausalIntervention(OperatorBase):
    op_id, name, layer = "C12", "因果干预模拟", 4
    def _run(self, d):
        cut = d.get("cut_edge", "")
        return {"intervention": f"切断边[{cut}]", "downstream_effect": "待观测", "counterfactual": True}
