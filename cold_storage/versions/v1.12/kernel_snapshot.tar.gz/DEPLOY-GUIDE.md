# ZONGYUAN-ROOT 云端守护代理部署指南

## 部署前确认
- 云服务器已可访问（123.207.202.158）
- Python3已安装
- Git仓库已配置

## 部署步骤（云服务器上执行）

```bash
# 1. 进入目录
cd /opt/ZONGYUAN-ROOT

# 2. 拉取最新代码
git pull origin main

# 3. 执行一键部署
bash deploy/install.sh
```

## 部署后验证

```bash
# 查看服务状态
systemctl status zongyuan-daemon

# 查看日志（应该看到每30分钟一条巡检）
journalctl -u zongyuan-daemon -f
```

## 回滚（如果需要）

```bash
systemctl stop zongyuan-daemon
systemctl disable zongyuan-daemon
rm /etc/systemd/system/zongyuan-daemon.service
systemctl daemon-reload
```

## 资源占用预估
- CPU: <5%
- 内存: ~50MB
- 网络: 每30分钟一次HTTPS请求，月流量<10MB
- 对现有官网影响: 零

---
Ω₀⊂⊙∞⊂Ω | DID-BR-000002
