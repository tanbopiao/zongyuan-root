#!/bin/bash
# ZONGYUAN-ROOT 云端守护代理一键部署
# 在云服务器上执行: bash install.sh

echo "=========================================="
echo "ZONGYUAN-ROOT 守护代理部署"
echo "=========================================="

# 1. 创建工作目录
mkdir -p /opt/ZONGYUAN-ROOT/daemon
cd /opt/ZONGYUAN-ROOT/daemon

# 2. 拉取最新代码（如果git仓库已配置）
if [ -d ".git" ]; then
    git pull origin main
else
    echo "请先git clone仓库到当前目录"
    exit 1
fi

# 3. 安装依赖（只有requests）
pip3 install requests -q

# 4. 创建systemd服务
cat > /etc/systemd/system/zongyuan-daemon.service << EOF
[Unit]
Description=ZONGYUAN-ROOT Daemon Agent
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/ZONGYUAN-ROOT/daemon
ExecStart=/usr/bin/python3 /opt/ZONGYUAN-ROOT/daemon/deploy/daemon_agent.py
Restart=always
RestartSec=60

[Install]
WantedBy=multi-user.target
EOF

# 5. 启动服务
systemctl daemon-reload
systemctl enable zongyuan-daemon
systemctl start zongyuan-daemon

echo "=========================================="
echo "部署完成！"
echo "查看状态: systemctl status zongyuan-daemon"
echo "查看日志: journalctl -u zongyuan-daemon -f"
echo "停止服务: systemctl stop zongyuan-daemon"
echo "=========================================="
