#!/bin/bash
# ZONGYUAN-ROOT 故障切换：主实例挂了拉起备用实例(8769/8771)
ZK=/opt/zongyuan-kernel
# 检查主实例健康
if ! curl -s --max-time 3 http://127.0.0.1:8768/health | grep -q ok; then
  echo "[$(date -Iseconds)] 主实例异常，拉起备用实例" >> $ZK/logs/failover.log
  # 备用实例用不同端口
  PORT_OVERRIDE=8771 setsid python3 $ZK/services/local/status_server_8768.py > $ZK/logs/status_backup.log 2>&1 &
  PORT_OVERRIDE=8769 setsid python3 $ZK/api/deploy_api_server.py > $ZK/logs/deploy_backup.log 2>&1 &
fi
