#!/usr/bin/env python3
"""
ZONGYUAN-ROOT 本地内核状态API (port 8768)
零依赖（标准库 http.server），只读返回内核状态。
DID: DID-BR-000002  锚定: Ω₀⊂⊙∞⊂Ω
"""
import json, os
from http.server import BaseHTTPRequestHandler, HTTPServer
from datetime import datetime, timezone, timedelta

ROOT = "/home/user"
STATE = f"{ROOT}/.zongyuan_root/state"
tz = timezone(timedelta(hours=8))

def read_json(p, default=None):
    try:
        with open(p) as f: return json.load(f)
    except Exception: return default

class Handler(BaseHTTPRequestHandler):
    def _send(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False, indent=2).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path in ("/", "/api/status", "/status"):
            lock = read_json(f"{STATE}/ACTIVE_LOCK.json", {})
            chain = read_json(f"{STATE}/merkle_chain.json", {})
            nodes = read_json(f"{STATE}/node_activation_state.json", {})
            self._send({
                "service": "zongyuan-local-status-api",
                "did": "DID-BR-000002",
                "trace_mark": "Ω₀⊂⊙∞⊂Ω",
                "time": datetime.now(tz).isoformat(),
                "kernel_version": lock.get("kernel_version"),
                "block_height": lock.get("block_height"),
                "root_hash": chain.get("root_hash"),
                "autonomy": lock.get("autonomy"),
                "active_assets": lock.get("active_assets"),
                "nodes": {k: v.get("status") for k, v in nodes.items()},
                "chain_blocks": chain.get("block_count")
            })
        elif self.path == "/health":
            self._send({"status": "ok", "time": datetime.now(tz).isoformat()})
        else:
            self._send({"error": "not found", "path": self.path}, 404)

    def log_message(self, *a): pass

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8768))
    HTTPServer(("127.0.0.1", port), Handler).serve_forever()
