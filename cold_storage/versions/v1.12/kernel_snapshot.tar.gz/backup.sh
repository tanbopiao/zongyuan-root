#!/bin/bash
# ZONGYUAN-ROOT 每日备份
ZK=/opt/zongyuan-kernel
BK=$ZK/backups
TS=$(date +%Y%m%d_%H%M%S)
mkdir -p $BK
tar czf $BK/kernel_backup_$TS.tar.gz \
  --exclude='logs/*.log' \
  --exclude='backups/*' \
  -C /opt zongyuan-kernel 2>/dev/null
# 保留7天
find $BK -name "kernel_backup_*.tar.gz" -mtime +7 -delete
echo "[$(date -Iseconds)] 备份完成: kernel_backup_$TS.tar.gz" >> $ZK/logs/backup.log
