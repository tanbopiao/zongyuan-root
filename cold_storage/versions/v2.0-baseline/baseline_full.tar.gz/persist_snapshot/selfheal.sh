#!/bin/bash
# 自愈：检查3进程，挂了自动从持久层拉起
KERNEL=/home/user/ZONGYUAN-ROOT/persist_snapshot/kernel
cd $KERNEL
for proc in "kernel/main.py:kernel" "status_server_8768.py:status" "deploy_api_server.py:deploy"; do
  name="${proc%%:*}"
  label="${proc##*:}"
  if ! pgrep -f "$name" > /dev/null; then
    echo "$(date -Iseconds) 自愈: $label 进程缺失，重新拉起"
    case $label in
      kernel) setsid python3 kernel/main.py > logs/kernel.log 2>&1 & ;;
      status) setsid python3 services/local/status_server_8768.py > logs/status.log 2>&1 & ;;
      deploy) setsid python3 api/deploy_api_server.py > logs/deploy.log 2>&1 & ;;
    esac
  fi
done
