#!/bin/bash
# ZONGYUAN-ROOT 沙箱销毁后一键恢复脚本
# 用法: bash kernel_recover.sh
# 从 persist_snapshot/ 恢复所有易失资产
set -e
PERSIST=/home/user/ZONGYUAN-ROOT/persist_snapshot
ZK=/opt/zongyuan-kernel

echo "=== ZONGYUAN-ROOT 沙箱恢复 ==="

# 1. 恢复/opt内核
echo "[1/6] 恢复内核到 /opt/zongyuan-kernel ..."
sudo mkdir -p $ZK
sudo tar czf /tmp/kernel_restore.tar.gz -C $PERSIST/kernel .
sudo tar xzf /tmp/kernel_restore.tar.gz -C $ZK
sudo chmod +x $ZK/*.sh 2>/dev/null
echo "  ✅ 内核恢复: $(find $ZK -type f | wc -l)文件"

# 2. 恢复SSH密钥
echo "[2/6] 恢复SSH密钥 ..."
mkdir -p ~/.ssh
cp $PERSIST/ssh/zongyuan_new.enc ~/.ssh/zongyuan_new
cp $PERSIST/ssh/zongyuan_new.pub ~/.ssh/
cp $PERSIST/ssh/config ~/.ssh/config 2>/dev/null
chmod 600 ~/.ssh/zongyuan_new
chmod 644 ~/.ssh/zongyuan_new.pub
echo "  ✅ SSH密钥已恢复"

# 3. 恢复crontab
echo "[3/6] 恢复crontab ..."
crontab $PERSIST/crontab/crontab_backup.txt 2>/dev/null
echo "  ✅ crontab已恢复: $(crontab -l | wc -l)条"

# 4. 恢复节点密钥
echo "[4/6] 恢复节点密钥 ..."
mkdir -p ~/.zr_mhp
cp $PERSIST/node_keys/*.pem ~/.zr_mhp/ 2>/dev/null
cp $PERSIST/node_keys/*.json ~/.zr_mhp/ 2>/dev/null
echo "  ✅ 节点密钥已恢复"

# 5. 恢复状态文件
echo "[5/6] 恢复状态文件 ..."
mkdir -p ~/.zongyuan_root/state ~/.zongyuan_root/PERMANENT_BASE
cp $PERSIST/state/merkle_chain.json ~/.zongyuan_root/state/ 2>/dev/null
cp $PERSIST/state/ACTIVE_LOCK.json ~/.zongyuan_root/PERMANENT_BASE/ 2>/dev/null
cp $PERSIST/state/current_lock.json ~/.zongyuan_root/state/ACTIVE_LOCK.json 2>/dev/null
echo "  ✅ 状态文件已恢复"

# 6. 启动内核
echo "[6/6] 启动内核 ..."
cd $ZK
setsid python3 kernel/main.py > logs/kernel.log 2>&1 &
setsid python3 services/local/status_server_8768.py > logs/status.log 2>&1 &
setsid python3 api/deploy_api_server.py > logs/deploy.log 2>&1 &
sleep 2
echo "  ✅ 内核进程: $(ps -ef | grep -E 'kernel/main|8766|8768' | grep -v grep | wc -l)个"

echo ""
echo "=== 恢复完成 ==="
echo "收敛点: persist_snapshot/ (64文件, 404K)"
echo "沙箱销毁损失: 仅运行时日志和临时缓存（可重建）"
