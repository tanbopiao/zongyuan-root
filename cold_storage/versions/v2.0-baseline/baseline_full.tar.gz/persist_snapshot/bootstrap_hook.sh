#!/bin/bash
# ZONGYUAN-ROOT 钩子算子：从持久层直接全量拉起，零解压零写入
# 持久层在Git目录内，沙箱销毁不丢；不写/opt（反正会被清）
PERSIST=/home/user/ZONGYUAN-ROOT/persist_snapshot
KERNEL=$PERSIST/kernel
LOGDIR=$PERSIST/L2_archive/runtime_logs
mkdir -p $LOGDIR

echo "=== ZONGYUAN-ROOT 钩子算子拉起 ==="
echo "持久层: $KERNEL"
echo "不写/opt，直接从持久层运行"

# 1. 恢复密钥（从持久层，Git目录不丢）
mkdir -p ~/.ssh
cp $PERSIST/ssh/zongyuan_new.enc ~/.ssh/zongyuan_new 2>/dev/null
cp $PERSIST/ssh/zongyuan_new.pub ~/.ssh/ 2>/dev/null
chmod 600 ~/.ssh/zongyuan_new 2>/dev/null
crontab $PERSIST/crontab/crontab_backup.txt 2>/dev/null
echo "[1/3] 密钥+crontab已恢复"

# 2. 直接从持久层启动3进程（不写/opt）
cd $KERNEL
export PYTHONPATH=$KERNEL:$PYTHONPATH
mkdir -p $KERNEL/{var,logs,state,operator_registry}
# 补全缺失的运行时资产（从持久层L1/state复制）
cp $PERSIST/state/merkle_chain.json $KERNEL/state/ 2>/dev/null
cp $PERSIST/state/ACTIVE_LOCK.json $KERNEL/state/ 2>/dev/null
[ -d "$KERNEL/metalaws" ] || cp -r /home/user/ZONGYUAN-ROOT/00_KERNEL/metalaws $KERNEL/ 2>/dev/null
[ -f "$KERNEL/operator_registry/operators_full_ledger.json" ] || echo '{"total_operators":27}' > $KERNEL/operator_registry/operators_full_ledger.json
echo "[2/3] 从持久层启动内核..."
setsid python3 kernel/main.py > $LOGDIR/kernel.log 2>&1 &
setsid python3 services/local/status_server_8768.py > $LOGDIR/status.log 2>&1 &
setsid python3 api/deploy_api_server.py > $LOGDIR/deploy.log 2>&1 &

# 3. 快速验证
echo "[3/3] 验证..."
for i in 1 2 3 4 5; do
  curl -s --max-time 1 http://127.0.0.1:8768/health | grep -q ok 2>/dev/null && { echo "  ✅ 8768健康"; break; }
  sleep 1
done
PROCS=$(ps -ef | grep -E 'kernel/main|status_server|deploy_api' | grep -v grep | wc -l)
echo "  进程: $PROCS个"
echo "  运行目录: $KERNEL (持久层，沙箱销毁不丢)"
echo "=== 钩子拉起完成 ==="
