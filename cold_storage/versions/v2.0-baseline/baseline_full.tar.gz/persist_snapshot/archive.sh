#!/bin/bash
# ZONGYUAN-ROOT 分级持久化归档脚本
# L0核心(即时恢复) L1高价值(状态) L2中价值(日志) L3低价值(历史)
PERSIST=/home/user/ZONGYUAN-ROOT/persist_snapshot
ZK=/opt/zongyuan-kernel
STATE=/home/user/.zongyuan_root
TS=$(date +%Y%m%d_%H%M%S)

echo "=== 分级持久化归档 $TS ==="

# L1 高价值：状态快照（每次覆盖最新+保留历史）
echo "[L1] 高价值状态..."
cp $ZK/var/heartbeat.json $PERSIST/L1_highvalue/heartbeat_latest.json 2>/dev/null
cp $ZK/var/operator_health.json $PERSIST/L1_highvalue/operator_health_latest.json 2>/dev/null
cp $ZK/var/real_pipeline.json $PERSIST/L1_highvalue/real_pipeline_latest.json 2>/dev/null
cp $STATE/state/merkle_chain.json $PERSIST/L1_highvalue/merkle_chain_latest.json 2>/dev/null
cp $STATE/state/ACTIVE_LOCK.json $PERSIST/L1_highvalue/active_lock_latest.json 2>/dev/null
cp $ZK/var/LOCKDOWN_MANIFEST.txt $PERSIST/L1_highvalue/ 2>/dev/null
# 带时间戳的历史副本
cp $ZK/var/heartbeat.json $PERSIST/L1_highvalue/heartbeat_$TS.json 2>/dev/null
echo "  ✅ $(ls $PERSIST/L1_highvalue/ | wc -l)个状态文件"

# L2 中价值：日志+自检（按天归档）
echo "[L2] 日志与自检归档..."
DAY=$(date +%Y%m%d)
mkdir -p $PERSIST/L2_archive/logs/$DAY $PERSIST/L2_archive/selfcheck/$DAY
cp $ZK/logs/*.log $PERSIST/L2_archive/logs/$DAY/ 2>/dev/null
cp $ZK/logs/selfcheck_*.json $PERSIST/L2_archive/selfcheck/$DAY/ 2>/dev/null
# 真实管线结果
cp $ZK/var/real_pipeline.json $PERSIST/L2_archive/real_pipeline/real_pipeline_$TS.json 2>/dev/null
echo "  ✅ 日志:$(ls $PERSIST/L2_archive/logs/$DAY/ 2>/dev/null | wc -l) 自检:$(ls $PERSIST/L2_archive/selfcheck/$DAY/ 2>/dev/null | wc -l)"

# L3 低价值：操作轨迹（追加写入）
echo "[L3] 操作轨迹记录..."
echo "[$TS] 归档执行 | L1状态快照 | L2日志归档 | 进程:$(ps -ef | grep -cE 'kernel/main|8766|8768') | 心跳:$(cat $ZK/var/heartbeat.json 2>/dev/null | python3 -c 'import sys,json;print(json.load(sys.stdin).get(\"ts\",\"?\"))' 2>/dev/null)" >> $PERSIST/L3_history/operations/operation_log.md
echo "  ✅ 轨迹已追加"

# 清理L1超过30天的历史心跳（最新保留）
find $PERSIST/L1_highvalue/ -name "heartbeat_20*.json" -mtime +30 -delete 2>/dev/null
# 清理L2超过7天的日志
find $PERSIST/L2_archive/logs/ -type d -mtime +7 -exec rm -rf {} + 2>/dev/null

echo ""
echo "=== 归档完成 ==="
echo "L0核心: $(find $PERSIST/kernel $PERSIST/ssh $PERSIST/crontab -type f 2>/dev/null | wc -l)文件"
echo "L1高价值: $(find $PERSIST/L1_highvalue -type f | wc -l)文件"
echo "L2归档: $(find $PERSIST/L2_archive -type f | wc -l)文件"
echo "L3历史: $(find $PERSIST/L3_history -type f | wc -l)文件"
echo "总计: $(du -sh $PERSIST | cut -f1)"
