#!/bin/bash
# 完整性校验：核心文件哈希比对，篡改触发ntfy告警
PERSIST=/home/user/ZONGYUAN-ROOT/persist_snapshot
MANIFEST=$PERSIST/L1_highvalue/integrity_manifest.txt
[ -f "$MANIFEST" ] || find $PERSIST/kernel -type f ! -path '*__pycache__*' -exec sha256sum {} \; | sort > $MANIFEST
DIFF=$(find $PERSIST/kernel -type f ! -path '*__pycache__*' -exec sha256sum {} \; | sort | diff $MANIFEST - | wc -l)
if [ "$DIFF" -gt 0 ]; then
  curl -s -d "⚠️ ZONGYUAN-ROOT完整性告警: $DIFF处文件哈希不匹配" https://ntfy.sh/zongyuan-kunlun-2026 > /dev/null
  echo "⚠️ 完整性告警: $DIFF处不匹配"
else
  echo "✅ 完整性校验通过"
fi
