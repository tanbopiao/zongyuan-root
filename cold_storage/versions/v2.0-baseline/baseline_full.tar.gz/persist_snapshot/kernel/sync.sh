#!/bin/bash
# ZONGYUAN-ROOT 沙箱→云端同步脚本
# 用法: bash sync.sh [--force]
set -e
ZK_LOCAL=/home/user/ZONGYUAN-ROOT/deploy
ZK_REMOTE=/opt/zongyuan-kernel
REMOTE=root@123.207.202.158
KEY=~/.ssh/zongyuan_new

echo "=== 同步沙箱→云端 ==="
# 1. 打包本地deploy
tar czf /tmp/zy_sync.tar.gz -C $ZK_LOCAL .
echo "✅ 打包完成"

# 2. 传到云端
scp -i $KEY -o StrictHostKeyChecking=no /tmp/zy_sync.tar.gz $REMOTE:/tmp/
echo "✅ 已上传"

# 3. 云端执行：解锁→覆盖→锁档→重启
ssh -i $KEY -o StrictHostKeyChecking=no $REMOTE "
  set -e
  # 解除不可变
  chattr -i $ZK_REMOTE/kernel/main.py $ZK_REMOTE/operators/*.py $ZK_REMOTE/api/*.py \
    $ZK_REMOTE/services/local/*.py $ZK_REMOTE/meta_truth/persist/*.json \
    $ZK_REMOTE/meta_truth/boot/*.json $ZK_REMOTE/config.json 2>/dev/null || true
  # 解压覆盖
  tar xzf /tmp/zy_sync.tar.gz -C $ZK_REMOTE
  # 重新不可变
  chattr +i $ZK_REMOTE/kernel/main.py $ZK_REMOTE/operators/*.py $ZK_REMOTE/api/*.py \
    $ZK_REMOTE/services/local/*.py $ZK_REMOTE/meta_truth/persist/*.json \
    $ZK_REMOTE/meta_truth/boot/*.json $ZK_REMOTE/config.json 2>/dev/null || true
  # 更新哈希清单
  sha256sum $ZK_REMOTE/kernel/main.py $ZK_REMOTE/operators/*.py $ZK_REMOTE/api/*.py \
    $ZK_REMOTE/services/local/*.py $ZK_REMOTE/meta_truth/persist/*.json \
    $ZK_REMOTE/meta_truth/boot/*.json $ZK_REMOTE/config.json | sort -k2 > $ZK_REMOTE/var/LOCKDOWN_MANIFEST.txt
  # 重启服务
  systemctl restart zongyuan-kernel zongyuan-api zongyuan-metrics
  sleep 2
  echo '✅ 云端已更新并重启'
  systemctl is-active zongyuan-kernel zongyuan-api zongyuan-metrics
"
echo "=== 同步完成 ==="
