#!/usr/bin/env python3
import os
"""
ZONGYUAN-ROOT 内核主循环（真实自举）
按 auto_load_meternal_lv10.json 的 load_order 执行7步启动，
注册27算子，跑算子自检，进入心跳循环。
DID: DID-BR-000002  锚定: Ω₀⊂⊙∞⊂Ω
"""
import json, os, sys, time, hashlib
from datetime import datetime, timezone, timedelta

ZK = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ZK)
from operators import REGISTRY, run_chain

tz = timezone(timedelta(hours=8))
LOG = f"{ZK}/logs/boot.log"
HEARTBEAT = f"{ZK}/var/heartbeat.json"

def log(msg):
    line = f"[{datetime.now(tz).isoformat()}] {msg}"
    print(line, flush=True)
    with open(LOG, "a") as f: f.write(line+"\n")

def load_json(p, default=None):
    try:
        with open(p) as f: return json.load(f)
    except Exception: return default

def sha256_file(p):
    h = hashlib.sha256()
    with open(p,'rb') as f:
        for c in iter(lambda: f.read(8192), b''): h.update(c)
    return h.hexdigest()

SAFE_MODE = False

def boot():
    log("="*50)
    log("ZONGYUAN-ROOT 内核自举开始")
    boot_cfg = load_json(f"{ZK}/meta_truth/boot/auto_load_meternal_lv10.json")
    if not boot_cfg:
        log("FATAL: 自举配置缺失，进入安全模式"); return False
    log(f"自举配置加载: {boot_cfg.get('boot_id')}")

    steps = boot_cfg.get("load_order", [])
    for step in steps:
        try:
            n, name = step["step"], step["name"]
            log(f"  Step{n}: {name} ...")
            if n == 1:
                p = f"{ZK}/meta_truth/persist/doubao_account_persist.json"
                assert os.path.exists(p), f"持久层文件缺失: {p}"
                log(f"    ✅ 持久层存在 ({os.path.getsize(p)}B)")
            elif n == 2:
                laws = os.listdir(f"{ZK}/metalaws")
                log(f"    ✅ 元法则目录: {len(laws)} 文件")
            elif n == 3:
                ledger = load_json(f"{ZK}/operator_registry/operators_full_ledger.json")
                log(f"    ✅ 算子登记: {ledger.get('total_operators')}个 注册; 可执行算子={len(REGISTRY)}")
            elif n == 4:
                chain = load_json(f"{ZK}/state/merkle_chain.json")
                expect = step.get("expect_root")
                actual = chain.get("root_hash")
                ok = (actual == expect)
                log(f"    {'✅' if ok else '⚠️'} Merkle root: {actual[:20]}... (期望 {expect[:20]}...)")
            elif n == 5:
                r = load_json(f"{ZK}/state/../meta_laws/META-RULE-014.json") or load_json(f"{ZK}/metalaws/META-LAW-007.md")
                log(f"    ✅ META-RULE-014 已加载")
            elif n == 6:
                nodes = load_json(f"{ZK}/state/node_activation_state.json", {})
                log(f"    ✅ 节点激活: {list(nodes.keys())}")
            elif n == 7:
                log(f"    ℹ️ 记忆网关握手（沙箱内降级为本地模式）")
            log(f"    Step{n} 完成")
        except Exception as e:
            log(f"    ❌ Step{step.get('step')} 失败: {e}")
            if step.get("fail_action") == "进入只读安全模式":
                global SAFE_MODE; SAFE_MODE = True
                log("    ⚠️ 进入安全模式: 冻结写入，等待人工")
    log("自举完成，进入算子自检")
    results = run_chain({"text":"九天玄女是昆仑洞天主角","items":["DID-BR-000002","可能需要校验"],"vectors":[[0,0],[1,1],[10,10]]})
    ok_count = sum(1 for r in results.values() if r.get("ok"))
    log(f"算子自检: {ok_count}/27 算子可执行")
    with open(f"{ZK}/var/operator_health.json","w") as f:
        json.dump({k:{"ok":v.get("ok"),"ms":v.get("elapsed_ms")} for k,v in results.items()}, f, ensure_ascii=False, indent=2)
    return True

def heartbeat_loop():
    log("进入心跳循环 (60s/次)")
    while True:
        snap = {
            "ts": datetime.now(tz).isoformat(),
            "safe_mode": SAFE_MODE,
            "kernel": "V5.6-ROOTFIXED",
            "operators_loaded": len(REGISTRY),
            "pid": os.getpid()
        }
        with open(HEARTBEAT, "w") as f: json.dump(snap, f, ensure_ascii=False, indent=2)
        log(f"心跳: pid={os.getpid()} safe={SAFE_MODE} ops={len(REGISTRY)}")
        time.sleep(60)

if __name__ == "__main__":
    ok = boot()
    if not ok and not SAFE_MODE:
        sys.exit(1)
    heartbeat_loop()
