#!/bin/bash
# ZONGYUAN-ROOT 自治内核一键部署脚本
# 用法: bash install.sh [授权码]

set -e
INSTALL_DIR="/opt/ZONGYUAN-ROOT"
LICENSE_KEY="${1:-}"

echo "========================================="
echo "  ZONGYUAN-ROOT 自治内核一键部署"
echo "========================================="

# 1. 环境检测
echo "[1/6] 环境检测..."
if [ "$EUID" -ne 0 ]; then echo "请使用root用户运行"; exit 1; fi
python3 --version || { echo "需要Python3.10+"; exit 1; }
pip3 --version >/dev/null 2>&1 || { echo "需要pip3"; exit 1; }

# 2. 安装依赖
echo "[2/6] 安装依赖..."
pip3 install fastapi uvicorn chromadb python-dotenv requests 2>/dev/null | tail -1

# 3. 创建目录
echo "[3/6] 创建目录结构..."
mkdir -p $INSTALL_DIR/{logs,vector_db,Ω-Brainμ,truth_architecture,autonomous_kernel_protocol}

# 4. 授权验证
echo "[4/6] 授权验证..."
if [ -n "$LICENSE_KEY" ]; then
    echo "  使用授权码: $LICENSE_KEY"
    python3 $INSTALL_DIR/license_guard.py activate "$LICENSE_KEY" 2>/dev/null || echo "  授权验证失败，将以免费版运行"
else
    echo "  未提供授权码，将以免费版运行（10条真值/1实例）"
    echo "  激活命令: python3 $INSTALL_DIR/license_guard.py activate <授权码>"
fi

# 5. 初始化真值库
echo "[5/6] 初始化真值库..."
if [ ! -f "$INSTALL_DIR/Ω-Brainμ/truth_index.json" ]; then
    echo '{"version":"v1.0-init","truth_count":3,"truths":[{"id":"AX-01","type":"axiom","level":"L0_AXIOM","content":"元极恒一公理","status":"FROZEN"},{"id":"AX-02","type":"axiom","level":"L0_AXIOM","content":"三态收敛公理","status":"FROZEN"},{"id":"AX-03","type":"axiom","level":"L0_AXIOM","content":"符号涌现公理","status":"FROZEN"}]}' > $INSTALL_DIR/Ω-Brainμ/truth_index.json
fi

# 6. 启动服务
echo "[6/6] 启动服务..."
cd $INSTALL_DIR
nohup python3 ai-native-ops/vector_server.py > logs/vector.log 2>&1 &
nohup python3 license_server.py > logs/license.log 2>&1 &

echo ""
echo "========================================="
echo "  部署完成！"
echo "  向量库: http://localhost:8003/health"
echo "  授权服务: http://localhost:8007/health"
echo "  日志: $INSTALL_DIR/logs/"
echo "  激活授权: python3 $INSTALL_DIR/license_guard.py activate <码>"
echo "========================================="
